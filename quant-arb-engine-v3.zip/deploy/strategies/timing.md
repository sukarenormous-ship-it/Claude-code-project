# Regime Detection & Strategy Timing

Read by: Stage 2 FILTER (every scan)

---

## 1. Product-Based Regime Detection

Detect regime from exchange products — not from indicators or sentiment indices.
Products ARE the market. Indicators are someone else's interpretation.

### 6 Product Signals

| # | Product | Bull | Bear | Neutral | Weight |
|---|---------|------|------|---------|--------|
| 1 | Futures basis APY | >8% contango | <2% or backwardation | 2-8% | HIGH |
| 2 | Funding rate /8hr | >+0.005% | <-0.005% | -0.005 to +0.005% | HIGH |
| 3 | Options IV skew | call IV > put IV by >3pp | put IV > call IV by >3pp | within 3pp | MED |
| 4 | Order book bid-ask spread | <0.1% tight | >0.3% wide | 0.1-0.3% | MED |
| 5 | Spread Trading APR | >10% + active volume | <5% + dead volume | 5-10% moderate | LOW |
| 6 | Earn/promo rates | <6% APY, few promos | >8% APY, aggressive promos | 6-8% | LOW |

**Signal weights — when signals conflict:**

```
HIGH weight (Funding + Futures basis):
  Direct market pricing by participants putting capital at risk.
  Most reliable regime indicators. Trust these over others.

MED weight (Options shape + Order book):
  Participant behavior signals. Reliable but can lag regime changes.

LOW weight (Earn rates + Spread Trading page):
  Platform-derived or secondary signals. Confirm regime but don't determine it.

If HIGH-weight signals conflict with LOW-weight:
  → trust HIGH-weight.
  e.g., funding strongly negative + Earn rate normal → still Bear.
```

### Regime Classification

```
≥4 signals pointing same direction → HIGH CONFIDENCE
  Use that regime's timing map directly.

3 signals same direction → MEDIUM CONFIDENCE
  Use that regime's timing map but with caution.
  Consider smaller position sizes.

Signals scattered → TRANSITION
  Regime is changing. See Transition rules below.

Signals contradicting → MIXED
  Different assets/timeframes showing different regimes.
  Scan both sides. Flag all candidates with regime uncertainty.
```

### Detection Examples

```
IMPORTANT — Per-Asset Regime Detection:
  Regime can differ across assets. Crypto (BTC/ETH) and commodity
  tokens (XAUT, oil) often diverge.
  Rules:
    1. If scanning multiple assets → detect regime PER asset or asset class
    2. Apply timing filter per asset, not globally
       e.g., skip BTC spread-arb (bear) but KEEP XAUT spread-arb (bull)
    3. Common divergences:
       Crypto vs Commodity tokens (different macro drivers)
       BTC vs Altcoins (BTC dominance rising = alt-bearish)
    4. Cross-asset divergence itself is a signal (pairs trading opportunity)
```

```
Example A — Bear + Extreme Fear:
  1. Futures: BTC basis 2-5% → neutral (2-8% range), NOT bear
  2. Funding: -0.01%/8hr < -0.005% ✓ bear
  3. Options: IV 51% vs RV 27%, put skew >3pp ✓ fear
  4. Spread Trading: APR 3% <5%, no volume ✓ dead
  5. Earn: 12% USDT promo >8% ✓ desperate
  6. Order book: XAUT bid-ask spread >0.3% ✓ scared
  → 5/6 bear (basis is neutral) → HIGH CONFIDENCE Bear

Example B — Bull:
  1. Futures: BTC basis 15-25% (steep contango) ✓ bull
  2. Funding: +0.03%/8hr (longs paying heavily) ✓ bull
  3. Options: call volume high, call IV elevated ✓ greed
  4. Spread Trading: 15%+ APR, active volume ✓ active
  5. Earn: normal 3-5% rates, few promos ✓ stable
  6. Order book: thick, tight spreads ✓ confident
  → 6/6 bull → HIGH CONFIDENCE Bull

Example C — Transition:
  1. Futures: basis widening from flat → slight contango ✓ shifting
  2. Funding: flipping between positive and negative daily ✓ uncertain
  3. Options: put skew flattening, call volume increasing ✓ fear fading
  4. Spread Trading: APR increasing from 3% to 7% ✓ waking up
  5. Earn: promos still active but rates declining ✓ transitioning
  6. Order book: depth improving ✓ returning confidence
  → mixed signals, no clear majority → TRANSITION
```

---

## 2. Regime-Timing Map

### Which strategies work when — and which to skip.

For each regime: scan priority 1 first (easiest to find), then 2 (harder), skip regime-wrong.

---

### BULL + GREED (basis wide, funding positive, IV low-moderate)

```
Priority 1 — Easiest to find:
  spread-arb         Basis 10-25%+, contango steep → textbook cash-and-carry
  funding-harvest    Funding 0.01-0.05%/8hr → spot+short perp prints money
  
Priority 2 — Available but harder:
  conversion         Parity may bend during high demand, but MMs active → rare
  cross-exchange     Funding diverges across exchanges during FOMO
  weekend-gap        Always available, edge magnitude same
  platform-yield     Always available, rates typically lower (platform not desperate)

SKIP — Regime wrong:
  reverse-funding    Funding positive → you'd PAY, not receive

LOW PRIORITY — Better alternatives usually exist:
  earn-hedge         Funding harvest usually beats Earn+hedge in bull.
                     BUT if Earn promo is exceptionally high → check net vs harvest.

CONDITIONAL — Usually skip but exceptions exist:
  sell-vol           DEFAULT skip: IV often understates during sustained bull
                     EXCEPTION: if IV spikes >15pp above RV during bull
                     (local fear event within bull trend) → may sell short-dated
```

---

### BEAR + FEAR (basis flat/negative, funding negative, IV elevated)

```
Priority 1 — Easiest to find:
  platform-yield     Earn 8-12%+ (desperate promos), always works
  sell-vol           IV >> RV gap (fear premium), crowd overpays protection

Priority 2 — Available but harder:
  reverse-funding    Funding negative → long perp receives, but borrow cost is key
  weekend-gap        Always available, gold volatile → larger gaps
  earn-hedge         If Earn rate > hedge cost → works
  cross-exchange     Fear creates funding divergence across exchanges

SKIP — Regime wrong:
  spread-arb         Basis 2-5% → at or below floor 5%, waste of time
  funding-harvest    Funding negative → you'd PAY, not receive

LOW PRIORITY — Rarely found but not regime-wrong:
  conversion         MMs present in calm/fearful markets → edge ≈ 0 usually.
                     But profile avoid_regime = None → don't hard-skip, just scan last.

REFERENCE — Bear regime composite strategies:
  See strategies/real-world-discoveries.md §2 for tested hand rankings (β, γ, α)
  in bear+sideways regime. These are [Opinion — Analytical] from March 2026 —
  verify with current data before applying.
```

---

### SIDEWAYS + COMPRESSED VOL (range-bound, funding neutral, IV low)

```
Priority 1 — Easiest to find:
  sell-vol           Range-bound = IC/credit spread territory, theta decay is ally
  platform-yield     Always available

Priority 2 — Available but harder:
  spread-arb         Small basis may exist if contango → check if above floor
  weekend-gap        Always available, smaller gaps (low underlying vol)
  earn-hedge         Funding near zero → hedge cost low → may work

SKIP — Regime wrong:
  funding-harvest    Funding near zero → no income
  reverse-funding    Funding near zero → no income

LOW PRIORITY — Rarely found but not regime-wrong:
  conversion         Tight pricing → parity violations rare. Scan last.
  cross-exchange     Funding aligned across exchanges → gap rare. Scan last.
```

---

### TRANSITION (regime changing — signals mixed/shifting)

```
Special rules — do NOT use normal regime filtering:
  1. Do NOT filter any cataloged strategy — scan all
  2. Prioritize strategies that profit from the change itself:
     - Risk reversal (buy cheap calls funded by expensive puts during fear→recovery)
     - Basis expansion/contraction trades (enter spread arb as basis widens)
     - Funding direction change (enter funding harvest as funding turns positive)
  3. Flag all candidates: "regime uncertain — reduce size"
  4. Use shorter duration (7-14 days max) to limit regime-change risk
  5. Re-assess regime every 2-3 days during transition

Transition detection signals:
  - Funding flipping sign frequently
  - Basis widening/narrowing rapidly  
  - IV curve changing shape (skew flattening or steepening)
  - Earn promo rates changing
  - Order book depth improving/deteriorating
```

---

### ALWAYS AVAILABLE (regime-independent)

```
These strategies work in any regime — check first, always:

  platform-yield     Earn/savings products, promo rates
                     Available: any time
                     Scan: check current APR, caps, terms
                     
  weekend-gap        TradFi closes → RWA tokens drift
                     Available: Friday before TradFi close → Monday after open
                     Thursday: begin assessing — catalyst expected this weekend?
                     Tuesday-Wednesday: not actionable, don't scan
                     Scan: Friday, assess underlying volatility + weekend events
                     
  convert-rate-gap   Platform Convert vs spot market price
                     Available: any time
                     Scan: whenever checking platform features

  cross-exchange     Spot PRICE differences between exchanges (Lv.1 arb)
                     Note: this is spot arb, NOT cross-exchange funding arb
                     (funding arb has its own profile: cross-exchange-funding.md)
                     No profile for spot arb — treat as UNCATALOGED if found
                     Available: any time, but gaps more frequent during high volatility
                     Scan: during volatility spikes or exchange-specific events

Priority: scan these BEFORE regime-specific strategies.
They're fastest to check and don't depend on regime assessment being correct.
```

---

## 3. Timing Decision Rules

### For Stage 2 FILTER

```
Input:  regime (from Stage 1) + list of all observations
Output: filtered list (regime-wrong removed)

Process:
  1. Determine regime confidence (HIGH / MEDIUM / TRANSITION / MIXED)
  
  2. If HIGH or MEDIUM confidence:
     - For each cataloged strategy, check profile.timing.avoid_regime
     - If current regime matches avoid_regime → remove from list
     - Keep everything else (including uncataloged items)
  
  3. If TRANSITION or MIXED:
     - Do NOT remove anything — scan all
     - Add transition-specific strategies to scan list
     - Flag all candidates with regime uncertainty
  
  4. Always keep:
     - "Always available" strategies
     - Uncataloged observations (no profile → can't determine regime fit)
     - Anything unusual or unexpected
```

### Quick Reference: avoid_regime by profile

| Profile | avoid_regime (quantitative) |
|---------|---------------------------|
| spread-arb | Basis APY < 2% (flat/backwardation) |
| funding-harvest | Funding < +0.005%/8hr (not positive enough) |
| reverse-funding | Funding > -0.005%/8hr (not negative enough) |
| sell-vol | TRANSITION regime (signals scattered/contradicting) |
| platform-yield | None |
| weekend-gap | None |
| cross-exchange-funding | None (but gaps rare when funding within ±0.005%) |
| conversion | None (but rarely found in any regime) |
| earn-hedge | When net (Earn APR − hedge cost) < floor 3% |

---

## 4. Regime Shift Awareness

```
Within a single conversation:
  Regime rarely shifts during one chat session. No need to re-check mid-chat.

Across conversations (user returns after days/weeks):
  Do NOT assume previous regime still holds.
  Always re-run Stage 1 OBSERVE from scratch.
  
  Key shift signals to watch for:
    - Funding rate sign change (most common early signal)
    - Basis expanding/contracting rapidly
    - Earn promo rate changes (platform behavior shifting)
    - Options skew changing direction

  If user mentions something that implies regime changed:
    e.g., "funding just flipped positive" or "basis is widening"
    → acknowledge the shift
    → re-assess which strategies are now viable/not viable
    → previously skipped strategies may now work
    → previously READY strategies may now be regime-wrong
```
