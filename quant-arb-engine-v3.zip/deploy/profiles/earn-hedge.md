```yaml
identity:
  name:        Earn + Hedge (Platform Yield Arbitrage)
  type:        Lv.3 if hedge is perp or future (delta neutral, carry risk remains)
               Lv.4 if hedge is partial or options-based (residual directional risk)
  mechanism:   Platform Earn rate exceeds the cost of hedging price risk.
               Deposit asset → earn yield → hedge with short perp/future.
               Net = Earn APR - hedge cost. [PLATFORM + STRUCTURAL]
  maturity:    CATALOGED

timing:
  regime:        All regimes — but net depends heavily on funding direction
  avoid_regime:  When net (Earn APR − hedge cost) < floor 3% — check net before entering
  best_when:     Earn promo active + funding positive (longs pay shorts = your short hedge earns funding)

operating_range:
  floor:         3% net APY (after hedge cost)
  entry:         5% net APY
  normal:        3-8% net APY
  exceptional:   >10% net (promo + favorable funding alignment)
  metric:        net APY = Earn APR - |funding cost| - borrow cost - fees
  range_basis:   floor = minimum where yield justifies 2-leg complexity + monitoring cost.
                 3% from 2 legs vs 4% from 1 leg (platform-yield) → barely worth it.
                 entry = 5% gives enough margin over platform-yield baseline.
  recalibrate_when: Earn product terms change, funding regime shifts,
                    new hedge instruments become available.

alternatives:
  when_below_floor:  platform-yield (Earn without hedge — accept price risk)
  when_regime_wrong: platform-yield (if hedge cost too high, just Earn)
  simpler_version:   platform-yield (1 leg, higher risk but no hedge cost)

execution:
  style:         continuous with monitoring — deposit + hedge, monitor costs
                 NOT set-and-forget like platform yield alone.
                 Hedge cost changes every 8hr (funding) → must monitor.
  hedge_selection:
    perp_hedge:
      pro: no expiry, flexible exit anytime
      con: funding cost variable — net APY unpredictable
      use_when: funding currently favorable and expected stable
    future_hedge:
      pro: basis cost locked at entry — net APY predictable
      con: fixed expiry, may need to roll, possible settlement fee
      use_when: want certainty on net yield, contango reasonable
    choice_rule: if funding volatile (flipping signs) → dated future for predictability.
                 if funding stable + favorable direction → perp for flexibility.
  entry_signal:  net APY > entry threshold after all costs
  exit_signal:   net APY drops below floor for >2 consecutive periods
                 OR Earn rate changes OR hedge cost spikes
  position_mgmt: check net daily (funding changes, Earn rate may change).
                 if funding flips → net may go negative → exit hedge, keep Earn or exit both.

verification:
  must_check:
    - Earn APR (actual, not headline)
    - Earn cap per user (limits size)
    - Earn withdrawal terms (can you exit quickly?)
    - CRITICAL: does Earn deposit count as collateral for hedge?
      If YES → capital efficient (1× capital for both legs)
      If NO → need 2× capital (one for Earn, one for hedge margin)
      → effective APY halved if 2× capital needed
      → MUST verify before calculating net
    - current funding rate (for perp hedge) or basis (for futures hedge)
    - borrow cost (if applicable)
    - net = Earn - hedge cost → positive?
  freshness:
    - Earn APR: daily
    - funding rate: every 8hr
    - borrow rate: daily
  platform_reqs: Earn product + perp/futures for same asset on same platform.

costs:
  net_formula:
    if Earn counts as collateral (1× capital):
      net_APY = Earn_APR - |hedge_cost| - fees
    if Earn does NOT count as collateral (2× capital):
      effective_net = (Earn_APR - |hedge_cost| - fees) / 2
  formula_example:
    Earn 11%, funding cost 5.5% APY (= 0.005%/8hr × 3 × 365), fees ~0.5%
    if collateral:     net = 11% - 5.5% - 0.5% = 5.0% APY ✓ above entry
    if NOT collateral: net = 5.0% / 2 = 2.5% APY ✗ below floor 3%
    → collateral status flips the decision: READY vs SKIP
  fees:          Earn: usually none. Hedge: perp maker ~0.02% × 2 sides.
  hidden_costs:  funding rate fluctuation (main cost uncertainty),
                 Earn cap limits size, withdrawal delay may trap capital
  min_profit:    $15 per week (2 legs + daily monitoring)

risks:
  primary:       Funding flips → hedge cost exceeds Earn rate → net negative
  secondary:     Earn rate changes without notice, asset depegs from underlying
  kill_condition: Net APY negative for >1 day → exit both legs
  what_can_go_wrong: XAUT Earn 11%, funding cost 3%, net = 8%. Looking great.
                     Funding flips to -5% (you now pay 5%) → net = 11-5 = 6%. Still OK.
                     But if Earn drops to 3% simultaneously → net = 3-5 = -2% → losing money.
                     Must monitor both variables, not just one.
```
