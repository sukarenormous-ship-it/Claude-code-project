```yaml
identity:
  name:        Sell Volatility / Iron Condor / Credit Spread
  type:        Lv.4 Structured
  mechanism:   Crowd overpays for options protection when fearful (IV > RV).
               Selling overpriced options captures the fear premium. [HEURISTIC]
               NOT arb — statistical edge, can lose on any single trade.
  maturity:    CATALOGED

timing:
  regime:        Bear + fear (IV elevated) OR Sideways + compressed vol
  avoid_regime:  Transition — vol may explode during regime change
  best_when:     IV-RV gap >20pp + regime appears stable for next 7-14 days

operating_range:
  floor:         5pp IV-RV gap — below this, premium too thin
  entry:         10pp gap
  normal:        5-15pp
  exceptional:   >20pp — extreme fear premium
  metric:        pp (percentage points) IV minus RV(30d)
  range_basis:   floor = minimum gap where collected premium covers expected
                 adverse move + fees. ~5pp historically covers 1-sigma move over 7-14d.
  recalibrate_when: market vol regime shifts structurally, or after 10+ IC trades
                    show actual win rate and avg P/L.

alternatives:
  when_below_floor:  platform-yield (no vol exposure)
  when_regime_wrong: long vol strategies (buy straddle if expecting breakout)
  simpler_version:   credit spread (2 legs instead of 4 for IC)

execution:
  style:         expiry-bound — open position, manage until expiry
                 NOT multi-cycle within same expiry.
                 Can repeat with new expiry after previous one settles.
  structures:
    credit_spread:
      legs: 2
      risk: bounded one side
      use_when: directional lean within vol sell thesis, smaller capital
      min_profit: $15
    iron_condor:
      legs: 4
      risk: bounded both sides
      use_when: range-bound conviction, want to sell vol both directions
      min_profit: $30
    naked_short:
      legs: 1-2
      risk: UNLIMITED — strongly discouraged
      use_when: almost never in this context
  entry_signal:  IV-RV gap > entry + regime stable (not transitioning)
  exit_signal:   expiry (let it settle) OR close early if:
                 - IV collapses → take profit early
                 - price approaches short strike → cut loss
  position_mgmt: monitor daily. if price moves toward short strike,
                 decide: roll, widen, or close. use short-dated (7-14d)
                 in compressed regimes to limit breakout exposure.

verification:
  must_check:
    - current IV (ATM or relevant strikes)
    - realized vol (30-day)
    - options liquidity at target strikes:
        bid-ask spread must be < 5% of premium collected
        order book depth must be ≥ 2× desired position size
    - max loss at wing strikes — is it acceptable?
  freshness:
    - IV: < 24 hours
    - RV: < 3 days (slow-moving)
    - options depth: < 1 hour (for execution)
  platform_reqs: Options trading enabled. Sufficient strikes available.

costs:
  net_formula:   max_profit = total premium collected - total fees
                 max_loss = wing_width - premium (for IC/spread)
                 expected_PnL = (win_rate × avg_win) - ((1-win_rate) × avg_loss)
  formula_example: BTC IC, sell 65K put / buy 60K put / sell 80K call / buy 85K call
                   premium collected $120, fees $3, max loss $5000-120=$4880
                   win rate ~67%, avg win ~$117, avg loss ~$200
                   expected = 0.67×117 - 0.33×200 = $78-$66 = +$12 per trade
                   (thin edge — requires consistent execution over many trades)
  fees:          options maker ~0.02% × 4 legs (IC) or × 2 legs (credit spread)
  hidden_costs:  bid-ask spread on OTM strikes (often wide),
                 assignment/exercise risk near expiry
  min_profit:    see structures above ($30 for IC, $15 for credit spread)

risks:
  primary:       Breakout — price moves beyond short strike → max loss on wing
  secondary:     Vol expansion (IV goes higher instead of converging to RV)
  kill_condition: Price breaches short strike — close or roll immediately
  what_can_go_wrong: IV gap 24pp, sell IC. 46-day compression ends with 15% breakout.
                     Price blows through short strike → max loss.
                     Win rate ~65-70% but each loss can be 2-3× each win.
```
