```yaml
identity:
  name:        Conversion / Reversal Arbitrage
  type:        Lv.1 Pure Arb
  mechanism:   Put-call parity violation: C - P ≠ S - PV(K). When violated after fees,
               a riskless profit can be locked by trading all 3 simultaneously. [AXIOM]
  maturity:    CATALOGED

timing:
  regime:        All regimes — parity is regime-independent
  avoid_regime:  None — but opportunities are rarer when market is efficient (calm markets)
  best_when:     Vol spikes, MM withdrawal, new listing, unusual order flow

operating_range:
  floor:         edge > round-trip executable cost (~0.15% for crypto options)
  entry:         edge > 0.3% (comfortable margin above floor — covers slippage uncertainty)
  normal:        0.15-0.5% per trade
  exceptional:   >1% — market stress or MM offline
  metric:        % edge after executable cost
  range_basis:   floor = spot fee (~0.1%) + options fees (~0.02%×2) + slippage (~0.01%) ≈ 0.15%.
                 any edge below this is consumed by fees.
  recalibrate_when: options fee structure changes, or new market maker enters
                    (could tighten spreads → lower floor).

alternatives:
  when_below_floor:  no alternative for Lv.1 — either it exists or it doesn't.
                     move on to Lv.2+ strategies.
  when_regime_wrong: N/A — regime-independent
  simpler_version:   N/A — already the gold standard of arb

execution:
  style:         instant capture — all legs executed simultaneously or near-simultaneously
                 NO holding period. Profit locked at execution.
                 No multi-cycle concept — each occurrence is independent.
  entry_signal:  parity violation > fees detected via scan
  exit_signal:   N/A — position is fully hedged at entry. Wait for settlement.
  position_mgmt: none needed — all legs offset. Just wait for expiry/settlement.

verification:
  must_check:
    - ALL prices at bid/ask (not mid!):
        conversion (buy spot + buy put + sell call):
          spot ASK, put ASK, call BID
        reversal (sell spot + sell put + buy call):
          spot BID, put BID, call ASK
    - total executable cost across all 3 legs
    - settlement alignment (do all legs settle same way?)
    - exercise style (European? American? auto-exercise?)
  scan_method:
    1. focus ATM ± 2 strikes (highest liquidity, most likely edge)
    2. at each strike check:
       conversion: C(bid) - P(ask) vs S(bid) - PV(K)
       reversal:   P(bid) - C(ask) vs PV(K) - S(ask)
    3. if edge > total fees → candidate
    4. scan more often during: vol spikes, MM withdrawal, new listings
    5. normal conditions: usually fruitless — don't spend time unless triggered
  freshness:
    - ALL prices: real-time (must be simultaneous)
    - executable within seconds of calculation
  platform_reqs: Options + spot on same exchange. Same expiry available.

costs:
  fees:          spot ~0.1% + options ~0.02% × 2 + possible exercise/settlement fee
  hidden_costs:  legging risk (prices move between leg executions),
                 pin risk near expiry, exercise fee
  min_profit:    $5 per trade (3 legs but instant, no monitoring)

risks:
  primary:       Legging risk — can't fill all 3 legs at quoted prices
```
