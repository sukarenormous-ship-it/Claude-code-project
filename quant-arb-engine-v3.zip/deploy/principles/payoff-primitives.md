# Payoff Primitives & Building Block Design

Every statement is labeled: **[Exact Identity]**, **[Approximation]**, **[Heuristic]**, or **[Contract-specific]**.

## Table of Contents

1. Hidden Option Recognition
2. Put-Call Parity
3. Synthetic Positions
4. Digital / Binary Approximations
5. Spread & Locked Identities
6. PM Parity Relations
7. Greeks as Design Language
8. Implied Information Extraction
9. Contract Normalization
10. Pricing Pitfalls & Reality Checks

---

## 1. Hidden Option Recognition

Anything with conditional payoff is an option. Recognize hidden options to invent building blocks.

| Observation | Option Interpretation |
|------------|----------------------|
| Funding rate on perps | Option on carry regime [Heuristic] |
| PM Above No | Digital put — pays if price stays below boundary [Exact within PM] |
| PM Range Yes | Binary range accrual — pays if in target zone [Exact within PM] |
| Stop-loss order | Synthetic put with execution risk [Approximation] |
| Liquidation cascade | Path-dependent barrier event [Heuristic] |
| Take-profit order | Synthetic covered call [Approximation] |
| Basis between venues | Mean-reverting spread — convergence optionality [Heuristic] |
| IV > RV spread | Volatility risk premium [Heuristic — regime dependent] |

**Recognition process:** For each observation, identify: underlying state variable, strike/threshold, expiry, payoff shape, long/short, implied cost, tradability.

---

## 2. Put-Call Parity [Exact Identity]

```
C(K,T) - P(K,T) = S - K × e^(-rT)          (European, no dividends)
C - P = S - PV(divs) - PV(K)                (with dividends)
C - P = e^(-rT) × (F - K)                   (forward form)
C - P = S - PV(K) - accumulated_funding      (crypto/perps) [Contract-specific]
```

---

## 3. Synthetic Positions [Exact Identity]

PV(K) / financing component is **never optional** for pricing or parity checks.

| Synthetic | Construction | Exact Relationship |
|-----------|-------------|-------------------|
| Synthetic Long Forward | Long Call(K) + Short Put(K) | = Forward at K, NOT spot |
| Synthetic Long Stock | Long Call(K) + Short Put(K) + PV(K) cash | = S exactly |
| Synthetic Long Call | Long Stock + Long Put(K) - PV(K) | = C(K) |
| Synthetic Long Put | Short Stock + Long Call(K) + PV(K) | = P(K) |
| Conversion | Long Stock + Long Put(K) + Short Call(K) | = PV(K) |
| Reversal | Short Stock + Short Put(K) + Long Call(K) | = -PV(K) |
| Box Spread | Bull Call Spread + Bear Put Spread (same strikes) | = PV(K2 - K1) |

**Common error:** "Long Call + Short Put = Synthetic Stock" — **wrong.** It equals synthetic forward. Stock requires + PV(K).

---

## 4. Digital / Binary Approximations [Approximation]

```
Digital Call(K) ≈ Bull Call Spread(K, K+ε) ÷ ε
Digital Put(K) ≈ Bear Put Spread(K-ε, K) ÷ ε
```

**Without ÷ ε, max payout = ε, not 1. Always normalize.**

PM Above Yes(K) IS a native digital call [Exact within PM].
PM digital ≠ Options digital when resolvers differ [Contract-specific].

---

## 5. Spread & Locked Identities [Exact Identity]

```
Bull Call Spread(K1,K2) + Bear Put Spread(K1,K2) = PV(K2 - K1)   (box)
→ Use whichever spread is cheaper to execute

Butterfly(K1,K2,K3) = Long Call(K1) + 2×Short Call(K2) + Long Call(K3)
  Peaked at K2

Iron Condor = Bull Put(K1,K2) + Bear Call(K3,K4)
  Profit if S stays in [K2, K3]
```

---

## 6. PM Parity Relations (Same Platform)

For cross-platform PM parity, see `principles/pm-arb-mechanics.md`.

**Binary pair** [Exact Identity]:
```
Ask(Yes) + Ask(No) ≥ $1.00   (round-trip executable cost)
If Ask(Yes) + Ask(No) < $1.00 → instant arb
```

**Exhaustive cover** [Exact Identity]:
```
Σ Ask(all brackets) ≥ $1.00
If Σ Ask < $1.00 → instant arb
```

**Above × Range** [Approximation]:
```
Range(L,U) ≈ Above(L) - Above(U)
```
Significant deviation beyond executable cost = edge signal [Contract-specific].

---

## 7. Greeks as Design Language

| Desired property | Greek target | Building block |
|-----------------|-------------|----------------|
| Linear exposure | High Δ, low Γ | Deep ITM, future, perp |
| Convex exposure | High Γ | ATM or OTM option |
| Income from time | Positive Θ | Short option |
| Vol increase bet | Positive Vega | Long straddle/strangle |
| Vol decrease bet | Negative Vega | Credit spread, iron condor |
| Bounded risk | Capped payoff | Spread, collar |

**PM Greeks** [Approximation]: PM has extreme gamma near boundary — good for sharp boundary repair, poor for gradual hedging.

---

## 8. Implied Information Extraction

| Source | Information | Edge signal |
|--------|------------|-------------|
| IV vs RV | Options expensive or cheap | IV > RV = seller edge [Heuristic] |
| IV skew | Fear direction | Steep put skew = fear premium [Heuristic] |
| PM vs Options prob | Market disagreement | Large gap = investigate, not auto-exploit |
| Funding rate | Crowd lean | Extreme = positioning bias [Heuristic] |
| Basis | Carry cost | Large = conversion opportunity [Heuristic] |

---

## 9. Contract Normalization [Contract-specific]

Before combining cross-venue instruments, normalize: multiplier/lot size, settlement type and source, expiry/resolution timing, boundary convention, exercise style, fee structure, quote convention.

---

## 10. Pricing Pitfalls

| Mistake | Fix |
|---------|-----|
| Mid price for both legs | Bid for sells, ask for buys |
| Ignoring PM executable cost | Subtract half-spread + fees |
| Comparing PM % to options % | Different shapes — convert first |
| Treating synthetic = original | Price the execution gap |
| Ignoring perp funding | Include in net payoff |
| Optimizing theoretical payoff | Optimize net deployable payoff |

**Reality check:** Price at executable → add costs → legging risk → settlement alignment → timing → edge erosion → stress worst case → **compare to simple alternative**.
