```yaml
identity:
  name:        Cross-Exchange Funding Arbitrage
  type:        Lv.3 Near-Arb
  mechanism:   Same asset's funding rate differs across exchanges due to different
               participant bases and liquidity pools. Short perp on exchange where 
               funding is higher (receive more), long perp on exchange where funding
               is lower (pay less). Net = rate differential. [STRUCTURAL]
  maturity:    CATALOGED

timing:
  regime:        All regimes — but gaps widen during extreme sentiment
  avoid_regime:  None — but harder to find during neutral/calm markets
  best_when:     Extreme fear or greed → different exchanges react differently

operating_range:
  floor:         0.003%/8hr gap between exchanges (~4% APY) — below this, fees on 2 exchanges kill it
  entry:         0.005%/8hr gap (~6.5% APY)
  normal:        0.003-0.01%/8hr gap
  exceptional:   >0.02%/8hr gap (~26% APY)
  metric:        %/8hr funding rate differential between exchanges
  range_basis:   floor = combined entry fees on 2 exchanges (~0.48% total)
                 amortized over ~14 days (42 periods) = ~0.0114%/8hr.
                 BUT: funding gap accrues every period, so floor is the gap 
                 where cumulative income > fees before gap closes.
                 At 0.003%/8hr gap × 42 periods = 0.126% total earned vs 0.48% fees → NOT enough.
                 Gap must persist at 0.003%/8hr for 160 periods (53 days) to break even.
                 Practical floor: 0.005%/8hr = breaks even in ~96 periods (32 days).
                 Entry: 0.005%/8hr assuming gap persists ≥14 days.
  recalibrate_when: fee tiers change on either exchange, or funding frequency changes.

alternatives:
  when_below_floor:  single-exchange funding harvest (if one side still extreme)
  when_regime_wrong: N/A — can work in any regime if gap exists
  simpler_version:   funding-harvest on single exchange (half the complexity)

execution:
  style:         monitoring-heavy — open when gap appears, close when gap converges
                 requires active monitoring or alerts on both exchanges
  entry_signal:  funding gap > entry threshold for ≥1 period
  exit_signal:   gap < floor OR gap flips (exchange A and B swap which pays more)
  position_mgmt: check every 8hr. rebalance margin if one side moves significantly.
                 be ready to close quickly if gap converges.

verification:
  must_check:
    - LIVE funding rates on BOTH exchanges (must be simultaneous snapshot)
    - fee structure on both exchanges (may differ significantly)
    - margin requirements on both (capital split)
    - withdrawal/transfer time between exchanges (for rebalancing)
  freshness:
    - funding rates: MUST be simultaneous — rates from different times are useless
    - fees: once per exchange (stable)
  platform_reqs: Accounts on 2+ exchanges. Perp contracts for same asset on both.

costs:
  fees:          perp maker/taker on BOTH exchanges (~0.02-0.055% × 2 × 2 sides)
  hidden_costs:  capital split across 2 exchanges (reduces efficiency),
                 transfer time for rebalancing, different margin rules
  min_profit:    $15 per day (4 legs across 2 platforms, heavy monitoring)

risks:
  primary:       Funding rates converge immediately → zero income
  secondary:     One exchange goes down → stuck with unhedged position on other
```
