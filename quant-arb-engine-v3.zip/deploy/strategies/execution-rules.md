# Execution Rules

Practical execution principles. Platform-specific parameters belong in the
Market-Spec template (see mechanism-transformations.md section 4).

---

## Execution Order

1. Buy the protective/long leg FIRST (safe leg)
2. Sell the short leg IMMEDIATELY after fill
3. Use limit orders near market (not market orders)
4. NEVER sell naked before buying protection

Rationale: if you sell first and can't fill the long leg, you're exposed
to unlimited risk for the time between fills.

---

## Expiry Selection Framework [Heuristic]

| Time to expiry | Premium behavior | Suitability |
|---------------|-----------------|-------------|
| Very short (<1 day) | Most premium already decayed | Poor — not enough to capture |
| Short (2-5 days) | Good premium remaining, fast theta | Good for credit strategies |
| Medium (2-4 weeks) | High absolute premium | Good for larger credit |
| Long (>1 month) | Most premium, but capital locked longer | Situational |

Match expiry to: PM resolution date (if hybrid), belief timeframe, capital rotation needs.

---

## Position Sizing

- Start with minimum size (1 contract) until strategy is proven
- Max position: ≤25% of account per trade [Heuristic — adjust to risk tolerance]
- Scale up only after consistent positive results
- Pre-trade check: "Am I willing to lose the maximum loss amount?"

---

## Risk Management

- Cut loss when underlying breaches short strike significantly
- Don't average down on losing options positions
- Track cumulative P&L across all positions, not just individual trades
- Monitor dynamic edges (e.g., conversion e_opt) — they change significantly
  within hours [Tested observation — re-verify with current data]

---

## Dynamic Edge Warning

Some edges (especially conversion basis, funding rate, PM pricing) are NOT static.
They can change substantially within a single trading session.

Implications:
- Edge measured at analysis time ≠ edge at execution time
- Structures relying on tight edge margins need real-time scanning
- "Guaranteed" profit from parity structures is only guaranteed at the moment of
  simultaneous fill — any delay introduces execution risk
