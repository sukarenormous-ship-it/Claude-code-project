# Real-World Discoveries, Regime Playbook & Design Principles

## Table of Contents

1. Non-Negative Design Principle
2. Regime-Specific Playbook: Bearish + Sideways
3. Real-World Efficiency Observations
4. Funding Rate — Limitations as Building Block
5. Practical Scanner Tools & Data Sources
6. PM Binary vs Linear Instruments — Scale Mismatch
7. Novel Structure Ideas (Not Yet Validated)
8. Key Heuristics Summary
9. Relationship to Other Skill References

---

This reference captures knowledge discovered through real market data analysis,
not from textbooks. Every observation was validated against live data from
Bybit, Polymarket, Binance, CoinGlass, and other sources (March 2026).
Novel structure ideas emerged from combining frameworks across the skill system.

**⚠️ STALENESS WARNING:**
Specific numbers (prices, rates, No rates, edge values) in this file are from
March 2026. They WILL be different now. Use the PRINCIPLES (non-negative design,
scale mismatch, funding instability) — they are permanent. But re-scan all
specific numbers before applying any strategy.

---

## 1. Non-Negative Design Principle [Discovered — Core Rule]

```
Non-Negative Structure = Locked Edge (core) + Income Layers (bounded loss)

RULE: max loss of ALL income layers combined ≤ locked edge ALWAYS
```

### What Qualifies as "Locked Edge"

| Instrument | Locked? | Why |
|-----------|---------|-----|
| Conversion/Reversal (all legs filled) | Yes | Put-call parity [Exact Identity] |
| Dated Futures Basis (spot + short futures) | Yes | Converges at expiry [Exact Identity] |
| Box Spread (4 legs, European) | Yes | PV(width) [Exact Identity] |
| Cross-Platform PM (same resolver) | Yes | YES + NO = $1 [Exact Identity] |
| Funding Rate carry | NO | Can flip direction anytime |
| Credit Spread (VRP) | NO | Has max loss scenario |
| PM Tail Fade | NO | Tail event = full loss |
| Protective Put + Spot | NO | Cost creates negative region |

### Income Layers — Enhance But Never Be Core

```
Sizing rule:
  N_max = Locked_Edge / Max_Loss_Per_Contract

  If N × max_loss > locked_edge → NOT non-negative
```

### Application Hierarchy

```
1. Find locked edge (conversion, basis, box, cross-PM)
2. IF exists → add income layers sized within edge → Lv.1-3
3. IF no locked edge → structure is Lv.4-5 (useful but not non-negative)
4. IF edge too small for income layers → wait or accept bounded loss
```

---

## 2. Regime-Specific Playbook: Bearish + Sideways

### Market Conditions Observed (March 2026)

```
- BTC: $71K → $66K in one week, 47% below ATH ($126K)
- ETH: broke below $2,000, 60% below ATH ($4,953)
- Fear & Greed Index: 16 (Extreme Fear)
- Funding rates: negative across BTC, ETH, SOL, XRP on Binance/Bybit
  BUT neutral some days (+0.003% Binance) → swing within days
- IV > RV on ETH puts (bearish skew high)
- ETF outflows: BTC -$171M, ETH -$92.5M single-day records
- Oil above $100 (geopolitical tension)
- Fed: held 3.5-3.75%, raised inflation outlook to 2.7%
```

### Strategy Viability in This Regime

| Strategy | Viability | Edge Source | Non-neg? |
|----------|----------|------------|----------|
| Dated Futures Basis | Low — basis flat/negative in bear | Convergence | Yes but tiny |
| Conversion/Reversal | Low — ETH market efficient | Parity gap | Yes if edge > 0 |
| Funding Arb (delta-neutral) | Medium — funding negative | Carry | Near (can flip) |
| Funded Collar | Medium | Funding + VRP | Near (rally risk) |
| Iron Condor | Good — IV > RV | VRP | No (bounded loss) |
| PM Tail Fade on high-vol coin | Good — on SOL | Crowd bias | No (tail risk) |
| Protective Put + PM Bet No | Good — on SOL | Upside + PM income | Near (if sized right) |
| Risk Reversal (sell call, buy put) | Active — traders doing this now | Bearish expression | No |
| Stablecoin yield + DCA | Safe | Risk-free rate ~3.5% | Yes but low |

### What Does NOT Work in This Regime

- Cash-and-carry when basis is flat or negative (backwardation)
- Cross-exchange funding arb when funding is similar across exchanges
- PM Range arb (overround ~21% on ETH → no edge)
- Conversion on ETH/Bybit (edge ≈ 0, market too efficient)
- Bet No on ETH at far thresholds (No rate 98-99¢ → income too small)

### Composite Hand Rankings for Bearish/Sideways

```
Hand β: Conversion + PM Tail Fade        → Score 22/30 (BEST if conv edge exists)
Hand γ: Neg-Funding Collar + Credit      → Score 20/30 (default if no conv edge)
Hand α: IC + Reverse Basis + Funding     → Score 19/30 (complex, experienced only)
```

Key rule: β requires locked edge (conversion). If unavailable → use γ.
Both require regime to persist. V-shape rally = worst case for all three.

---

## 3. Real-World Efficiency Observations [Observed March 2026]

### ETH Options on Bybit (3 APR 2026 expiry, ~5 days)

```
Conversion edge across ALL strikes: very small or negative after fees.
Spot: $2,008.48 | 14 strikes scanned from K=1800 to K=2300

Best conversion edge found: ~$1-3 (before dynamic changes)
Fee impact: ~$1 per conversion (0.05% on 3 legs)
Net edge: approximately $0 after fees

Conclusion: ETH options on Bybit are EFFICIENT for near-dated expiry.
Hand β on ETH → NOT viable at this time.
Potential alternatives: BTC on Deribit (deeper liquidity), SOL (higher vol).
```

### Reversal Scan (Same Data)

```
Reversal = Short Spot + Short Put + Long Call
Best reversal edge: also near zero after fees.
Both directions (conversion and reversal) are priced efficiently.
```

### ETH PM on Polymarket (March-April 2026)

```
PM Above ("ETH above ___ on April 3"):
  2,100: Yes 30¢ / No 72¢  (Σ $1.02, overround 2%)
  2,200: Yes 13¢ / No 88¢  (Σ $1.01, overround 1%)
  2,400: Yes 4.3¢ / No 98¢ (Σ $1.023, overround 2.3%)

Key finding: at +20% from spot, No rate already 98¢ → income only 2¢
             at +5% from spot, No rate 72¢ → income 28¢ but too close

PM Range ("ETH price on April 3"):
  Σ all bracket asks = ~121¢ → overround = 21%
  → No range-only arb possible
  Tail brackets (<1500, >2400): Yes 2.8-4.6¢ → tiny income, high loss
```

### SOL vs ETH — The Volatility Gap (From Notebook Analysis)

```
WARNING: SOL and ETH data below are from DIFFERENT time periods.
SOL data: from notebook (late 2025, SOL spot ~$186)
ETH data: from Polymarket (March 2026, ETH spot ~$2,008)
SOL spot as of March 2026 is ~$83 — NOT $186.
Do NOT compare absolute numbers directly. 
The PRINCIPLE (high vol → better PM tail income) is valid,
but the specific No rates MUST be re-scanned with current data.

SOL spot ~$186 [Observed — late 2025], PM "above 400": No = 82¢ → income 18¢
  Distance: +115% | Risk/Reward: 1:4.5

ETH spot ~$2,008 [Observed — March 2026], PM "above 2,400": No = 98¢ → income 2¢
  Distance: +20% | Risk/Reward: 1:49

Same strategy type, vastly different results. [Opinion — Analytical]
SOL works because its historical vol makes +115% move "credible" to crowd.
ETH doesn't work because even +20% is seen as unlikely → No rate too high.
```

---

## 4. Funding Rate — Limitations as Building Block [Discovered]

The skill's existing content treats funding rate as a hidden option (carry trade).
This section adds critical limitations discovered from live data.

### Funding Rate is NOT Stable

```
Observed March 25, 2026: Binance BTC funding = +0.003% (neutral)
Observed March 29, 2026: Binance BTC funding = negative (bearish)

Swing from neutral to negative in 4 DAYS.
Cause: BTC dropped from $71K to $66K, triggering short positioning.
```

### Cross-Exchange Funding Arb Classification

```
Long on Exchange A (funding negative = receive) + Short on Exchange B (funding less negative = pay less)

This is NOT Lv.2 (Parity Arb).
This IS Lv.5 (Hedged Speculation).

Why: The spread between exchange funding rates is NOT locked.
It can flip at any time. There is no convergence guarantee.
Unlike dated futures basis which MUST converge at expiry,
funding spread has no expiry anchor.
```

### Funding Rate Edge Conditions [Heuristic]

| Condition | Funding Arb Viability |
|-----------|---------------------|
| Funding deeply negative + persistent | Good — collect carry |
| Funding neutral (near 0) | No edge — fees eat everything |
| Funding flip (neg → pos) | LOSS — you now pay instead of receive |
| Different across exchanges | Short-lived — bots equalize quickly |
| Extreme event (liquidation cascade) | Temporarily extreme — but dangerous |

### Rule for Using Funding in Structures

```
PERP funding rate = BONUS INCOME, never core edge.
If your structure requires perp funding to be non-negative → it is NOT non-negative.
Treat perp funding as: nice to have when negative, cost to manage when positive.

DATED futures basis = CAN be core edge.
Dated basis converges at expiry [Exact Identity].
This is fundamentally different from perp funding which has no expiry anchor.
Do NOT confuse the two.
```

---

## 5. Practical Scanner Tools & Data Sources [Operational]

### Funding Rate Monitoring

| Tool | What It Shows | URL |
|------|-------------|-----|
| CoinGlass | Funding rates all exchanges, heatmap, arb scanner | coinglass.com/FundingRate |
| Coinalyze | Aggregated funding rates + historical charts | coinalyze.net/funding-rates |
| Velo Data | Clean trend visualization over time | velodata.app |

### Funding Rate Arb Scanners

| Tool | Capability | Exchanges |
|------|-----------|-----------|
| Loris Tools | Cross-exchange arb detection, 25+ exchanges, 1h/4h/8h normalization | CEX + DEX |
| P2P.Army | Spread tracking + Telegram alerts when spread disappears | 15+ exchanges |
| ArbitrageScanner | Funding + spatial + perpetual arb screening | Major CEX |
| Binance Arb Bot | Built-in delta-neutral bot, plug-and-play | Binance only |
| OKX Smart Arb | Built-in arb system for beginners | OKX only |

### PM Market Scanning

| Platform | Best For | Assets Available |
|----------|---------|-----------------|
| Polymarket | Deepest liquidity, most altcoins, varied question types | BTC, ETH, SOL, DOGE, XRP, more |
| Kalshi | US-regulated, bracket-style | BTC, ETH |
| Myriad | Smaller markets, owned by Decrypt | BTC, ETH |
| Gemini | Range contracts, exchange-integrated | BTC, ETH, SOL, XRP, ZEC |

### Options Data

| Exchange | Best For | Assets |
|----------|---------|--------|
| Deribit | Deepest options liquidity, BTC + ETH + SOL | BTC, ETH, SOL |
| Bybit | Options + perps + spot in one place, UTA margin | BTC, ETH, SOL |
| OKX | Options + perps, good API | BTC, ETH |
| Binance | Largest spot volume for delta-neutral leg | All major |

---

## 6. PM Binary vs Linear Instruments — Scale Mismatch [Discovered — Structural Limitation]

This is a fundamental limitation discovered by testing multiple structure designs
with real ETH data (Bybit options + Polymarket, March 2026).

### The Core Problem

```
PM payoff = $0 or $1 per contract (binary)
Options/Perp/Spot payoff = −$∞ to +$∞ per unit (linear or convex)

To hedge $100 of linear loss with PM:
  Need 100+ PM contracts
  Each PM contract costs $0.05-0.90 depending on threshold
  Total PM cost = $5-90 for $100 hedge
  BUT: PM only pays at ONE specific outcome (binary)
  If price lands OUTSIDE that outcome → PM cost is pure loss
```

### Why This Cannot Be Solved [Structural Limitation]

```
Linear instrument: loss grows proportionally with price movement
PM binary: payoff is FIXED ($1) regardless of how far price moves

At S = threshold + $1:    PM pays $1, linear loss = small → PM covers ✓
At S = threshold + $100:  PM pays $1, linear loss = large → PM doesn't cover ✗
At S = threshold + $500:  PM pays $1, linear loss = huge → PM is irrelevant ✗

No amount of PM contracts fixes this because:
  More contracts → more cost → more loss when PM doesn't trigger
  → creates NEW hole elsewhere in the payoff chart
```

### PM Range "Step Function" Approximation [Heuristic — Tested]

Using multiple PM Range brackets with escalating N per bracket can
approximate a linear hedge, but:

```
Bracket near spot: Yes price expensive (20-52¢) → cost high → doesn't work
Bracket far from spot: Yes price cheap (3-12¢) → cost low → works for tails

Result: PM Range hedge works for TAILS, fails for MID-RANGE
This is true regardless of which directional instrument is used
(options, perp, spot, leveraged token)
```

### Tested Combinations and Results [Observed — March 2026 ETH data]

| Combo | Directional Leg | PM Hedge Leg | Non-neg? | Why/Why not |
|-------|----------------|-------------|----------|-------------|
| Options (strangle) + PM Range Yes (all brackets) | Long Put + Long Call | Buy Yes every bracket in hole | ❌ | Σ bracket Yes ≈ $1 = overround eats everything |
| Options (IC narrow) + PM Range Yes (1-2 brackets) | Iron Condor | Buy Yes at edges | ~78% | Works for brackets covered, not outside |
| Perp + PM Above Yes | Short Perp | Buy Yes "above X" | ❌ | PM $1 cap vs perp unlimited loss |
| Perp + PM Above No | Short Perp | Buy No "above X" | ❌ | No income too small at safe threshold |
| Micro Perp + PM Range Yes (escalating N) | Short Perp 0.01 ETH | Buy Yes multiple brackets | ~tail only | Works at far brackets, fails near spot |
| Asymmetric IC + PM Range Yes (cheap side) | Asymmetric IC | Buy Yes at cheap brackets | ~85% | Best result — matches crowd bias |

### Design Implications

```
1. PM CANNOT fully hedge linear instruments — accept bounded loss or micro-size
2. PM is best used as:
   a. Income source (Bet No) to FUND options protection — not as hedge itself
   b. Tail insurance (Range Yes at cheap brackets) — accept mid-range gap
   c. Amplifier (Range Yes at target bracket) — when conviction is high
3. For full non-negative → need LOCKED EDGE (conversion, basis) as core
   PM alone cannot create non-negative from linear instruments
4. Asymmetric design + crowd bias exploitation = best practical approach
5. High-vol assets (SOL) shrink the problem because PM tail income is higher
```

### Non-Negative Feasibility Formula for Options + PM Range [Exact Identity]

Proven via Linear Programming optimization with ETH real data (March 2026):

```
NON-NEGATIVE IS FEASIBLE only when:

  Σ(Yes prices of brackets to cover) < Options_Profit / (Options_Profit + |Options_Loss|)

Where:
  Σ Yes = sum of Yes ask prices for ALL brackets you need to cover
  Options_Profit = max credit or max profit of options structure
  Options_Loss = max loss of options structure (absolute value)
```

Example with ETH Narrow IC (credit $47.6, max loss $52.4):
```
  Threshold = 47.6 / (47.6 + 52.4) = 0.476 (47.6¢)
  Σ Yes all brackets = 94.4¢ → 94.4¢ > 47.6¢ → INFEASIBLE
  Σ Yes cheap brackets only (≤6¢) = 24.4¢ → 24.4¢ < 47.6¢ → FEASIBLE
    but leaves uncovered brackets → non-negative only ~76% of outcomes
```

Optimal N (uniform across covered brackets) [Exact Identity]:
```
  N = |Options_Loss| / (1 − Σ Yes_covered)
  PM cost = N × Σ Yes_covered
  Center payoff = Options_Profit − PM cost
  Covered bracket payoff = −|Options_Loss| + N − PM cost ≈ $0
```

### Key Finding: Feasibility Depends on Options Profit/Loss Ratio

```
If Options_Profit / Options_Width > Σ Yes → feasible
If Options_Profit / Options_Width < Σ Yes → infeasible

For IC: credit/width ratio typically 50-75% — not enough for ETH (Σyes=94%)
For OTM spread: cost/width ratio must be < (1 − Σyes) = 5.6% on ETH

→ Only VERY cheap OTM spreads could theoretically work on ETH
→ On SOL (if Σyes is lower), more structures become feasible
```

### The Practical Hierarchy [Opinion — Analytical]

```
Best non-negative:  Locked edge (conversion/basis) + PM income layer
Next best:          Asymmetric options + PM Range cheap brackets (~85% coverage)
Next:               Micro perp + PM Range escalating N (tail coverage only)
Worst:              Full PM Range coverage (overround kills it)
```

---

## 7. Novel Structure Ideas [Generated — Not Yet Validated]

These ideas emerged from combining frameworks. They require research and
paper-trading before live execution. Each idea lists which skill section
generated it.

### Idea 1: PM Calendar Spread

```
Source: PM Time Decay Behavior (pm-question-types.md §4)

Structure: 
  Buy No on far-month PM (No rate cheap, lots of time)
  Sell No on near-month PM (No rate expensive, near resolve)
  Same asset, same threshold

Edge: time decay differential — near-month No rises faster than far-month
Risk: if price approaches threshold, both No drop — but near drops faster
Classification: Lv.4 (Structured Payoff) — NOT pure arb
Status: needs liquidity check — can you actually sell PM No at fair price?
```

### Idea 2: Cross-Asset PM Vol Arb

```
Source: Asset Selection by Volatility (pm-question-types.md §3)

Observation:
  SOL PM "above +100%": No = 82¢ (income 18¢)
  ETH PM "above +100%": No = 99¢ (income 1¢)
  
  Both are "+100% from spot" but crowd prices them very differently.
  If implied vol from PM prices disagrees with options-implied vol
  → potential mispricing.

Structure:
  Compare: PM-implied probability vs Options-implied probability at same threshold
  If PM says 18% chance but options say 5% → PM overprices tail
  → Sell PM Yes (or buy PM No) at that threshold

Edge: cross-market probability disagreement
Risk: PM and options have different settlement mechanics
Classification: Lv.3-4
Status: needs systematic comparison tool — build PM vs options implied prob scanner
```

### Idea 3: Event-Driven PM Entry

```
Source: Crowd Bias & PM Entry Timing (pm-question-types.md §5)

Strategy:
  Wait for major pump or FOMO event → crowd buys Yes aggressively → No cheapens
  Buy No at depressed price (contrarian entry)
  Wait for excitement to fade → No recovers toward fair value
  Sell No for profit — no need to wait for resolve

Edge: mean-reversion of crowd sentiment
Risk: event could be start of genuine breakout → No stays cheap or drops further
Classification: Lv.5 (Hedged Speculation) unless paired with options hedge
Status: needs historical backtesting — how fast does PM No recover after events?
```

### Idea 4: Perp Funding + PM Combo (No Options Required)

```
Source: combining Funding Rate analysis + PM Tail Fade + Asset Selection

For assets WITHOUT liquid options (DOGE, memecoins):
  Leg 1: Long Spot + Short Perp (delta-neutral, collect negative funding)
  Leg 2: PM Bet No at far threshold (tail income)

  Funding = carry income (when negative)
  PM = tail fade income
  Delta-neutral = no directional risk from spot

Edge: funding carry + PM crowd bias
Risk: funding flips + PM tail event (double hit possible)
Classification: Lv.5 — both legs can reverse
Non-negative: NO — neither leg is locked

Improvement: add a condition to exit when funding approaches zero
→ reduces the "flip" risk but doesn't eliminate it

Status: needs funding persistence analysis per asset
```

---

## 8. Key Heuristics Summary [Quick Reference]

| Heuristic | Value | Source |
|-----------|-------|--------|
| PM No rate sweet spot for structures | 70-85¢ | Real data analysis |
| Touch market threshold vs Close market | Touch needs ~2× the distance | Polymarket rules comparison |
| PM time decay at very far threshold | Flat 80% of period, jumps last 3-5 days | Observed behavior |
| Asset vol threshold for PM viability | Need No ≤ 85¢ at safe threshold distance | SOL vs ETH comparison |
| Max PM contracts (non-neg sizing) | N ≤ spot_gain_at_T / PM_loss_per_contract | Payoff algebra |
| Min PM contracts (fund options) | N ≥ options_cost / PM_income_per_contract | Payoff algebra |
| Feasibility test | N_min ≤ N_max required | If violated → infeasible |
| Funding rate as core edge | NEVER for perp funding — treat as bonus only | Observed rate flips |
| Dated futures basis as core edge | YES — converges at expiry [Exact Identity] | Different from perp funding |
| Cross-exchange funding arb | Lv.5, NOT Lv.2 (perp only) | No convergence guarantee |
| ETH options on Bybit (near-dated) | Efficient — conv edge ≈ 0 | Observed March 2026 |
| PM Range overround (ETH) | ~21% — no range arb | Observed March 2026 |
| Best entry for monthly hit PM | First day of month | Time premium maximum |
| Best entry for PM No (sentiment) | During FOMO/pump events (No is cheap) | Contrarian timing |
| PM binary vs linear scale mismatch | PM $1 cap cannot hedge linear $100+ loss | Structural limitation |
| PM Range hedge coverage | Works for tails, fails for mid-range | Tested across multiple designs |
| Asymmetric design + crowd bias | Best practical approach for ETH | Tested March 2026 |
| Micro-sizing for PM hedge | Reduce directional leg to match PM $1 scale | Enables PM hedge but reduces profit |

---

## 9. Relationship to Other Skill References

| This section | Connects to | How |
|-------------|------------|-----|
| Non-Negative Principle | optimization.md (D_min) | Extends D_min to general locked-edge + income-layer framework |
| Regime Playbook | SKILL.md (Bias-First Discovery) | Applies bias framework to specific observed regime |
| Efficiency Observations | mechanism-transformations.md (Anti-patterns) | Adds #18: "Assuming edge exists without live verification" |
| Funding Limitations | payoff-primitives.md (Hidden Options) | Adds warning that funding is NOT reliable core edge |
| Novel Ideas | belief-patterns.md (Pattern H) | New patterns generated from cross-framework synthesis |
| Scale Mismatch | optimization.md (Feasibility) | Adds structural impossibility: PM binary cannot fully hedge linear |
| Scanner Tools | operational.md | Extends with specific PM and funding rate tools |
