```yaml
identity:
  name:        Weekend RWA Gap Trade
  type:        Lv.4 Structured
  mechanism:   When TradFi reference market closes (weekend/holiday), tokenized version
               continues trading with reduced participants → price drifts from fair value.
               When reference reopens → price converges. [STRUCTURAL]
  maturity:    CATALOGED

timing:
  regime:        All regimes — structural, not regime-dependent
  avoid_regime:  None — but edge magnitude varies with underlying volatility
  best_when:     High underlying volatility + major events expected over weekend

operating_range:
  floor:         0.3% gap per weekend — below this, fees + spread eat profit
  entry:         0.5% expected gap
  normal:        0.3-1.5% per weekend
  exceptional:   >2% — major geopolitical event over weekend
  metric:        % price gap (Friday close to Monday open)
  range_basis:   floor = perp round-trip fees (~0.11%) + typical spread cost (~0.1%)
                 + funding over weekend (~0.05%). total ~0.26%, rounded up to 0.3%.
  recalibrate_when: fee changes, or after 10+ weekend trades show actual distribution.

alternatives:
  when_below_floor:  platform-yield (earn yield instead of direction bet)
  when_regime_wrong: N/A — works all regimes
  simpler_version:   N/A — already simple (1 leg)

execution:
  style:         calendar-fixed — open Friday before TradFi close, close Monday after open
                 NOT multi-cycle within a weekend.
                 Repeats weekly — every weekend is a new trade.
  entry_signal:  Friday, assess: is underlying volatile? any weekend events expected?
                 if likely gap > entry → open position
  exit_signal:   Monday after TradFi reference market reopens + price converges
  position_mgmt: no management needed during weekend — set and wait.
                 direction bet: long if expecting Monday gap up, short if gap down.
                 win rate ~67% on directional match historically.
  direction_heuristics:
    - if underlying in strong trend (>5% weekly move) → bet trend continues
    - if major weekend event expected → assess event impact direction
    - if no clear signal → skip this weekend (don't force a trade)
    - historical bias: gold tends to gap in trend direction ~60-67%
    - IMPORTANT: this is Lv.4, direction is a bet not a lock.
      size accordingly — risk ≤ expected edge per trade.

verification:
  must_check:
    - TradFi market closing time (exact, timezone-aware)
    - current crypto price vs last TradFi close
    - expected weekend catalysts (economic data, geopolitical events)
    - perp funding rate (cost of holding position over weekend)
  freshness:
    - price data: real-time (Friday entry)
    - event calendar: check Friday before close
  platform_reqs: Perp or spot for the tokenized asset (e.g., XAUT, oil tokens)

costs:
  fees:          perp taker ~0.055% × 2 sides
  hidden_costs:  funding payments over weekend (2-3 periods),
                 spread cost on entry/exit
  min_profit:    $10 per weekend (1-2 legs)

risks:
  primary:       Wrong direction — gap goes opposite way → loss
  secondary:     Unexpected TradFi holiday schedule (market doesn't reopen when expected)
  kill_condition: None during weekend (can't exit). Set max loss via stop on Monday.
  what_can_go_wrong: Long XAUT Friday expecting gold gap up. Over weekend, gold sentiment
                     reverses. Monday COMEX opens down → XAUT converges down → loss.
                     Limited to ~1-2% of position. Manageable with proper sizing.
```
