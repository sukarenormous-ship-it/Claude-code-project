# Payoff Algebra, Constraint Relaxation & Worked Examples

This reference is the **"how to actually think"** guide. It provides:
1. A formal method for writing desired payoffs as equations and solving for instruments
2. A systematic approach for when the ideal structure can't be built
3. Full worked examples showing the thinking process from zero to finished structure

---

## Table of Contents

1. Payoff Algebra — Writing and Solving Payoff Equations
2. Constraint Relaxation — What to Give Up When You Can't Have Everything
3. Worked Example A — Inventing a Structure from a Belief (Bullish + Capped)
4. Worked Example B — Observing a Hidden Option and Building Around It
5. Worked Example C — When the Ideal Can't Be Built

---

## 1. Payoff Algebra

### The Core Idea

Any desired payoff can be written as a **piecewise function over regions of the state space**.
Once you have that function, you can decompose it into building blocks algebraically.

### Step 1: Write the Desired Payoff

The user says what they want. Translate it into a piecewise payoff function:

```
Example: "ผมอยากได้กำไรถ้าราคาขึ้นไปถึง 2500 แต่ไม่อยากเสียถ้ามันลง
          และถ้ามันทะลุ 2500 ไปไม่เป็นไร ได้แค่ 2500 ก็พอ"

Translate to piecewise:
  P(S) = { 0           if S < 2000  (current price)
          { S - 2000    if 2000 ≤ S ≤ 2500
          { 500         if S > 2500

Shape: zero below entry, linear upside, capped above 2500
```

### Step 2: Decompose into Known Payoff Functions

Each building block has a known payoff function. Match regions:

```
Building block payoff functions:
  Long Call(K)      = max(S - K, 0)
  Short Call(K)     = -max(S - K, 0)
  Long Put(K)       = max(K - S, 0)
  Short Put(K)      = -max(K - S, 0)
  PM Above Yes(K)   = 1 if S > K, else 0
  PM Above No(K)    = 1 if S ≤ K, else 0
  Call Spread(K1,K2) = max(S-K1, 0) - max(S-K2, 0)  = capped linear [K1, K2]
  Put Spread(K1,K2)  = max(K2-S, 0) - max(K1-S, 0)  = capped linear [K1, K2] downside
```

### Step 3: Solve the Equation

Write: Desired Payoff = Σ (quantity_i × building_block_i)

```
From the example above:
  P(S) = { 0        if S < 2000
          { S - 2000 if 2000 ≤ S ≤ 2500
          { 500      if S > 2500

This is exactly: Call Spread(2000, 2500)
  = max(S - 2000, 0) - max(S - 2500, 0)
  = { 0        if S < 2000       ✓
    { S - 2000 if 2000 ≤ S ≤ 2500 ✓
    { 500      if S > 2500       ✓

Solution: Buy 1× Call Spread (2000/2500)
```

### More Complex Decomposition

```
Example: "อยากได้ +$100 ถ้า S > 2500, +$50 ถ้า 2200 < S ≤ 2500, -$20 ถ้า S ≤ 2200"

Piecewise:
  P(S) = { -20   if S ≤ 2200
          { +50   if 2200 < S ≤ 2500
          { +100  if S > 2500

Decompose by region changes:
  At S = 2200: payoff jumps from -20 to +50 (change = +70)
  At S = 2500: payoff jumps from +50 to +100 (change = +50)
  Base level: -20 everywhere (flat cost)

  P(S) = -20 + 70 × 1(S > 2200) + 50 × 1(S > 2500)

  where 1(S > K) is the indicator function = digital call at K

Solution candidates:
  -$20 flat cost (entry premium)
  + 70 × PM Above Yes($2200)   [pays $70 if above 2200]
  + 50 × PM Above Yes($2500)   [pays $50 if above 2500]

  OR using options approximation:
  -$20 flat cost
  + 70 × tight call spread at 2200 (÷ width)
  + 50 × tight call spread at 2500 (÷ width)

  OR using regular options:
  This is roughly: Bull Call Spread(2200, 2500) + extra upside above 2500
  = Long Call(2200) - some Short Call(2500) + adjustment
```

### The Algebra Rules

| Operation | Result |
|-----------|--------|
| Long Call(K1) + Short Call(K2), K2 > K1 | Call Spread — capped linear upside [K1, K2] |
| Long Put(K2) + Short Put(K1), K2 > K1 | Put Spread — capped linear downside [K1, K2] |
| Long Call(K) + Long Put(K) | Straddle — V-shape payoff at K |
| Short Call(K) + Short Put(K) | Short Straddle — inverted V |
| Call Spread(K1,K2) + Put Spread(K3,K4), K4<K1 | Iron Condor — profit in range |
| Long Call(K1) + 2×Short Call(K2) + Long Call(K3) | Butterfly — peaked at K2 |
| N × PM Above Yes(K) | N × digital call — step function at K |
| PM Above Yes(K1) - PM Above Yes(K2) | ≈ PM Range(K1, K2) — zone payout |
| Long Spot + Long Put(K) | Protected long — floor at K |
| Long Spot + Short Call(K) | Covered call — capped upside at K |
| Long Spot + Long Put(K1) + Short Call(K2) | Collar — bounded range [K1, K2] |

### Step 4: Price the Solution

After solving algebraically:
1. Look up real prices (bid/ask) for each component
2. Calculate net cost = Σ (quantity_i × price_i) using ask for buys, bid for sells
3. Calculate net payoff in each region = gross payoff - net cost
4. Check: does net payoff still match desired shape after costs?

### Step 5: Check Feasibility

- Do all required instruments exist at the right strikes/thresholds?
- Is liquidity sufficient for each leg?
- Does settlement/resolution align across legs?
- Are there cheaper alternative decompositions?

---

## 2. Constraint Relaxation

### The Problem

Often the ideal payoff is impossible to build with available instruments.
Maybe the right PM strike doesn't exist. Maybe the option spread is too expensive.
Maybe the required digital doesn't have enough liquidity.

**Constraint relaxation** is the systematic process of deciding what to give up.

### The Relaxation Hierarchy

When you can't build the ideal structure, relax constraints in this priority order
(relax the least painful first):

| Priority | What to Relax | What You Give Up | When to Accept |
|----------|--------------|-------------------|---------------|
| 1 (first) | **Precision of boundaries** | Exact strike/threshold — use nearest available | Almost always acceptable |
| 2 | **Payoff smoothness** | Perfect piecewise shape — accept curved or stepped approximation | Usually acceptable |
| 3 | **Upside cap level** | Where upside gets capped — accept lower cap | When it significantly reduces cost |
| 4 | **Upside participation rate** | How much of the upside you keep (e.g., 70% instead of 100%) | When protection cost is high |
| 5 | **Protection level** | How deep the floor goes — accept higher max loss | When floor is very expensive |
| 6 | **Non-negative constraint** | Zero worst-case — accept bounded negative (e.g., -$50) | When non-negative is structurally impossible |
| 7 (last) | **Structure itself** | The whole approach — switch to fundamentally different design | When nothing works |

### The Relaxation Process

```
1. Write the IDEAL payoff equation
2. Try to solve with available instruments
3. If impossible → identify which constraint blocks the solution:
   - Missing instrument? → substitute or approximate
   - Too expensive? → reduce size or scope
   - Wrong strikes available? → shift boundaries
   - Liquidity insufficient? → simplify to fewer legs
4. For each blocker, try relaxation options in priority order
5. After each relaxation, re-check:
   - Is the relaxed version still better than doing nothing?
   - Is it still better than the simple alternative (just buy spot/call)?
   - Does the user accept the trade-off?
6. Present the relaxed structure with honest labeling of what was sacrificed
```

### Relaxation Algebra

You can express relaxation mathematically:

```
Ideal:    P(S) = { 0 if S < 2000, S-2000 if 2000≤S≤2500, 500 if S>2500 }
          Cost to build: $80 (too expensive for user's $50 budget)

Relaxation options:

A) Narrow the spread (relax upside cap):
   P_A(S) = Call Spread(2000, 2300)
   Cost: $45 ✓  Max profit: $300 (was $500)
   Trade-off: 40% less max upside

B) Shift strikes up (relax entry point):
   P_B(S) = Call Spread(2100, 2500)
   Cost: $48 ✓  Max profit: $400
   Trade-off: need 5% more upside before profit starts

C) Accept some downside (relax non-negative):
   P_C(S) = Long Call(2100) + PM No($2500) funding
   Cost: $50 ✓  Downside: -$50 (premium lost)
   Trade-off: not zero-loss anymore, but higher upside potential

D) Ratio approach (relax participation rate):
   P_D(S) = 0.6 × Call Spread(2000, 2500)
   Cost: $48 ✓  Max profit: $300 (60% of original)
   Trade-off: smaller gains but same shape
```

### Decision Framework for Relaxation

Ask these questions in order:

1. **What is the user's hardest constraint?**
   - "ห้ามเสียเกิน X" → protect the loss floor, sacrifice upside
   - "ต้องได้ upside เต็มๆ" → protect participation, accept more risk
   - "งบมีแค่ Y" → work within budget, scale down or simplify
   - "ต้อง automate ได้" → fewer legs, cleaner logic

2. **What is the user's softest constraint?**
   - Usually: exact strike levels, precise cap points, perfect symmetry
   - Relax these first

3. **What's the "just do the simple thing" alternative?**
   - Before proposing a complex relaxed structure, compare to:
     just buy a call, just buy spot, just do a basic spread
   - If the relaxed version is only marginally better → recommend simple

4. **Is the relaxed version still worth the complexity?**
   - Each leg adds execution risk, monitoring burden, legging risk
   - A 3-leg structure that's 10% better than a 1-leg structure may not be worth it

---

## 3. Worked Example A — Inventing a Structure from Belief

### The Prompt

User: "ETH ตอนนี้ $2000 ผมคิดว่ามันจะขึ้นไปซัก $2300-2400 ภายใน 2 สัปดาห์
      แต่ไม่น่าเกิน $2500 ผมไม่อยากเสียเงินเลยถ้ามันลง อยากได้ structure ที่
      ไม่มีในหนังสือ"

### Step 1: Extract Belief → Piecewise Payoff

```
Belief:
  Likely state:    ETH goes to $2300-2400
  Unlikely state:  ETH > $2500
  Dangerous state: ETH drops below $2000
  
Desired payoff:
  P(S) = { ≥ 0         if S ≤ 2000   (no loss on down)
          { positive    if 2000 < S ≤ 2500  (profit on up)
          { don't care  if S > 2500   (OK to cap)
```

### Step 2: Write Ideal Payoff Equation

```
Ideal: P(S) = Call Spread(2000, 2500) - Cost = 0 in all non-profitable states

For non-negative payoff everywhere:
  Need: Cost ≤ min payoff in losing region
  Call Spread cost = C
  Non-negative requires: some mechanism pays ≥ C when S ≤ 2000
```

### Step 3: Inventory Available Building Blocks

```
Available instruments (hypothetical):
  Options: Calls/Puts at $100 intervals, 2-week expiry
  PM Above: Yes/No at $2000, $2200, $2400, $2500, $2600
  PM Range: brackets $1800-2000, $2000-2200, $2200-2400, $2400-2600
  Perp: ETH-USDT perpetual swap
```

### Step 4: Design Leg by Leg

```
Leg 1 (profit in likely state):
  → Call Spread(2000, 2500), costs $120
  → Pays up to $500 in likely zone ✓

Leg 2 (make it non-negative when S ≤ 2000):
  Need something that pays ≥ $120 when S ≤ 2000
  → PM No above $2000? Pays $1 per contract if S ≤ 2000
    Price: ~$0.20 → profit $0.80 per contract
    Need 150 contracts × $0.20 = $30 cost → pays $150 when S ≤ 2000 ✓
  But wait: PM No above $2000 pays when S ≤ 2000
    same as when call spread is worthless
    → different triggers? Call spread loses value gradually, PM triggers at boundary
    → NOT same trigger — PM is binary at 2000, options are linear → OK
    
Leg 3 (fund the PM cost):
  PM cost is $30, total structure now costs $150
  → Short Call at $2500? Premium received ≈ $40
  BUT: Short Call above 2500 + PM No above 2000... 
    → different triggers ✓ (one at 2500, one at 2000)
  → Net cost now: $120 + $30 - $40 = $110
  
  Still need non-negative: PM pays $150 when S ≤ 2000, cost is $110
  → Net when S ≤ 2000: $150 - $110 = +$40 ✓ non-negative!
```

### Step 5: Verify All Scenarios

```
S = $1800 (crash):
  Call Spread = $0
  Short Call = +$40 (keep premium)
  PM No($2000) = +$120 (150 × $0.80)
  Total cost = -$150 (call spread + PM)
  Net = $0 + $40 + $120 - $150 = +$10 ✓

S = $2000 (flat):
  Call Spread = $0
  Short Call = +$40
  PM No($2000) = boundary — check resolution rules!
  ⚠️ If boundary → "higher bracket" → PM No loses → $0
  Net = $0 + $40 + $0 - $150 = -$110 ✗ NOT non-negative at boundary!
  
→ PROBLEM: boundary convention breaks non-negative at exactly $2000
```

### Step 6: Constraint Relaxation

```
Problem: non-negative fails at S = $2000 boundary
Options:
  A) Use PM No above $1950 instead (shift boundary down $50)
     → now PM pays when S ≤ $1950, not $2000
     → leaves gap at $1950-$2000 where neither PM nor Call Spread pays much
     → small loss zone (-$30 to -$50) at $1950-2000
     
  B) Accept bounded loss (relax non-negative)
     → max loss ≈ $110 at exactly $2000 (unlikely to land exactly there)
     → everywhere else: positive or near-zero
     → Practical? Probably yes — $2000 exactly is a thin probability slice
     
  C) Use lower PM boundary + smaller call spread
     → PM No above $1800, Call Spread (2100, 2500)
     → reduces cost, shifts structure, changes shape
     
Choose: Option B — accept that exactly-at-boundary is a tiny risk
Label honestly: "Bounded loss, near-non-negative, with $110 max loss at $2000 boundary"
```

### Step 7: Classify and Summarize

```
Structure: Call Spread(2000/2500) + 150×PM No($2000) + Short Call($2500)
Lv.4 — Structured Payoff Engineering
Not pure arb because: boundary convention risk + PM/options settlement mismatch
Best scenario: S = $2400 → Call Spread +$400, Short Call +$40, PM = $0, Cost $150 → Net +$290
Worst scenario: S = $2000 exactly → Net -$110
Practical: Yes — bounded loss, good R/R, 3 legs manageable
```

### What Made This "Not in a Textbook"

No textbook describes "Call Spread + PM No + Short Call" as a named strategy.
It was **invented** by:
1. Writing the desired payoff as a piecewise function
2. Identifying that the "no loss on down" requirement needs a binary payoff at the boundary
3. Recognizing PM No as the cheapest binary-like instrument for that region
4. Adding Short Call to fund the PM cost
5. Discovering the boundary convention problem through scenario analysis
6. Applying constraint relaxation to handle the edge case

---

## 4. Worked Example B — Observing a Hidden Option

### The Observation

"Funding rate on ETH perps has been consistently negative for 3 days.
Every 8 hours, shorts pay longs ~0.01%. That's free income for holding long perp."

### Step 1: Recognize the Hidden Option

```
What is this?
  Underlying: funding rate regime (positive vs negative)
  "Strike": funding = 0 (where it flips sign)
  "Expiry": continuous (8-hour intervals)
  Shape: when funding < 0 → long perp receives income (like selling a put on funding)
         when funding > 0 → long perp pays (like being short a call on funding)
  
This is: a carry trade where holding long perp = short straddle on funding rate
  You earn income in stable regime, but funding can flip against you
```

### Step 2: Characterize as Building Block

```
New building block: "Negative Funding Carry"
  Payoff: +|funding rate| × position size × time, while funding stays negative
  Risk: funding flips positive → you start paying
  Duration: unknown — regime-dependent
  Cost: price exposure on the perp itself (can be hedged)
  
Interesting property: the carry is directionally opposed to the price risk
  Negative funding usually means market is bearish → long perp is contrarian
  So you're getting paid to hold a contrarian position
```

### Step 3: Build a Structure Around It

```
Observation: can we separate the carry income from the price risk?

Design:
  Leg 1: Long Perp (captures negative funding)
  Leg 2: Long Put at current price (hedges downside)
  Leg 3: Short Call OTM (partially funds the put)
  
This creates: a carry trade with bounded risk (collar around the perp)
  Income: funding payments (continuous)
  Protection: put floor
  Cost: call premium offsets put premium; upside is capped
  
Payoff:
  S drops: put protects; funding may flip (double risk) → check correlation!
  S flat: earn funding; options decay (theta eats both legs) → net depends on rates
  S rises: capped by short call; funding may flip positive → carry stops
```

### Step 4: Reality Check

```
Key risk: funding rate is correlated with price movement
  When price crashes → funding may go very negative → MORE carry income (good)
  When price rises → funding may go positive → carry stops or reverses (bad)
  
This means: the hidden option (funding carry) is partially correlated with
the price hedge. The put and the funding both benefit from downside.
→ Not a pure hedge — more like amplification on downside, dampening on upside.

Constraint relaxation needed:
  Accept that this is Lv.5 (Hedged Speculation), not Level 3
  Accept that funding can flip and carry can stop
  Accept that options premium + carry may not fully offset
  
Worth it? Only if funding has been sufficiently negative for long enough
to justify the options cost. Calculate breakeven: 
  options net cost ÷ daily funding income = days to breakeven
```

---

## 5. Proven Structural Impossibility

"Unlimited upside + non-negative everywhere" with discrete instruments is impossible
because the call's cost always creates a dead zone between strike and breakeven.

The only ways to eliminate the dead zone:
1. Zero-cost entry (very specific pricing conditions — rare)
2. Continuous funding subsidy (regime-dependent — unreliable)
3. Cap the upside (convert to spread → makes D_min test possible)

This is a fundamental trade-off. Recognize it quickly and pivot to constraint relaxation.

---

## Summary: The Three Tools Together

| Tool | When to use | What it does |
|------|------------|-------------|
| **Payoff Algebra** | Every time you design a structure | Translates belief into equation, decomposes into instruments, verifies all regions |
| **Constraint Relaxation** | When ideal structure can't be built | Systematically identifies what to sacrifice, in priority order, with honest labeling |
| **Worked Examples** | When learning or explaining | Shows the full thinking process — including wrong turns and dead ends |

The combination makes creative structure design **systematic rather than guesswork**:
1. Write the ideal → try to solve → if impossible → relax → solve again → verify
2. At every step, the math tells you exactly what's possible and what's not
3. When you hit a structural impossibility, you can prove it and explain why
4. The user gets an honest assessment with clear alternatives, not just "it can't be done"
