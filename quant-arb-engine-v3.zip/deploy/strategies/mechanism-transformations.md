# Mechanism Transformations, Anti-Patterns & Search Engine

## Table of Contents

1. Transformation Library (instrument, geometry, regime, time, financing, simplification)
2. Anti-Pattern Library (17 known failure modes)
3. Systematic Search & Scoring Engine
4. Market-Spec Template

---

This reference provides three capabilities for systematic strategy invention:
1. **Transformation library** — rules for morphing one structure into another
2. **Anti-pattern memory** — known failure modes to check before deploying
3. **Search & scoring engine** — systematic method to generate, evaluate, and rank candidates

---

## 1. Transformation Library

A "transformation" takes an existing structure and produces a new one by changing
one dimension while preserving others. Applying multiple transformations in sequence
produces structures that may not exist in any textbook.

### Instrument Substitution Transforms

Replace one building block with a functionally similar one from a different market
or instrument class. Each substitution changes cost, execution, and risk profile.

| Transform | From → To | What changes | When to use |
|-----------|----------|-------------|-------------|
| Binary ↔ Vertical | PM Above ↔ Tight Call Spread ÷ width | PM = native digital (cheaper if liquid); Vertical = smoother near boundary | PM unavailable or illiquid → use vertical; Options expensive → use PM [Heuristic] |
| Spot ↔ Future ↔ Perp ↔ Synthetic | Swap the linear exposure leg | Carry/funding cost, settlement, margin | Match settlement to other legs; minimize funding drag [Contract-specific] |
| Call ↔ Synthetic Call | Listed Call ↔ (Stock + Put - PV(K)) | Execution complexity, legging risk | Listed is cheaper to execute if liquid; Synthetic if call is overpriced [Heuristic] |
| Put ↔ Synthetic Put | Listed Put ↔ (-Stock + Call + PV(K)) | Same as above | Same logic |
| PM Above ↔ PM Range | Boundary claim ↔ Zone claim | Above = one-sided; Range = two-sided | Above for hedge/repair; Range for landing-zone boost only [Heuristic] |
| Credit Spread ↔ Debit Spread | Bull Put Spread ↔ Bull Call Spread | Cash flow direction, margin | Credit preferred when selling premium; Debit when buying convexity [Heuristic] |
| Long Option ↔ Short Option + Hedge | Buy protection ↔ Sell + manage risk | Premium direction, theta sign, tail exposure | Sell when IV is rich; Buy when IV is cheap [Heuristic] |
| PM Buy No ↔ PM Sell Yes | Same payoff (profit when event doesn't happen) | Buy No = pay upfront, collect $1 if win; Sell Yes = receive premium, pay $1 if lose | Sell Yes when you want immediate cash flow; Buy No when you want cleaner position. Check liquidity on both sides. |

### Geometry Transforms

Change the shape of the payoff while keeping the instrument class the same.

| Transform | What it does | Effect on payoff | When to use |
|-----------|-------------|-----------------|-------------|
| Widen strikes | Increase K2 - K1 in spread | More upside potential, higher cost, larger loss zone | When budget allows and want more range |
| Narrow strikes | Decrease K2 - K1 | Less upside, lower cost, smaller loss zone | When budget is tight |
| Shift strikes up/down | Move entire structure higher/lower | Changes breakeven, changes which states are profitable | When probability mass shifts |
| Add wing | Add another option leg outside existing structure | Caps or extends exposure in tail | When tail risk needs management |
| Remove wing | Simplify by dropping an outer leg | Saves cost but exposes tail | When tail probability is negligible |
| Stack (add quantity) | Increase N in same structure | Linear scaling of P/L, same shape | When want more exposure to same view |
| Ratio adjustment | Change leg quantities to non-1:1 | Skews payoff shape, creates leverage in one direction | When conviction is asymmetric |

### Regime Transforms

Flip the directional or volatility assumption of a structure.

| Transform | What it does | Example |
|-----------|-------------|---------|
| Invert direction | Bullish → Bearish (mirror) | Bull Call Spread → Bear Put Spread |
| **Mirror warning** | Before inverting, verify: (1) required building blocks exist in opposite direction, (2) crowd bias is favorable in opposite direction, (3) PM thresholds available at needed distance. If any answer is no → mirror is infeasible, design from scratch instead. |
| **PM asymmetry — why mirrors often fail** | PM markets are structurally asymmetric: (1) Questions are framed as "Above X?" — no native "Below X?" format, (2) Crypto crowd bias defaults to bullish — PM No above far strike is cheap (contrarian income) but bearish equivalent is expensive, (3) Threshold availability is skewed upward — many far-above thresholds, few far-below. Result: bullish PM structures have more building blocks than bearish. For bearish regimes, use crowd's residual bullish bias instead — e.g., sell calls (crowd overpays hope) or buy PM No above far strike to fund bearish options. |
| Reverse regime | Trending → Mean-reverting | Directional + PM overlay → Iron Condor + PM Range |
| Flip vol view | Long vol → Short vol | Long Straddle → Short Straddle (or Iron Condor) |
| Swap hedge/core | What was core becomes hedge, vice versa | PM becomes core, options become hedge |
| Opposite-regime mirror | "What if I'm wrong?" | If bullish structure → create bearish version with same cost/risk profile |

### Time Transforms

Change the temporal dimension of a structure.

| Transform | What it does | When to use |
|-----------|-------------|-------------|
| Shift expiry | Move to earlier or later expiration | Match with PM resolution date, or adjust theta profile |
| Calendar spread | Add time dimension (long far, short near) | When term structure is steep and you want theta differential |
| Roll | Close near-dated, open far-dated | When approaching expiry and want to maintain position |
| Match maturity | Align all legs to same resolution date | Reduce maturity mismatch risk — almost always correct |

### Funding / Financing Transforms

Change how the structure is paid for.

| Transform | What it does | When to use |
|-----------|-------------|-------------|
| Self-financing | Add a short leg to fund the long legs | When net premium budget = 0 |
| Partial financing | Sell partial premium to reduce but not eliminate cost | When want some but not full protection |
| Collar construction | Add floor + cap around core position | When want bounded risk/reward |
| PM funding | Use PM leg income to subsidize options cost | When PM leg is cheap relative to options |

### Simplification Transforms — APPLY THESE FIRST

Simplification transforms reduce complexity. Run these before adding more legs.

| Transform | What it does | When to use |
|-----------|-------------|-------------|
| Remove redundant leg | Drop a leg that doesn't improve worst-case or EV | When leg doesn't improve worst-case or EV (pre-screen step 4) |
| Widen spread to replace overlay | Instead of adding PM No, widen the vertical spread | When spread width increase costs less than PM overlay |
| Replace multi-leg with single option | If combined payoff ≈ single call/put shape → use the single option | When complexity tax > edge improvement |
| Merge same-market legs | Combine two options legs into one spread | When they're effectively a spread already |
| Drop the PM, keep options only | If PM leg adds <5% edge improvement after executable cost | When PM executable cost is high |
| Replace cross-market with same-market | Use vertical spread instead of PM binary for boundary | When options liquidity is better than PM |

### Composition Rule

**Multiple transforms can be chained.** Example of invention:

```
Start: Bull Call Spread (textbook)
→ Apply "Binary ↔ Vertical": replace Short Call with PM No
    Result: Long Call + PM No (cross-market structure, not in textbook)
→ Apply "Self-financing": add Short Call at higher strike to fund
    Result: Long Call(K1) + Short Call(K3) + PM No(K2) (3-leg hybrid)
→ Apply "Shift strikes": move PM threshold to match belief boundary
    Result: Novel structure tuned to specific belief
→ Check trigger correlation: K1 ≠ K2 ≠ K3 → different triggers → OK
→ Check same-trigger: none share boundary → valid hedge/repair relationship
```

Each step produces a legitimate new structure. The transformation trail documents
WHY the structure looks the way it does — not just WHAT it is.

---

## 2. Anti-Pattern Library (Failure Memory)

These are known failure modes discovered through analysis and testing.
Check every candidate structure against this list before proceeding.

### Structural Anti-Patterns

| # | Anti-Pattern | What Goes Wrong | How to Detect | Fix |
|---|-------------|----------------|--------------|-----|
| 1 | **Same trigger ≠ hedge** | Two legs both profit or both lose on same event → amplification, not hedge | Check: if state X occurs, do both legs move in same direction? | Separate triggers: ensure legs respond to different state boundaries |
| 2 | **No-overlay cliff** | Adding PM No creates non-negative in most states but a cliff (sharp loss) at the PM boundary | Check payoff at S = K_PM ± ε — is there a discontinuity? | Accept bounded loss at boundary (constraint relaxation) or shift PM threshold away from critical zone |
| 3 | **Maturity mismatch illusion** | Structure "looks" hedged but legs expire at different times → window of naked exposure | Check: do all legs resolve simultaneously? If not, what's the exposure in the gap? | Match maturities or explicitly price/accept the mismatch window risk |
| 4 | **Dead zone** | Between option strike and breakeven, payoff is negative. Looks non-negative on paper because you ignore the cost region | Calculate breakeven = K + total_cost. Check payoff in [K, breakeven] explicitly | Accept dead zone (constraint relaxation) or fund it with additional income leg |
| 5 | **PM cheaper ≠ PM better** | PM may have lower ticket price than options but worse payoff shape (binary vs linear) for the state you're hedging | Compare payoff PER DOLLAR of cost across the relevant state range, not just ticket price | Use PM for boundary/threshold hedging; use options for gradual/continuous hedging |
| 6 | **Cost-eaten structure** | Sum of all PM bracket ask prices >> $1 → every combination is structurally losing | Check Σ Ask(all brackets) > $1 and the magnitude of overage | Use PM only where executable cost is low (typically Above pairs, not Range ladders) [Heuristic] |
| 7 | **Phantom edge from mid-price** | Edge appears when using mid-prices but vanishes at executable (bid/ask) prices | Recalculate edge using ask for buys, bid for sells | Always use executable prices in final evaluation |
| 8 | **Legging risk eats edge** | Theoretical edge exists but multi-leg execution means you can't fill simultaneously → slippage during entry eliminates edge | Estimate legging cost: max price move during expected fill time × delta exposure of unfilled legs | Simplify structure (fewer legs) or ensure edge >> legging cost |
| 9 | **Funding rate correlation trap** | Using funding income to finance a structure, but funding flips when price moves against you → double hit | Check: is funding correlated with the adverse scenario? | Don't count on funding as reliable income source across regimes — treat as bonus, not structural leg |
| 10 | **Resolution wording trap** | PM resolution says "above at close" but you hedge using intraday price → PM doesn't trigger even though price touched level | Read exact resolution wording, reference source, and timestamp | Match hedge instrument to PM resolution mechanics exactly |
| 11 | **Normalization error** | Option multiplier = 1 ETH but PM contract = 0.01 ETH → hedge ratio is 100:1, not 1:1 | Check lot sizes and multipliers across all venues | Normalize all positions to same unit (e.g., per-ETH exposure) before calculating hedge ratios |
| 12 | **Boundary convention trap** | PM says "above $2000" but boundary goes to higher bracket → at exactly $2000, PM No wins, not PM Yes | Check boundary convention for each PM product | Test payoff at boundary value explicitly. Don't assume ">" vs "≥" |
| 13 | **Disguised simple structure** | Novel 3-leg structure turns out to have same payoff shape as a simple bull spread but worse execution | Draw the combined payoff and compare to basic structures visually | If payoff shape matches a simpler named strategy → use the simpler one |
| 14 | **Overlay-for-show** | Adding a PM overlay or extra leg makes the payoff chart look better but the edge improvement after executable cost is negligible | Calculate: edge improvement from overlay minus overlay executable cost minus complexity tax | If net improvement < 5% of structure cost → remove the overlay |
| 15 | **Over-engineering bias** | AI tends to prefer complex multi-leg structures because they demonstrate more "thinking" even when simpler is better | Always present the simple baseline alongside the complex candidate with explicit comparison | If complex version doesn't clearly dominate → recommend simple |
| 16 | **Dynamic edge treated as static** | Conversion basis, funding rate, PM pricing change significantly within hours — treating them as fixed leads to false edge | Check: is this edge measured at a point in time or stable? | If dynamic → need real-time scanning, not one-time analysis |
| 17 | **Long call default for non-directional** | Recommending long call when user has no directional conviction — theta decay eats the premium | Check: does user have strong directional view? | If no directional view → credit spread or conversion is better than long call [Heuristic] |

### When to Check Which Anti-Pattern

| Stage | Check these anti-patterns |
|-------|--------------------------|
| After composing legs | #1 (same trigger), #5 (PM cheaper ≠ better), #11 (normalization) |
| After calculating payoff | #2 (cliff), #4 (dead zone), #7 (phantom edge) |
| After choosing execution | #3 (maturity mismatch), #8 (legging risk), #10 (resolution wording), #12 (boundary convention) |
| After optimizing | #6 (cost-eaten), #9 (funding correlation) |

---

## 3. Systematic Search & Scoring Engine

When inventing new structures, don't evaluate one candidate at a time.
Generate multiple candidates systematically, then score and rank them.

### Generation Phase: Candidate Factory

Starting from a belief + desired payoff shape, generate candidates by applying
transformation sequences:

```
Base structure (from belief pattern or Leg1→Leg2→Leg3 workflow)
├── Apply: instrument substitution (3-5 variants)
│   ├── Variant A: original instruments
│   ├── Variant B: replace PM with vertical
│   ├── Variant C: replace options with PM
│   ├── Variant D: replace spot with perp
│   └── Variant E: synthetic replacement
├── Apply: geometry transform (2-3 per variant)
│   ├── Narrow strikes
│   ├── Widen strikes
│   └── Shift strikes
├── Apply: financing transform (2 per variant)
│   ├── Self-financing version
│   └── Partially funded version
└── Apply: regime transform (1-2 per variant)
    ├── Opposite-regime mirror
    └── Vol-neutral version

Typical: 15-30 raw candidates before filtering
```

### Filtering Phase: Quick Reject

Before detailed scoring, quickly eliminate candidates that fail hard constraints:

| Quick Reject Test | Kill if: |
|------------------|----------|
| Anti-pattern #1 check | Same trigger legs found → not a hedge |
| Instrument existence | Required instrument doesn't exist on venue |
| Executable cost > budget | Total ask-side cost exceeds user's capital |
| Max loss > tolerance | Worst-case loss exceeds user's stated limit |
| Leg count > complexity budget | More legs than user can monitor/execute |
| Settlement mismatch severity | Critical mismatch with no bound → reject |

Typical: 50-70% of candidates eliminated here.

### Scoring Phase: Multi-Criteria Evaluation

Score surviving candidates on these dimensions (1-5 each):

| # | Dimension | What it measures | Weight guidance |
|---|-----------|-----------------|----------------|
| 1 | **Worst-case net payoff** | What happens if everything goes wrong? | High weight — survival matters most |
| 2 | **Expected value (EV)** | Probability-weighted average payoff across scenarios | High weight — must be positive after costs |
| 3 | **Fillability** | Can all legs actually be filled at executable prices? | High weight — unfillable = fantasy |
| 4 | **Simplicity** | Number of legs, clarity of logic, monitoring burden | Medium weight — fewer legs = less can go wrong |
| 5 | **Mismatch risk** | Settlement, resolver, timing, boundary mismatches across legs | Medium weight — mismatch = hidden tail risk |
| 6 | **Scanner readiness** | Can a scanner detect this opportunity automatically? | Low-Medium — matters if user wants automation |
| 7 | **Edge robustness** | Does edge survive under different scenarios/assumptions? | Medium weight — fragile edge = unreliable |
| 8 | **Capital efficiency** | Edge per dollar of capital locked up | Low-Medium — matters for scaling |

### Scoring Process

For each surviving candidate:

```
1. Calculate exact payoff in each scenario using payoff primitives
   (exact identities, executable prices, fees included)
   
2. Run anti-pattern checklist (all 17 items)
   Flag any that trigger — don't auto-reject, but note the risk

3. Score 1-5 on each dimension:
   5 = excellent (top-tier, no concerns)
   4 = good (minor concerns, acceptable)
   3 = adequate (notable concerns, proceed with caution)
   2 = weak (significant issues, likely not worth it)
   1 = failing (fundamental problem, reject unless nothing better exists)

4. Calculate weighted score (user can adjust weights based on priorities)

5. Rank candidates by total score
```

### Selection Phase: Choose Best Practical

From the ranked list:

1. **Best overall** — highest total weighted score
2. **Best worst-case** — highest score on dimension #1
3. **Simplest viable** — highest simplicity score among those with positive EV
4. **Most automatable** — highest scanner readiness among those with positive EV

Present top 2-3 candidates with their trade-offs.

**Final check:** Compare each finalist to "just do the simple thing" (buy a call,
sell a put, take a spot position). If the complex structure is only marginally better
than the simple alternative, recommend the simple one.

### Scoring Output Template

```
┌───────────────────────────────────────────────────┐
│ CANDIDATE SCORING                                 │
├──────────┬────────┬────────┬────────┬─────────────┤
│Dimension │Cand. A │Cand. B │Cand. C │Simple Alt   │
├──────────┼────────┼────────┼────────┼─────────────┤
│Worst-case│        │        │        │             │
│EV        │        │        │        │             │
│Fillable  │        │        │        │             │
│Simple    │        │        │        │             │
│Mismatch  │        │        │        │             │
│Scanner   │        │        │        │             │
│Robust    │        │        │        │             │
│Capital   │        │        │        │             │
├──────────┼────────┼────────┼────────┼─────────────┤
│TOTAL     │        │        │        │             │
│Anti-pats │        │        │        │             │
│Verdict   │        │        │        │             │
└──────────┴────────┴────────┴────────┴─────────────┘
```

---

## 4. Market-Spec Quick Reference [Contract-specific]

This section should be populated with exact venue specifications.
Below is the template — fill in for each venue you trade on.

### Template Per Venue

```
Venue: [name]
Product: [type — options / PM Above / PM Range / perp / future]
Underlying: [what asset]
Settlement: [cash / physical / binary]
Settlement source: [which price feed, exact specification]
Settlement time: [exact timestamp and timezone]
Boundary convention: [> K / ≥ K / close above K / etc.]
Multiplier: [contract size in units of underlying]
Fee structure: [maker/taker/settlement fees]
Min tick: [minimum price increment]
Expiry/resolution dates: [available dates]
Exercise style: [European / American / N/A for PM]
Margin requirement: [if applicable]
Order book type: [CLOB / RFQ / AMM]
Typical spread: [observed bid-ask spread range]
Typical depth: [observed order book depth]
```

### Why This Matters

Without venue-specific data, the AI is forced to assume or guess:
- Contract sizes (→ wrong hedge ratios)
- Settlement mechanics (→ wrong payoff calculations)
- Fee structures (→ wrong edge calculations)
- Boundary conventions (→ wrong digital/binary pricing)

The more venues filled in here, the better the AI can invent
structures that actually work in practice.

---

## Summary: How These Three Tools Work Together

```
Transformation Library → generates candidate structures
Anti-Pattern Library → filters out known failure modes  
Search & Scoring → ranks survivors and selects the best

The cycle:
  Belief → Payoff Algebra → Candidate Factory (transformations)
  → Quick Reject (anti-patterns) → Score → Select → Verify
  → If nothing good enough → apply more transformations → repeat
```

This turns strategy invention from "have a clever idea" into
"systematically explore the space of possible structures."
