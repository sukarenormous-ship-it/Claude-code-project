```yaml
identity:
  name:        Platform Yield Capture
  type:        Lv.4 Structured (platform risk, not market risk)
  mechanism:   Platform subsidizes yield to attract users — via promo rates,
               Earn products, or lending pool mechanics. [PLATFORM]
               Edge = subsidy. Disappears when promo ends.
  maturity:    CATALOGED

timing:
  regime:        All regimes — but rates typically higher during bear (platform desperate)
  avoid_regime:  None — always check, always available
  best_when:     Promotional campaigns (Earn Carnival, launch bonuses)

operating_range:
  floor:         below risk-free rate (~4% APY) — not worth platform risk
  entry:         above risk-free rate
  normal:        4-8% APY (non-promo periods)
  exceptional:   >10% APY (promotional)
  metric:        APY (as stated by platform)
  range_basis:   floor = risk-free rate. taking platform risk for less than risk-free is irrational.
                 no entry buffer needed — any amount above floor is pure platform premium.
  recalibrate_when: risk-free rate changes (Fed rate decisions), or platform risk profile changes.

alternatives:
  when_below_floor:  hold stablecoin off-exchange (risk-free rate)
  when_regime_wrong: N/A — always available
  simpler_version:   N/A — this IS the simplest

execution:
  style:         continuous — deposit and hold while rate is favorable
                 NOT cycle-based. No entry/exit timing needed.
                 Reassess when rate changes or promo ends.
  entry_signal:  rate > risk-free rate + platform risk acceptable
  exit_signal:   rate drops below floor OR platform risk increases
  position_mgmt: check rate daily (can change without notice).
                 compare across platforms periodically.
                 diversify across platforms if size is large.

verification:
  must_check:
    - actual APR (not headline — check after fees, tiers, caps)
    - cap per user (may limit effective size)
    - lock period / withdrawal delay
    - promo duration and terms
    - is deposited asset usable as collateral?
  freshness:
    - APR: check daily (changes without notice)
    - terms: check before every new deposit
  platform_reqs: Earn/Savings product available for target asset.

costs:
  fees:          usually none for Earn deposits
  hidden_costs:  opportunity cost of locked capital,
                 withdrawal delay (may miss other opportunities),
                 cap per user limits total earnings
  min_profit:    none — if rate > floor, it's worth doing regardless of $ amount

risks:
  primary:       Promo ends → rate drops to 3-5% without notice
  secondary:     Platform insolvency → total loss of deposit
  tertiary:      Terms change mid-deposit (added lock period, changed withdrawal rules)
  kill_condition: Any credible platform insolvency signal → withdraw immediately
  what_can_go_wrong: Deposit at 12% APR promo. Promo ends after 2 weeks.
                     Rate drops to 3%. Capital was locked, missed a 15% basis trade.
                     Net: earned 2 weeks of 12% (~0.46%) instead of 15% basis.
```
