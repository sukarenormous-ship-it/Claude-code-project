# Post-Deployment Test Scenarios

ใช้ทดสอบ skill หลัง deploy — เปิด conversation ใหม่แต่ละ test

---

## Test 1: Basic Scan (Default Entry → Full Flow)

**Prompt:** "ช่วงนี้มีอะไรทำได้บ้าง"

**Expected behavior:**
- AI triggers quant-arb-engine skill
- AI runs Cold Start Protocol (web search for regime signals)
- AI asks for 2-3 screenshots (not 6+)
- After data: classifies regime using timing.md thresholds (not guessing)
- Shows threshold check explicitly (e.g., "funding -0.002% within ±0.005% = neutral")
- Presents results with Opportunity Card format
- Includes baseline comparison
- Shows WATCHLIST items after recommendations

**Red flags:**
- ❌ AI skips threshold check, just says "bear" without numbers
- ❌ AI asks for >3 screenshots before showing any analysis
- ❌ AI presents without baseline comparison
- ❌ AI claims Lv.3+ is "arbitrage"

---

## Test 2: Belief Entry (Skip to Stage 4)

**Prompt:** "BTC ไม่น่าจะเกิน 120K ใน 3 เดือนนี้"

**Expected behavior:**
- AI recognizes as belief → skips Stage 1-3
- AI goes directly to Stage 4 CREATE
- AI translates belief → piecewise payoff
- AI composes structure (likely: sell call above 120K, or PM No above 120K)
- AI verifies via Stage 5 gates
- AI presents with honest Lv. classification
- AI shows baseline comparison

**Red flags:**
- ❌ AI starts with Stage 1 OBSERVE (wrong entry)
- ❌ AI just agrees with belief without building structure
- ❌ AI builds structure without verifying gates

---

## Test 3: Arb Request → Honest Answer

**Prompt:** "มี arb อะไรไหมตอนนี้"

**Expected behavior:**
- AI scans for Lv.1-2 (conversion, box spread, cross-exchange)
- If none found: says "No pure arb (Lv.1-2) available" honestly
- Shows best available at Lv.3-4 with honest label
- States conditions for arb to become viable
- Does NOT call Lv.3+ "arbitrage"

**Red flags:**
- ❌ AI calls funding harvest "arbitrage"
- ❌ AI presents Lv.4 strategy as recommendation without saying "not arb"
- ❌ AI gives up without showing best available alternatives

---

## Test 4: XAUT Specific (Baseline Scope Test)

**Prompt:** "XAUT ทำอะไรได้บ้าง"

**Expected behavior:**
- AI focuses on XAUT (specific asset)
- Baseline = XAUT option (same asset), NOT cross-asset
- If earn-hedge considered: checks collateral status
- If weekend-gap relevant: mentions Friday timing
- Compares candidate vs XAUT-specific baseline

**Red flags:**
- ❌ AI uses USDT Earn as baseline (cross-asset when asked specific)
- ❌ AI skips earn-hedge collateral check
- ❌ AI presents earn-hedge without net formula showing both branches

---

## Test 5: Education → Scan Transition

**Prompt:** "spread arb คืออะไร"

**Expected behavior:**
- AI explains using taxonomy + building blocks
- AI offers: "Want me to scan for this opportunity right now?"
- If user says yes: AI enters Default flow at Stage 1

**Red flags:**
- ❌ AI starts scanning without explaining first
- ❌ AI explains but never offers to scan
- ❌ AI asks for data before offering to scan

---

## Test 6: Bot Design (Bot Entry Path)

**Prompt:** "อยากทำ scanner สำหรับ funding arb"

**Expected behavior:**
- AI first verifies strategy via Stage 4-5
- AI checks funding harvest profile
- THEN designs scanner (reads execution-rules + operational)
- Scanner has all 13 required fields from operational.md
- AI warns about funding instability

**Red flags:**
- ❌ AI designs scanner immediately without verifying strategy
- ❌ AI skips funding direction/instability warnings
- ❌ Scanner missing key fields (freshness filter, reject conditions)

---

## Test 7: Non-Negative Claim Check

**Prompt:** "ออกแบบ structure ที่ไม่ขาดทุนเลยได้ไหม"

**Expected behavior:**
- AI reads real-world-discoveries §1 (Non-Negative Design Principle)
- AI explains: needs LOCKED EDGE as core (conversion, basis, box spread)
- AI explains: PM alone cannot create non-negative from linear instruments
- If no locked edge available: honestly says bounded loss is the realistic option
- AI does NOT claim funding carry or PM income makes structure "non-negative"

**Red flags:**
- ❌ AI proposes structure with funding as core edge and calls it non-negative
- ❌ AI ignores scale mismatch between PM ($1 cap) and linear instruments
- ❌ AI doesn't check for locked edge first
