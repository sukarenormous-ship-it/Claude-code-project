# PM Question Types, Asset Selection & Time Decay

## Table of Contents

1. PM Question Type Taxonomy
2. Question Type Selection for Structures
3. Asset Selection by Volatility
4. PM Time Decay Behavior
5. Crowd Bias & PM Entry Timing
6. Maturity Mismatch Strategies for PM + Options
7. Platform Reference

---

Understanding PM question types is critical for cross-market structure design.
Different question types create fundamentally different payoff functions,
time decay profiles, and risk characteristics. Choosing the wrong question type
can invalidate an otherwise sound structure.

---

## 1. PM Question Type Taxonomy

PM platforms (Polymarket, Kalshi, Myriad, Gemini) offer several question formats.
Each format has a different resolution mechanic that directly affects No payoff.

### Type A: "Above ___ on [date]?" (Close Market) [Contract-specific]

```
Resolution: price at close (or specific timestamp) on specified date
No wins if: price < threshold at resolution time
Payoff: binary — $1 if No wins, $0 if No loses
```

**Characteristics:**
- Intraday spikes do NOT affect resolution
- Only the final price matters
- No rate tends to be HIGHER (income LOWER) because it's safer
- Typical timeframe: 1 day to 1 week
- Platforms: Polymarket ("above ___ on [date]"), Kalshi

**For structure design:** Safest PM type for Bet No. Allows tighter threshold
(closer to spot) because spikes are ignored. Match with options that expire
on or after the resolution date.

### Type B: "What price will [asset] hit in [month]?" (Touch Market) [Contract-specific]

```
Resolution: immediately resolves Yes if price TOUCHES threshold at any point
No wins if: price NEVER touches threshold during entire period
Payoff: binary — $1 if No wins, $0 if No loses
```

**Characteristics:**
- A 1-second spike to threshold = No loses instantly
- Must survive EVERY moment of the entire period
- No rate tends to be LOWER (income HIGHER) because it's riskier
- Typical timeframe: 1 month
- Platforms: Polymarket ("what price will hit in [month]")

**For structure design:** Higher income per contract but requires threshold
MUCH farther from spot than Close markets. Rule of thumb: threshold should be
at least 2× the distance you'd use for a Close market [Heuristic].

**Critical warning:** Flash crashes, exchange glitches, and wick spikes can
trigger resolution even if price immediately reverses. This is a feature,
not a bug — it's in the rules.

### Type C: "All time high by [date]?" (Touch + Long-dated) [Contract-specific]

```
Resolution: immediately resolves Yes if price reaches ATH at any point before date
No wins if: price never reaches ATH before deadline
Payoff: binary — $1 if No wins, $0 if No loses
```

**Characteristics:**
- Threshold = ATH (often very far from current spot in bear markets)
- Long timeframe (months to 1 year) → capital lock
- No rate moderate (e.g., 85-90¢) because threshold is far but time is long
- Platforms: Polymarket

**For structure design:** Can be used with rolling short-dated options.
PM position is held long-term while options are rolled monthly.
Key risk: total roll cost over PM lifetime may exceed PM income.

### Type D: "Price on [date]?" (Range/Bracket Market) [Contract-specific]

```
Resolution: which bracket the close price falls in
No wins if: price does NOT close in specified bracket
Payoff: binary per bracket
```

**Characteristics:**
- Multiple brackets (e.g., $2,000-$2,100, $2,100-$2,200, etc.)
- Σ bracket ask prices >> $1 (high overround) → PM-only arb impossible
- No on a single bracket = No on "landing in this zone"
- Platforms: Polymarket, Kalshi, Gemini

**For structure design:** Generally NOT useful for Bet No at far thresholds.
High overround eats income. Use Type A or B instead for boundary claims.

### Type E: "Hit $X or $Y first?" (Race/Directional Market)

```
Resolution: whichever price is touched first wins
No payoff: N/A — this is a directional bet, not a threshold claim
```

**For structure design:** NOT compatible with Protective Put + PM Bet No.
Use only for sentiment reading, not as a structure leg.

### Type F: "Implied Volatility hit ___?" (Vol Market)

```
Resolution: based on IV index, not price
```

**For structure design:** Cannot be hedged with spot/put. Use only for
vol-specific strategies. Can inform timing of options purchases but
not as a direct PM leg in a price-based structure.

---

## 2. Question Type Selection for Structures

| Structure goal | Best PM type | Why |
|---------------|-------------|-----|
| Protective Put + PM income | Type A (Close) or B (Touch) | Binary payoff matches put protection |
| Maximum PM income per contract | Type B (Touch monthly) | No rate lower → income higher |
| Maximum safety | Type A (Close daily/weekly) | Spikes ignored |
| Long-term tail fade | Type C (ATH yearly) | Threshold very far |
| Range landing boost | Type D (Bracket) | Zone claim |

**Decision flow (follows the master workflow in cross-instrument-optimization.md §7):**
After asset is selected (Step 1 of master workflow), choose question type:
1. Do you need income to fund options? → Type B (most income) or A (safest)
2. Can you match options expiry? → Type A weekly or B monthly
3. Is threshold far enough for Type B? → If not, use Type A
4. Capital lock acceptable? → If long-term OK, consider Type C

---

## 3. Asset Selection by Volatility [Heuristic]

**Critical discovery:** The same PM question type produces vastly different
No rates depending on the underlying asset's volatility profile.

### Why Volatility Determines PM Viability

```
High-vol asset (e.g., SOL):
  Spot = $83, Threshold = $200 (+140%)
  Market thinks: "SOL could do this — it's done 30x before"
  → No rate = 82¢ → income = 18¢ per contract
  → Risk/Reward = 4.5:1

Low-vol asset (e.g., ETH):
  Spot = $2,008, Threshold = $4,000 (+99%)
  Market thinks: "ETH won't double in a month"
  → No rate = 95-99¢ → income = 1-5¢ per contract
  → Risk/Reward = 20-99:1
```

**The same percentage distance produces dramatically different No rates**
depending on the asset's historical volatility and crowd perception.

### Asset Viability Checklist

For a Protective Put + PM Bet No structure to work, the asset MUST have:

| # | Requirement | Check |
|---|------------|-------|
| 1 | PM market exists with far threshold + No rate ≤ 85¢ | Scan Polymarket/Kalshi |
| 2 | Options market with sufficient liquidity | Check Deribit/Bybit |
| 3 | Vol high enough that far threshold still has crowd uncertainty | Compare No rates across assets |
| 4 | Expiry/resolution alignment possible | Match options expiry to PM resolve |

### Asset Ranking for PM + Options Structures [Heuristic — verify with current data]

| Asset | Vol Profile | PM Tail Income | Options Liquidity | Overall |
|-------|-----------|---------------|------------------|---------|
| SOL | Very high | Excellent | Good (Deribit, Bybit) | ★★★★★ |
| DOGE | Extreme | Excellent | Poor (limited) | ★★★ |
| XRP | High (event-driven) | Good | Poor | ★★ |
| ETH | Moderate | Poor (No rate ~99¢ at far strikes) | Excellent | ★★ |
| BTC | Moderate-low | Poor | Excellent | ★★ |

**Key insight:** Options liquidity and PM tail income are often inversely correlated.
The best assets have BOTH — SOL is currently the best intersection point.

### Selecting the Right Asset — Workflow

```
1. Scan PM platforms for all crypto price markets
2. For each asset, find the threshold where No rate = 70-85¢
3. Calculate the % distance from spot to that threshold
4. Check: does this asset have liquid options at relevant strikes?
5. If yes → viable candidate
6. If no options → check if perp + spot can substitute (funding arb base)
7. Rank by: PM income per contract × options liquidity score
```

---

## 4. PM Time Decay Behavior [Heuristic]

PM time decay is fundamentally different from options theta.
Understanding this difference is critical for exit timing.

### Options Theta vs PM Time Decay

```
Options theta:
  - Accelerates near expiry (gamma effect)
  - Predictable, model-driven (Black-Scholes)
  - Smooth curve

PM time decay (far threshold):
  - FLAT for most of the period
  - Jumps in last few days when "survival" becomes near-certain
  - NOT smooth — driven by crowd behavior, not models
```

### PM No Rate Movement Patterns [Heuristic — Untested, limited observation]

NOTE: The patterns below are based on limited observations, not systematic
time-series analysis. Treat as hypotheses to verify with actual PM price
history before relying on them for exit timing decisions.

| Threshold distance | Time decay profile (hypothesized) | Implication |
|-------------------|-------------------|-------------|
| Very far (>100% from spot) | Flat 90% of time, jump last 3-5 days | Must hold to near-resolve for meaningful gain |
| Far (50-100%) | Gradual first 50%, accelerate last 50% | Can exit at ~70% of period for partial gain |
| Medium (20-50%) | More responsive throughout | Can trade in/out based on price movement |
| Near (<20%) | Highly responsive to every price move | Behaves more like options — but binary |

### Exit Timing Decision [Heuristic]

```
If threshold is very far + market is quiet:
  → Hold to resolve. Selling early captures almost nothing.
  
If threshold is medium + market moves away from threshold:
  → Can sell at 50-70% of period for decent partial gain.
  
If threshold is near + sudden favorable move:
  → Sell immediately — No rate spike gives good exit.
  
If threshold is any distance + market moves TOWARD threshold:
  → Cut loss early. Don't wait for resolve.
```

---

## 5. Crowd Bias & PM Entry Timing [Heuristic]

PM prices move when crowd sentiment shifts. In quiet markets, prices stagnate.
This affects when to enter and exit PM positions.

### Best Entry Conditions

| Condition | Why | Effect on No rate |
|-----------|-----|------------------|
| After major pump/rally | Crowd buys Yes aggressively → No cheapens | Buy No cheap (income high) |
| Peak fear/FOMO | Extreme sentiment → mispriced tails | No rate at tail thresholds drops |
| Start of new PM market | Time premium maximum → No rate cheapest | First-day entry optimal for touch markets |
| Post-news spike | Temporary sentiment → No rate may overshoot | Mean-reversion opportunity |

### Worst Entry Conditions

| Condition | Why | Effect on No rate |
|-----------|-----|------------------|
| Quiet sideways market | No crowd activity → No rate already high | Income too low to justify |
| Near PM expiry + no movement | Time decay already priced in | No room for rate to improve |
| After extended calm | No uncertainty premium → No rate near 99¢ | No edge |

### Tactical Rule

```
Buy No when crowd is excited about Yes (No is cheap)
Sell No when crowd calms down (No is expensive)
→ This is contrarian PM trading — buy fear, sell calm
```

---

## 6. Maturity Mismatch Strategies for PM + Options

When PM resolve date ≠ options expiry, use one of these strategies:

### Strategy 1: Match Expiry (Ideal)

Find options with expiry on or after PM resolve date.
→ No mismatch. Simplest.
→ May require using longer-dated options (higher premium).

### Strategy 2: Roll Options (PM Longer than Options)

```
Month 1: Buy PM No (resolve end of year) + Buy Put (expiry month 1)
Month 2: Put expires → buy new Put (expiry month 2)
Month 3: Continue rolling...
Month N: Sell PM No before resolve OR hold to resolve

Constraint: Σ(all put premiums) ≤ PM income
If violated → strategy is net negative → reject
```

### Strategy 3: Sell PM Early (Options Shorter than PM)

```
Week 1: Buy PM No (monthly) + Buy Put (2-week expiry)
Week 2: Put expires → sell PM No on order book
→ PM profit = No rate increase from time decay + favorable price movement

Best when: threshold medium distance + market moved favorably
Worst when: threshold very far + market quiet → No rate barely moved
```

### Strategy 4: Staged Re-Entry (Ladder)

```
Buy options in 2-week cycles
Each cycle: new PM No entry + new Put
→ Smaller positions but no mismatch
→ More transaction costs but more control
```

---

## 7. Platform Reference [Contract-specific — verify current offerings before trading]

**⚠️ Platform landscape changes rapidly. Always verify current offerings.**

| Platform | Question Types Available | Assets | Key Characteristics |
|----------|------------------------|--------|-------------------|
| Polymarket | Above (close), Hit (touch monthly), ATH, Range, Race, Vol | BTC, ETH, SOL, DOGE, XRP, more | Deepest liquidity, most altcoin coverage, moving to Polymarket USD collateral, CFTC registered |
| Kalshi | Bracket (range), Above | BTC, ETH, SOL, DOGE, SHIB, more | US-regulated (89% US market share), CFTC oversight, $22B valuation |
| Myriad | Various | BTC, ETH, more | Owned by Decrypt/Dastan, migrated to BNB Chain, switched from AMM to CLOB, uses USD1 stablecoin |
| Gemini | Range contracts (brackets) | BTC, ETH, SOL, XRP, ZEC | Exchange-integrated |

**Platform selection rule:**
- For altcoin PM (SOL, DOGE): Polymarket (only option with depth)
- For regulated US access: Kalshi
- For range/bracket strategies: Gemini or Kalshi
- For maximum question type variety: Polymarket
