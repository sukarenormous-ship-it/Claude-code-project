# Instrument Rules & Domain Archetypes

Every instrument is a **state claim** — a function that pays based on where the state
of the world ends up. Understanding each instrument's function (not just its name)
is what enables creative structure design.

---

## Instrument Function Reference

| Instrument | State Claim | Payoff Shape |
|-----------|-------------|-------------|
| Spot / Futures / Perp | Linear exposure to price | Unlimited up + down |
| Long Call | Right to buy above strike | Convex upside, capped loss |
| Long Put | Right to sell below strike | Convex downside, capped loss |
| Short Call | Obligation above strike | Linear income, unlimited tail risk |
| Short Put | Obligation below strike | Linear income, large tail risk |
| Call Spread | Capped bullish segment | Bounded profit + bounded loss |
| Put Spread | Capped bearish segment | Bounded profit + bounded loss |
| PM Above Yes | Binary boundary claim — "exceeds K" | Binary payout if > K |
| PM Above No | Binary boundary claim — "stays below K" | Binary payout if ≤ K |
| PM Range Yes | Binary zone claim — "lands in [L,U]" | Binary payout if in range |
| PM Range No | Binary zone claim — "outside [L,U]" | Binary payout if outside |
| Tight vertical near strike | Bull Call Spread(K, K+ε) ÷ ε | Near-binary payoff [Approximation — must normalize by width] |
| Conversion / Reversal | Parity-based fixed claim | Near-zero risk, small fixed P/L |

---

## Prediction Market Rules

Treat prediction markets as bounded, binary-like, digital-like, or event-linked payoff legs
when justified.

### PM Above vs PM Range — Different Functions

**PM Above = Boundary Claim**
- Function: "Will price exceed K?"
- Use as: repair leg, one-sided hedge, boundary income
- Executable cost: tends to be low (Yes + No spread close to $1.00) [Heuristic — venue/regime dependent]
- PM No above U = repair for bullish cap
- PM Yes above L = repair for bearish floor

**PM Range = Target-Zone Claim**
- Function: "Will price land in [L, U]?"
- Use as: landing-zone overlay, booster in believed zone
- Executable cost: tends to be high (sum of all bracket ask prices >> $1.00) [Heuristic — venue/regime dependent]
- Buy Yes at target zone = boost payoff in believed range

**Never confuse them.** Above = boundary/repair. Range = target/booster.

### PM Parity Relations

```
Range(L,U) ≈ Above(L) - Above(U)
```
Not exact due to endpoint conventions (boundary rules vary by platform).
Significant mismatch = potential edge worth investigating.

**PM-Only Non-Negative = Impossible When Executable Cost > 0** [Exact Identity]
- Exhaustive cover (all outcomes) costs > $1 → guaranteed house edge
- Monitor: if any exhaustive combination sums < $1 → instant arb opportunity

### Always Check Before Using a PM Leg

| # | Check |
|---|-------|
| 1 | Resolution wording — does it match your trade thesis exactly? |
| 2 | Reference price source — which feed determines settlement? |
| 3 | Timestamp and cutoff rules — when exactly does it resolve? |
| 4 | Settlement mechanics — cash? binary payout? partial? |
| 5 | Exactness of match vs hedge instrument — how close is the mapping? |
| 6 | Liquidity and depth — can you fill at the quoted price? |
| 7 | Fillability — bid/ask width, order book depth, slippage estimate |
| 8 | Executable cost — sum of Ask(Yes)+Ask(No) for Above; sum of all bracket Ask prices for Range |

**Hard rule:** Never assume a PM contract equals an option unless payoff and settlement
logic truly match.

### Settlement Awareness

- PM pairs sharing the same resolver have **reduced oracle/source mismatch** — but may still differ in boundary conventions, timestamp cutoffs, wording, or path-vs-close rules [Contract-specific — always verify]
- PM + Options across platforms typically use different resolvers → settlement mismatch exists
- Always verify: resolver source, timestamp/cutoff, boundary conventions, cash vs binary payout
- Settlement mismatch doesn't kill a structure — but it must be bounded and priced in

---

## Options / Synthetic Pricing Rules

Treat options as a pricing language, not only as a speculative instrument.

**Be ready to use:**
- put-call parity
- synthetic long / short stock
- synthetic long / short forward
- conversion / reversal
- box spread
- call spread / put spread equivalence
- collar / risk reversal
- options-implied forward
- options-implied probability
- strike-by-strike payoff shaping

### Always Check Before Using an Options Leg

| # | Check |
|---|-------|
| 1 | Strike alignment — do strikes match across legs? |
| 2 | Expiry alignment — same expiration for all legs? |
| 3 | Multiplier / contract size — normalized correctly? |
| 4 | European vs American exercise — affects early exercise risk |
| 5 | Physical vs cash settlement — affects delivery risk |
| 6 | Borrow / carry / dividend / funding assumptions |
| 7 | Underlier mapping — same underlying across instruments? |
| 8 | Bid / ask on each leg — use realistic fill prices |
| 9 | Assignment risk — especially for short American options |
| 10 | Liquidity and legging risk — can all legs be filled? |

### Same-Trigger Warning for Options + PM

When combining options and PM legs:
- If option strike ≈ PM threshold → they trigger on the same event → **amplify, not hedge**
- Ensure sufficient distance between strikes and PM boundaries
- The test: "If price moves to X, do both legs win or does one leg win and one lose?"
  If both win or both lose together → same trigger → amplification

---

## Cross-Market Probability Comparison

PM-implied probability and options-implied probability at the same threshold often diverge
significantly, especially at tail events (PM longshot bias).

**Why large gaps don't automatically mean exploitable edge:**
- PM pays binary (fixed amount if event occurs)
- Options pay linearly (proportional to how far past strike)
- Different settlement mechanics and resolvers
- Different timing and reference prices

**When the gap IS exploitable:**
- When you can construct a structure where the binary PM leg and options leg
  cover different segments of the state space (not the same trigger)
- When settlement mismatch is bounded and priced in

---

## Domain Archetype Library

Treat these as starting templates for creative design, not automatic recommendations.
Always validate before recommending. Use state-claim decomposition to modify or invent beyond these.

### Bullish / Capped-Extreme
- Long Call + Buy No (PM boundary repair)
- Bull Call Spread + Buy No
- Long Spot / Future + Protective Overlay + PM leg
- **Design principle:** Bullish core + boundary claim that pays if upside caps out

### Bearish / Capped-Extreme
- Long Put + PM overlay
- Bear Put Spread + PM overlay
- Short Future + Long Call + PM overlay
- **Design principle:** Bearish core + boundary claim that pays if downside is limited

### Event / Binary
- Event hedge overlay against directional options / futures
- Convex leg softened or financed by PM leg
- **Design principle:** Event-driven state claim + protection for wrong-outcome scenario

### Synthetic / Parity
- Put-call parity checks
- Synthetic forward vs listed future
- Conversion / reversal
- Box-spread financing
- **Design principle:** Exploit pricing inconsistencies between instruments that should be equivalent

### Range / No-Extreme
Only consider when:
- Risk is fully capped
- Settlement match is strong
- Liquidity is realistic for all legs
- PM Range executable cost is low enough to justify [Heuristic]
- **Design principle:** Landing-zone boost, not hedge

### Volatility Risk Premium
- Credit spreads when IV > RV
- Iron condors in sideways / high-IV regime
- **Design principle:** Sell overpriced volatility with bounded risk structure
- Most consistently actionable edge source across market conditions
