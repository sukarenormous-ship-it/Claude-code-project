# Changelog

## v3 (April 14, 2026) — Full Redesign

### New Files (15)
- **SKILL.md** (623 lines): 6-stage decision flow, 4 gates, 5 entry paths
  (Default + Belief + Education + Bot + Scanner Handoff),
  17-entry auto-trigger map, 5 few-shot examples, identity + capability boundaries,
  context window guidance, staleness rule, cold start protocol
- **profiles/ (10 files)**: Strategy profiles with quantitative operating ranges
  (floor/entry/normal/exceptional), net formulas with worked examples,
  mechanism labels (AXIOM/STRUCTURAL/HEURISTIC/PLATFORM),
  alternatives, quantitative avoid_regime, collateral branch (earn-hedge)
- **strategies/timing.md** (313 lines): 6-signal regime detection with numeric thresholds
  + weights (HIGH/MED/LOW), 4 regime maps (Bull/Bear/Sideways/Transition)
  + Always Available, per-asset detection, hand rankings cross-reference
- **strategies/composition.md** (578 lines): 5-step composition engine,
  3 pairing modes (neutral/directional/hedged), function extraction,
  progressive descent, ranking formula with unit conversion reminder,
  8-dimension scoring escalation
- **strategies/reasoning.md** (539 lines): 6 discovery prompts ordered by speed,
  edge source analysis (WHO/WHY/HOW LONG), parameter discovery,
  handoff format to composition
- **principles/reference-gap.md** (319 lines): Reference gap principle [AXIOM],
  10-parameter map with drift assessment, convergence classification,
  6 known patterns with confidence labels

### Updated v2 Files (11)
- output-templates.md: REWRITTEN — v3 card format + verification status labels
- mechanism-transformations.md: "Gate B" → "pre-screen step 4", anti-pattern count 12→17
- cross-instrument-optimization.md: "Spectrum Level 5" → Lv.5, staleness warning, duplicate Step 1 header fixed
- payoff-algebra.md: "Spectrum: Level 4" → Lv.4, "Level 5" → Lv.5
- belief-patterns.md: "Arbitrage Spectrum" → "Arb Taxonomy"
- real-world-discoveries.md: "Spectrum Lv." → "Lv.", staleness warning added
- epistemology-guide.md: "Spectrum Lv.5" → "Lv.5"
- payoff-primitives.md: path `references/` → `principles/`
- pm-question-types.md: platform table updated (Kalshi expanded assets, Myriad AMM→CLOB)
- pm-arb-mechanics.md: Myriad AMM→CLOB migration note
- operational.md: "No-Bot-Before-Mechanism Gate" → "Stage 4-5 verified"

### Unchanged v2 Files (3)
- instrument-rules.md, optimization.md, execution-rules.md

### Key v2 → v3 Changes
- Arb Taxonomy: "Spectrum 1-6" → Lv.1-5
- Gates: 5 letter gates (A-E) → 4 numbered gates (Numbers, Baseline, Feasibility, Data)
- Baseline: "best_simple" → "baseline" with scope rules (same-asset vs cross-asset)
- Profiles: new concept — quantitative operating ranges per strategy
- Timing: numeric thresholds (not qualitative "high/low")
- Directory: flat references/ → principles/ + strategies/ + profiles/
- spread-arb floor: 7% → 5% (corrected: fee round-trip 0.17% not 0.24%)
- earn-hedge: floor 5% → 3%, entry 8% → 5%, collateral branch in net formula
- funding-harvest: formula example rewritten (break-even ~14% APY, headline ~22%)
- Identity: added "Cannot: execute, monitor, API"
- Entry paths: 4 → 5 (added Scanner Handoff)
- Auto-trigger: 13 → 17 entries (added mechanism-transforms, real-world-discoveries,
  epistemology, operational)
- GOT: clarified as "active mindset" not separate step
- Cold start: clarified "skip if user already sent data"
- Context window: "max 3 reference files before summarizing"
- Staleness: warnings on 3 files with dated observations
- Platform data: updated Polymarket, Kalshi, Myriad current status

### Review Process
- Line-by-line review: all 33 files (6,833 lines)
- Cross-file consistency: 11 dimensions verified programmatically
- Math verification: fee amortization, APY conversion, LP feasibility, N_min/N_max
- Deep system review: identity, workflow, math, reasoning, decision, framework
- Cross-skill alignment: 4 skills (arb-engine, foundations, simulation, scanner)
- Fresh AI perspective: 3 confusion points identified and fixed
- Web search: PM platform data verified (Polymarket, Kalshi, Myriad)
