```yaml
# Strategy Profile: [NAME]

identity:
  name:        # full name
  type:        # Lv.1-5 classification
  mechanism:   # WHY does this edge exist? [label: AXIOM/STRUCTURAL/HEURISTIC/PLATFORM]
  maturity:    # CATALOGED (proven) or DRAFT (new, needs calibration)

timing:
  regime:        # which regime(s) this works in
  avoid_regime:  # which regime(s) to skip — used by Stage 2 FILTER
  best_when:     # specific conditions that make this exceptional

operating_range:
  floor:         # below this → don't bother (fee/effort > edge)
  entry:         # above this → recommended to enter
  normal:        # typical range in favorable regime
  exceptional:   # unusually high — act quickly but may not last
  metric:        # what unit (APY%, $/trade, pp gap, %/8hr)
  range_basis:   # HOW were floor/entry derived? (fee math, historical, estimated)
  recalibrate_when: # when to revisit these numbers

alternatives:
  when_below_floor:  # what to do instead when this strategy is below floor
  when_regime_wrong: # what to try when regime doesn't fit
  simpler_version:   # simpler strategy that achieves similar goal

execution:
  style:         # instant / hold-to-expiry / duration / calendar / continuous
                 # MUST derive from mechanism, never copy from another strategy
  entry_signal:  # specific trigger to open
  exit_signal:   # specific trigger to close
  position_mgmt: # how to manage while open

verification:
  must_check:    # specific items to verify BEFORE entering (not generic)
  freshness:     # how old data can be for each check
  platform_reqs: # what platform features/modes are needed

costs:
  net_formula:   # explicit formula: net = income - cost1 - cost2 - ...
  formula_example: # worked example with real numbers
  fees:          # specific fee structure for this strategy
  hidden_costs:  # costs often forgotten
  min_profit:    # minimum $ profit per cycle to justify effort

risks:
  primary:       # biggest risk specific to this strategy
  secondary:     # other notable risks
  kill_condition: # if this happens → close immediately, no questions
  what_can_go_wrong: # realistic worst-case scenario
```
