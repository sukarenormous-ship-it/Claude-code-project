```yaml
identity:
  name:        Spread Arb / Cash-and-Carry
  type:        Lv.2 Near-Pure
  mechanism:   Dated futures converge to spot at expiry by settlement mechanism. [AXIOM]
               Edge = basis captured at entry, locked by convergence.
  maturity:    CATALOGED

timing:
  regime:        Bull + contango wide (basis APY > 8%). Also works in sideways if basis sufficient.
  avoid_regime:  Basis APY < 2% (flat or backwardation — not enough to cover fees)
  best_when:     Contango steep (>15% APY) + high volume + near-dated expiry (fast convergence)

operating_range:
  floor:         5% APY net after all fees
  entry:         10% APY — spread wide enough to justify 2 legs
  normal:        5-14% APY
  exceptional:   >20% APY — usually during extreme bullish sentiment
  metric:        APY (annualized from basis ÷ days to expiry)
  range_basis:   floor = round-trip fees (~0.17% USDT linear) annualized over 14-30d ≈ 4-5%.
                 rounded up to 5% for slippage buffer.
                 entry = floor × 2 (comfortable margin for execution risk).
  recalibrate_when: fee structure changes, new contract types listed,
                    or after 5+ completed trades show actual distribution.

alternatives:
  when_below_floor:  platform-yield (simpler, always available)
  when_regime_wrong: reverse-funding (bear regime), sell-vol (if IV elevated)
  simpler_version:   platform-yield (1 leg, no hedge needed)

execution:
  style:         hold-to-expiry OR trade-the-range
                 hold-to-expiry: when basis steady, liquidity thin — set and wait
                 trade-the-range: when basis oscillates — open wide, close narrow, repeat
                 choose based on basis volatility and order book depth
  entry_signal:  basis APY > entry threshold (10%)
  exit_signal:   hold-to-expiry: settlement day
                 trade-the-range: basis narrows below 5% APY
  position_mgmt: monitor basis daily. if basis widens further, can add size.
                 if basis inverts → evaluate early exit vs hold.

verification:
  must_check:
    - futures order book depth:
        can you fill desired size at quoted price?
        depth must be ≥ 2× position size within 0.1% of best price
    - bid-ask spread on both legs (total slippage cost)
    - settlement mechanism (USDT settled? physical? fee?)
    - margin requirement (UTA offset for spot+future?)
  freshness:
    - price data: < 1 hour
    - order book depth: < 30 minutes
    - settlement rules: once per contract (doesn't change)
  platform_reqs: Spot + dated futures on same exchange. UTA preferred for margin offset.

costs:
  net_formula:   net_APY = gross_APY - annualized_total_fees
                 gross_APY = (basis / spot_price) × (365 / days_to_expiry)
                 total_fees = entry_fees + exit_fees
  fee_breakdown:
    entry: spot_buy_taker 0.1% + futures_sell_maker 0.02% = 0.12%
    exit:  spot: hold to settlement (0%) OR sell taker 0.1%
           futures: settlement fee 0-0.05% (USDT linear = 0%)
    round_trip: 0.12% + 0.05% = 0.17% (USDT linear, hold spot to settlement)
                0.12% + 0.15% = 0.27% (if selling spot + USDC settlement)
  formula_example: basis $18 on $4700 XAUT, 11 days to expiry
                   gross = 18/4700 × 365/11 = 12.7% APY
                   fees round-trip = 0.17% (USDT linear, hold to settlement)
                   annualized fee = 0.17% × 365/11 = 5.6%
                   net ≈ 12.7% - 5.6% = 7.1% APY (above floor 5% ✓, above entry 10%? no → WATCHLIST)
                   NOTE: if using taker on both sides, fees double → net < floor
  fees:          see fee_breakdown above
  hidden_costs:  slippage on entry (especially thin order books),
                 borrowing cost if using margin for spot leg
  min_profit:    $15 per cycle (2 legs)

risks:
  primary:       Liquidity — thin futures order book means can't exit at good price
  secondary:     Basis inversion (rare for dated futures), exchange downtime near expiry
  kill_condition: Exchange announces contract delisting or settlement rule change
  what_can_go_wrong: Enter at 10% APY, basis widens to 15% (unrealized loss on mark-to-market),
                     but converges at expiry → still profit. Risk is psychological, not structural.
```
