# Operational Specifications

---

## Scanner Design

Do not build a scanner until the opportunity is formalized and verified
via Stage 4-5 (mechanism + feasibility must pass before bot design).

### Scanner Must Define:

| # | Field | What to specify |
|---|-------|----------------|
| 1 | Objective | What the scanner is looking for |
| 2 | Instruments | Exact instruments to monitor (as state claims) |
| 3 | Data required | Price feeds, order books, PM contracts, etc. |
| 4 | Normalization | How to make different instruments comparable |
| 5 | Derived formulas | Calculated values (synthetic price, implied prob, edge) |
| 6 | Candidate condition | Raw signal that flags a potential opportunity |
| 7 | Cost-adjusted condition | Signal after fees, slippage, spread |
| 8 | Depth / liquidity filter | Minimum order book depth, max spread |
| 9 | Freshness filter | Max data age, sync requirements across feeds |
| 10 | Action threshold | When to alert or trigger OMS |
| 11 | Reject conditions | When to discard a candidate |
| 12 | Logging fields | What to record for analysis |
| 13 | OMS-ready condition | What makes a candidate ready for execution |

### What Scanners in This Domain Should Track:
- Spot / perp / futures price
- Option chain by strike / expiry
- Bid / ask / spread per instrument
- PM yes / no price (Above and Range separately)
- PM resolution metadata
- Underlier mapping across venues
- Expiry / maturity mapping
- Carry / funding / borrow assumptions
- Derived synthetic prices
- PM executable cost (Σ Ask for exhaustive cover) — monitor for cost inversion [Heuristic]
- IV vs RV ratio — monitor for VRP regime entry/exit
- D_min feasibility — monitor for spread+PM structure viability

---

## OMS (Order Management System) Design

For multi-leg or hybrid structures, sequencing is critical.
Never assume all legs will fill at screen price.

### OMS Playbook Must Define:

| # | Field | What to specify |
|---|-------|----------------|
| 1 | Trade archetype | What kind of structure is being executed (state-claim description) |
| 2 | Pre-trade checks | Margin, capital, data freshness, hedge readiness |
| 3 | Leg priority order | Which leg first, second, etc. |
| 4 | Entry sequencing | Why this order (hedge-first? PM-first? probe-then-scale?) |
| 5 | Partial-fill handling | What to do if only some legs fill |
| 6 | Abort conditions | When to cancel the entire trade |
| 7 | Retry rules | How many retries, with what adjustments |
| 8 | Timeout rules | Max time to complete all legs |
| 9 | Broken-hedge rules | What to do if hedge leg fails after core leg fills |
| 10 | Active monitoring | What to watch while position is open |
| 11 | Exit / unwind logic | How and when to close the position |
| 12 | Emergency stop | Kill-switch conditions |
| 13 | Alert conditions | What triggers human notification |
| 14 | Required telemetry | What data to log for post-trade analysis |

### Sequencing Considerations:
- Which leg must be secured first? (usually the most fragile or fastest-moving)
- Which leg provides immediate hedge?
- Entry styles: hedge-first, PM-first, options-first, neutral-base-first, probe-then-scale
- Always plan for the case where you're partially filled and exposed
- Consider: if only Leg 1 fills and Leg 2 fails, is the residual exposure acceptable?

---

## Cross-Market Edge Hierarchy

Ranked by typical actionability. **These rankings change with market conditions —
always re-evaluate.**

| Tier | Edge Type | Typical Size | Instrument | Actionability |
|------|-----------|-------------|------------|---------------|
| 1 | Volatility Risk Premium (IV > RV) | Meaningful | Options spreads | Most consistent |
| 2 | PM Above executable cost | Small | PM Above pairs | Good for repair legs [Heuristic] |
| 3 | PM Range executable cost | High cost | PM Range | Booster only [Heuristic] |
| 4 | PM vs Options probability gap | Large gap | Cross-market | Hard to exploit cleanly |
| 5 | Cross-exchange options | Negligible | Same options diff exchange | MM-arbitraged |

### Conditions That Shift the Hierarchy:
- New PM products or strikes → new edge sources appear
- Executable cost changes → previously losing structures become viable
- IV regime changes → VRP appears/disappears
- Liquidity changes → legging risk dominates or recedes
- Settlement rule changes → mismatch risk changes

---

## Candidate Rejection Rules

Reject or downgrade structures when:

| Condition | Action |
|-----------|--------|
| Settlement wording is too ambiguous | Reject or flag as high-risk |
| PM reference price doesn't match hedge closely | Downgrade; quantify mismatch |
| Expiry mismatch creates dangerous open exposure | Reject unless mismatch is bounded |
| Legging risk dominates the edge | Reject for automation; may be OK for manual |
| Option spreads are too wide | Reject unless edge is very large |
| PM liquidity is too thin | Reject for size; may work for small trades |
| Tail risk is uncapped | Reject unless user explicitly accepts |
| Complexity rises but benefit is small | Prefer simpler variant |
| Scanner signal is unstable / flickering | Reject for automation |
| OMS handling is too fragile relative to edge | Reject for automation |
| Same-trigger legs treated as hedge | Reclassify as amplification; redesign |
| D_min test fails | Reject for non-negative claim; may still work as bounded-loss |
| PM executable cost > edge | Reject PM leg; find alternative |
| Profit < risk on expected basis | Reject — "passes feasibility" ≠ "worth it" |

### When Rejecting, Label the Reason:
- Structurally weak
- Operationally fragile
- Too expensive
- Too mismatched
- Too hard to automate
- OK for manual discretionary trading only
- OK for paper study only
- **Currently infeasible — revisit when conditions change** (specify what must change)
