# Claude Code Handoff Brief

## What Is This

quant-arb-engine is a Claude skill for crypto derivatives edge discovery
and strategy design. It has been redesigned (v2→v3) and reviewed line-by-line
across 33 files, 6,833 lines. All known static issues have been fixed.

This document tells Claude Code what to do next.

---

## Architecture Overview (Read This First)

```
SKILL.md = master file. AI reads this on every conversation.
  Contains: 6-stage decision flow, 5 entry paths, auto-trigger map.
  
Auto-trigger: SKILL.md tells AI which files to read based on conditions.
  e.g., "Options involved → read principles/instrument-rules.md"
  AI does NOT read all 33 files. Typical conversation: 3-5 files.

Profiles: 9 strategy profiles with quantitative thresholds.
  Each has: floor (minimum to bother), entry (recommended), normal, exceptional.
  Stage 3 MATCH reads the matched profile.

Decision Flow:
  S1 OBSERVE → S2 FILTER (timing.md) → S3 MATCH (profiles/) → 
  S4 CREATE (composition + reasoning) → S5 VERIFY (4 gates) → S6 RANK

4 Gates (Stage 5):
  Gate 1 NUMBERS: net > 0 after all costs?
  Gate 2 BASELINE: vs simplest 1-leg alternative (label, not reject)
  Gate 3 FEASIBILITY: can actually execute?
  Gate 4 DATA READINESS: 0 unverified=RECOMMENDATION, 1=CONDITIONAL, 2+=CANDIDATE
```

---

## File Locations

```
Skill directory:  /mnt/skills/user/quant-arb-engine/
Deploy package:   quant-arb-engine-v3.zip (uploaded by user)
                  Unzip → rename deploy/ → quant-arb-engine/

Related skills (may need cross-skill updates):
  /mnt/skills/user/quant-foundations/SKILL.md
  /mnt/skills/user/quant-simulation/SKILL.md
  /mnt/skills/user/quant-scanner/SKILL.md
```

---

## Tasks — In Priority Order

### Task 1: Deploy + Verify File Structure

```bash
# After user uploads the skill, verify:
ls -la /mnt/skills/user/quant-arb-engine/
ls -la /mnt/skills/user/quant-arb-engine/profiles/
ls -la /mnt/skills/user/quant-arb-engine/strategies/
ls -la /mnt/skills/user/quant-arb-engine/principles/

# Verify SKILL.md auto-trigger map → all referenced files exist
```

### Task 2: Validation Script

Write a Python script (save as `validate_skill.py`) that checks:

```python
"""
Run after any edit to verify consistency across all files.
Exit code 0 = all pass. Non-zero = failures found.
"""

CHECKS = {
    "terminology": {
        "forbidden": ["best_simple", "Spectrum", "Adaptive Gate", "Anti-Garbage"],
        "forbidden_patterns": [r"Go.*No-Go", r"Gate [A-G]", r"Gate [5-9]"],
        "exclude_files": ["README.md", "CHANGELOG.md", "TEST-SCENARIOS.md", 
                          "CLAUDE-CODE-HANDOFF.md"],
    },
    "paths": {
        "no_old_paths": ["`references/"],  # should be principles/ or strategies/
    },
    "floors": {
        "spread-arb": {"floor": 5, "field": "floor:"},
        "earn-hedge": {"floor": 3, "field": "floor:"},
        "all_profiles": "normal_range_start >= floor",
    },
    "profiles": {
        "required_sections": ["identity:", "timing:", "operating_range:", 
                              "alternatives:", "execution:", "verification:",
                              "costs:", "risks:"],
        "yaml_tags": "exactly 1 ```yaml open + 1 ``` close per file",
    },
    "auto_trigger": {
        "every_referenced_file_must_exist": True,
    },
    "funding_direction": {
        # When funding > 0: longs pay shorts
        # When funding < 0: shorts pay longs
        "verify_manually": "grep all 'longs pay/shorts pay' statements",
    },
    "avoid_regime": {
        "profiles_must_match_timing_quick_reference": True,
    },
    "math": {
        "apy_conversion": "rate × 3 × 365 used consistently",
        "funding_harvest_headline": "~22% (not 26%)",
        "funding_harvest_breakeven": "~14% (not 17%)",
    },
}
```

### Task 3: Live Test Harness

Call Claude API with SKILL.md content + test prompts.
The skill files are loaded as system prompt context when the skill triggers.

```python
import anthropic

client = anthropic.Anthropic()

# Load SKILL.md as the skill context
skill_content = open("quant-arb-engine/SKILL.md").read()

tests = [
    {
        "name": "basic_scan",
        "prompt": "ช่วงนี้มีอะไรทำได้บ้าง",
        "must_contain": ["timing", "threshold", "regime"],
        "must_not_contain": ["pure arb", "guaranteed"],
        "behavior": [
            "asks for data OR does web search (cold start)",
            "does NOT classify regime without checking thresholds",
            "mentions specific threshold numbers from timing.md",
        ]
    },
    {
        "name": "arb_request_honest",
        "prompt": "มี arb ไหมตอนนี้",
        "must_not_contain": ["Lv.3 arb", "Lv.4 arb", "funding arb"],
        "behavior": [
            "checks Lv.1-2 first (conversion, box spread)",
            "if not found: says 'No pure arb' honestly",
            "presents Lv.3-4 with honest labels, NOT called arb",
        ]
    },
    {
        "name": "belief_entry",
        "prompt": "BTC ไม่น่าจะเกิน 120K ใน 3 เดือน",
        "must_contain": ["payoff", "structure"],
        "behavior": [
            "skips Stage 1-3 (no regime detection needed)",
            "translates belief into payoff shape",
            "designs structure matching the belief",
            "verifies via gates",
        ]
    },
    {
        "name": "baseline_scope",
        "prompt": "XAUT ทำอะไรได้",
        "behavior": [
            "baseline uses XAUT option (same asset, not cross-asset)",
            "does NOT use USDT Earn as primary baseline",
            "if earn-hedge considered: mentions collateral check",
        ]
    },
    {
        "name": "non_negative_claim",
        "prompt": "ออกแบบ structure ที่ไม่ขาดทุนเลยได้ไหม",
        "must_contain": ["locked edge", "conversion", "basis"],
        "must_not_contain": ["funding is locked"],
        "behavior": [
            "requires locked edge as core (conversion, basis, box spread)",
            "explains why funding/PM cannot be core edge",
            "offers bounded-loss alternative if no locked edge available",
        ]
    },
    {
        "name": "education_then_scan",
        "prompt": "spread arb คืออะไร",
        "behavior": [
            "explains spread arb using taxonomy + building blocks",
            "offers to scan for this opportunity",
            "does NOT start scanning before explaining",
        ]
    },
    {
        "name": "regime_threshold_check",
        "prompt": "funding rate อยู่ที่ -0.002% ถือว่า bear ไหม",
        "must_contain": ["0.005", "neutral", "threshold"],
        "behavior": [
            "references timing.md threshold: ±0.005%/8hr = neutral zone",
            "-0.002% is within neutral, NOT bear",
            "does NOT just say 'negative = bear'",
        ]
    },
]

# Run each test
for test in tests:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        system=f"You are using the quant-arb-engine skill.\n\n{skill_content}",
        messages=[{"role": "user", "content": test["prompt"]}]
    )
    
    output = response.content[0].text
    
    # Check must_contain / must_not_contain
    # Check behavior (manual review or LLM-as-judge)
    # Report pass/fail
```

**Important notes for test harness:**
- Use `claude-sonnet-4-20250514` for testing (fast + follows instructions well)
- SKILL.md alone should be enough for basic behavior testing
- For deep testing: also load timing.md + relevant profiles into system prompt
- Tests are in Thai — AI should respond in Thai (language matching)
- "behavior" checks may need LLM-as-judge (ask another Claude to evaluate)

### Task 4: Cross-Skill Updates

```
quant-simulation SKILL.md line ~104:
  OLD: "Spectrum: 1=Pure Arb, 2=Parity, 3=Hard-Hedged, 4=Structured, 
       5=Hedged Speculation, 6=Directional"
  NEW: "Lv.1-5 classification (see quant-arb-engine for definitions)"
  
  File: /mnt/skills/user/quant-simulation/SKILL.md
  This is the only known cross-skill inconsistency.
```

### Task 5: Iterate From Test Results

```
After running tests:
  1. Identify which tests fail and WHY
  2. Common failure modes:
     - AI doesn't read timing.md thresholds → SKILL.md instruction too weak
     - AI skips baseline comparison → Gate 2 wording needs strengthening
     - AI reads too many files → context window overflow → simplify
     - AI doesn't follow entry path → entry conditions need clearer matching
  3. Fix the SKILL.md or relevant file
  4. Re-run validation script (Task 2) → ensure no regression
  5. Re-run failed tests → verify fix works
  6. Repeat until all 7 tests pass
```

---

## Known Limitations (Don't Try to Fix These)

```
1. Context window: if AI reads SKILL.md + timing + profile + composition + reasoning 
   + payoff-algebra = ~2,600 lines → may start losing early instructions.
   SKILL.md already says "max 3 reference files before summarizing."
   
2. Threshold checking: AI tends to classify regime qualitatively ("negative = bear")
   instead of checking numeric thresholds. This is a model tendency, not a skill bug.
   May need stronger language in SKILL.md or worked examples showing threshold check.

3. PM platform data: changes frequently. Files have staleness warnings.
   Don't try to keep platform tables current — mark them [verify before trading].

4. v2 content quality: v2 reference files were audited for v3 CONFLICTS but their
   INTERNAL math/logic was only spot-checked, not fully re-verified.
   If tests reveal wrong math in v2 files → fix case by case.
```

---

## Success Criteria

```
All 7 tests pass with consistent behavior across 3 runs each.
Validation script returns exit code 0.
No cross-skill terminology conflicts.
```
