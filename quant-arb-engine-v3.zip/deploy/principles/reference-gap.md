# Reference Gap Principle

Read by: Stage 4 CREATE (when Parameter Discovery triggered via reasoning.md)

---

## 1. The Principle [AXIOM]

```
Every parameter in a market is anchored by a reference source.
When the reference disappears, the parameter drifts.
When the reference returns, the parameter converges.

This is not a strategy — it is a law of market microstructure.
It applies to any parameter, any market, any asset.
```

### Why This Happens

```
Market prices (and other parameters) are maintained by a feedback loop:

  informed participants observe → compare to reference → trade to correct deviations

When the reference disappears:
  1. Informed participants can no longer compare → stop correcting
  2. Remaining participants have less information → price based on sentiment/noise
  3. Supply-demand imbalance from remaining (different) participant base
  4. No anchor to prevent drift → parameter moves freely

When the reference returns:
  1. Informed participants compare current vs reference → see deviation
  2. They trade to correct → parameter moves toward reference value
  3. Convergence speed depends on liquidity + number of informed participants
```

### Drift Assessment (Qualitative)

```
Don't try to calculate drift mathematically — assess from observable signals:

HIGH drift expected:
  Very thin liquidity + no informed participants remaining
  e.g., XAUT during weekend (no COMEX reference, thin crypto-only book)

MED drift expected:
  Reduced liquidity + some informed participants still active
  e.g., BTC during Asian night hours (some global traders, reduced volume)

LOW drift expected:
  Decent liquidity + informed participants present
  e.g., ETH during US evening + European morning overlap

Key observable indicators:
  Order book depth (thinner = more drift potential)
  Bid-ask spread (wider = less informed participation)
  Volume relative to normal (lower = fewer correcting participants)
```

---

## 2. Not Just Price — All Parameters Drift

Price is the most visible parameter, but the principle applies universally.
Each parameter has its own reference source, downtime pattern, and drift behavior.

### Parameter Map

| Parameter | Reference Source | Downtime Pattern | Drift Behavior | Convergence Mechanism | How to Measure Drift |
|-----------|-----------------|------------------|----------------|----------------------|---------------------|
| **Price** | TradFi reference market (COMEX, NYSE) | Weekends, holidays, after-hours | Token price drifts from fair value | Arb bots + informed traders reprice at market open | current_token_price − last_TradFi_close |
| **Implied Volatility** | Market maker continuous quotes | Off-hours, stress events (MM withdraw) | IV spikes or collapses without MM anchor | MM return → reprice to model value | current_IV − IV_at_last_MM_active_period |
| **Funding Rate** | Arb bots maintaining spot-perp basis | Low-liquidity hours, exchange API issues | Funding becomes extreme (bots not correcting) | Bots resume → funding normalizes | current_rate − 30d_average_rate |
| **Borrow/Lending Rate** | Lending pool supply-demand equilibrium | Whale withdrawal, utilization spike | Rate spikes as supply drops | Capital returns → rate normalizes | current_rate − normal_rate_at_utilization |
| **NAV / Token Peg** | Redemption mechanism against underlying | Redemption paused, queue delayed, weekend | Token trades at premium or discount to NAV | Redemption reopens → premium/discount closes | (token_price − NAV) / NAV × 100% |
| **Oracle Price** | On-chain feed (Chainlink, Pyth) | Update lag, congestion, heartbeat interval | DeFi protocols use stale price | Oracle updates → protocol reprices | CEX_price − oracle_price |
| **Index Price** | Aggregate of prices from multiple exchanges | Source exchange down/maintenance | Index skewed by remaining sources | Source returns → index rebalances | index − median_of_all_sources |
| **Correlation** | Historical co-movement pattern | Market stress, structural break | Correlated assets decouple | Stress subsides → correlation restores (maybe) | rolling_7d_corr − 90d_corr |
| **Margin Requirement** | Exchange risk engine (uses current IV) | Recalculated periodically, not continuously | Stale IV → margin too loose or too tight | Engine recalculates → margin adjusts | current_req − req_at_last_recalc |
| **Settlement Price** | Settlement mechanism at expiry | Different exchanges settle at different times/methods | Cross-exchange settlement prices differ | No convergence — different by design | N/A — structural difference |

---

## 3. Convergence Is Not Guaranteed

### Convergence Classification

```
Before trading any drift, verify convergence:

✅ HIGH CONFIDENCE convergence (mechanism forces it):
  Price → settlement at expiry (futures), arb bots (spot)
  IV → market makers reprice (when back online)
  Funding → arb bots restore basis (when active)
  NAV → redemption mechanism (when open)
  Oracle → feed updates (on schedule)
  Index → source exchange returns (after maintenance)

⚠️ CONDITIONAL convergence (usually, but not always):
  Borrow rate → capital returns IF no structural demand change
  Margin requirement → recalculation IF IV hasn't structurally changed
  Correlation → restores IF stress was temporary, not structural

❌ NO convergence expected:
  Reference changed permanently (delist, protocol migration, regime shift)
  Settlement price across exchanges (different by design, not error)
  Correlation after fundamental structural change
```

### The Critical Test

```
For any parameter drift you want to trade:

  1. NAME the convergence mechanism
     "What specifically forces this parameter back to reference?"
     
     Good answers:
       "Futures settle to spot at expiry"
       "Arb bots restore basis when API is back online"
       "Redemption mechanism allows converting token to underlying"
     
     Bad answers:
       "It usually goes back" (no mechanism named)
       "Mean reversion" (statistical tendency, not mechanism)
       "It should converge" (hope, not mechanism)
  
  2. VERIFY the mechanism is active
     "Is the mechanism currently functional?"
     
     Redemption paused indefinitely → mechanism broken → no convergence
     Arb bots banned → mechanism removed → no convergence
     Settlement rules changed → old mechanism invalid → check new rules
  
  3. ESTIMATE convergence timing
     "When does the reference return?"
     
     Known schedule (weekend → Monday) → predictable timing
     Unknown (exchange maintenance "soon") → unpredictable → risky
     Never (permanent change) → not drift, it's a new equilibrium
```

---

## 4. Known Reference Gap Patterns

Recurring patterns where this principle creates tradeable opportunities.
Not exhaustive — new patterns can be discovered using reasoning.md.

### Pattern A: Weekend RWA Gap [OBSERVED — seen in data, not yet systematically traded]

```
Asset:      Tokenized commodities (XAUT, PAXG, oil tokens)
Reference:  TradFi market (COMEX, NYMEX)
Downtime:   Friday evening → Monday morning (and holidays)
What drifts: Token price drifts from last TradFi close
Convergence: Monday open → TradFi reprices → token converges
Frequency:  Every weekend (52× per year)
Magnitude:  0.3-2% typically, larger during volatile periods

Tradeable via: profiles/weekend-gap.md
```

### Pattern B: Off-Hours IV Drift [THEORETICAL — mechanism sound, not verified with data]

```
Asset:      Any asset with options where MMs are timezone-dependent
Reference:  Market maker continuous quoting
Downtime:   Off-hours when MMs reduce activity (typically late night local time)
What drifts: IV — without MM anchor, retail flow moves IV irrationally
Convergence: MMs return → reprice to model
Frequency:  Daily (but magnitude often below floor)
Magnitude:  1-5pp IV drift typically

Tradeable when: IV drift > sell-vol floor (5pp) during off-hours
Note: requires ability to trade options during off-hours
```

### Pattern C: Exchange Maintenance Funding Spike [THEORETICAL — mechanism sound, irregular occurrence]

```
Asset:      Any perp contract during exchange maintenance
Reference:  Cross-exchange arb bots maintaining basis
Downtime:   Scheduled or emergency maintenance on one exchange
What drifts: Funding rate — bots can't arb → funding spikes
Convergence: Exchange back online → bots resume → funding normalizes
Frequency:  Irregular (maintenance schedules vary)
Magnitude:  Can be extreme (10-50× normal funding)

Tradeable when: spike is large enough to cover round-trip fees
Warning: maintenance timing uncertain → difficult to plan
```

### Pattern D: Oracle Lag in DeFi [VERIFIED in DeFi — but OUT OF SCOPE for this skill]

```
Asset:      Any asset with DeFi protocols using oracle feeds
Reference:  Chainlink/Pyth price feed
Downtime:   Between oracle update heartbeats (varies: 1min to 1hr)
What drifts: DeFi protocol uses stale price while CEX price has moved
Convergence: Next oracle update → protocol reprices
Frequency:  Continuous (between every heartbeat)
Magnitude:  Small per occurrence, but consistent

Scope note: This is DeFi on-chain trading — outside current skill scope (CEX-focused).
  Included for completeness and cross-domain awareness.
  Execution requires on-chain tools, smart contract interaction, MEV protection
  — none of which are covered in this skill.
  If user asks about DeFi arb → note this pattern exists but redirect
  to appropriate DeFi-focused resources.

Tradeable when: CEX price moves significantly between oracle updates
Note: often captured by MEV bots, highly competitive
```

### Pattern E: Redemption Delay NAV Discount [THEORETICAL — mechanism sound, needs data verification]

```
Asset:      Wrapped/tokenized assets with redemption mechanism
Reference:  Underlying asset NAV
Downtime:   Redemption queue long, paused, or weekend-closed
What drifts: Token price vs NAV — discount (can't redeem) or premium (can't mint)
Convergence: Redemption reopens → discount closes
Frequency:  Irregular (depends on redemption demand)
Magnitude:  1-10% in stress, 0.1-1% normally

Tradeable when: discount > redemption fee + time cost
Warning: if redemption never reopens → permanent discount → not drift
```

### Pattern F: Cross-Exchange Settlement Divergence

```
Asset:      Same contract on different exchanges (e.g., BTC options Bybit vs Deribit)
Reference:  Each exchange's own settlement price methodology
Downtime:   Not downtime per se — structurally different references
What drifts: Settlement prices differ because methodologies differ
Convergence: NO guaranteed convergence — different by design

NOT a reference gap trade (no convergence mechanism).
But: if you know HOW settlement prices differ,
you can position to benefit from the known divergence.
Requires: deep understanding of each exchange's settlement rules.
```

---

## 5. Discovering New Reference Gaps

```
The patterns above are KNOWN. New ones can be discovered.

Use the 5-question process in strategies/reasoning.md (Parameter Discovery):
  Q1: What parameters determine value?
  Q2: What is each parameter's reference source?
  Q3: When does each reference have downtime?
  Q4: Does the parameter drift during downtime?
  Q5: Does it converge when reference returns?

When Q4 = yes AND Q5 = yes → new reference gap pattern found.
Document it using the pattern format above:
  Asset, Reference, Downtime, What drifts, Convergence, Frequency, Magnitude

Feed into Composition Engine (composition.md) as a new building block.
```

---

## 6. Second-Order Reference Gaps

```
First-order: parameter X drifts because its reference is absent.
Second-order: parameter Y changes because parameter X drifted.

Example chain:
  IV drifts (MM offline)
  → margin requirement changes (uses IV as input)
  → capital efficiency changes (margin affects position sizing)
  → optimal strategy shifts (can take larger/smaller positions)

  Nobody optimizes across this chain because:
  1. IV drift is temporary
  2. Margin recalculation is periodic
  3. The window is short

  But: if you KNOW the chain, you can:
  - Time entries when IV is temporarily low → margin is loose → larger position
  - Time exits when IV spikes → margin tightens → others forced to reduce

This is an edge from understanding the SYSTEM, not just one parameter.
It requires monitoring multiple parameters simultaneously.

How to find second-order gaps:
  1. Pick any first-order drift from the parameter map
  2. Ask: "what downstream parameter does this affect?"
  3. Trace the chain 2-3 steps
  4. Ask: "does anyone optimize across this chain?"
  5. If no → potential edge

Not every chain is tradeable. Many are too short-lived or too small.
But when found, they're defensible — competitors need system-level thinking.

RISK WARNING:
  - Chain can reverse: IV returns → margin tightens → forced position reduction
  - Timing is critical: window may be hours not days
  - Sizing must account for tightening scenario
    → never use 100% of loose margin, use 60-70% max
  - Second-order effects compound uncertainty — each link adds risk

PRACTICAL APPLICATION:
  This is more about AWARENESS than active trading strategy.
  Knowing the chain helps:
    - Explain unexpected P/L changes
    - Time entries slightly better (not dramatically)
    - Understand why others are forced to exit (liquidation cascades)
    - Recognize when margin is temporarily favorable
  Don't build a strategy around second-order gaps alone.
  Use as enhancement to first-order strategies.
```
