# Composition Engine, Function Extraction & Progressive Descent

Read by: Stage 4 CREATE (when triggered)

---

## 0. Generalized Option Thinking — Read Before Composing

Before using any tool in this file, adopt this mindset:

```
Don't start from "what instruments exist on the exchange."
Start from "what conditional payoffs exist — listed or not?"
```

Every building block is a payoff function. Before composing, re-characterize
each block you're considering:

| Ask | Why |
|-----|-----|
| What is the conditional payoff? | Reveals the TRUE function, not the product name |
| What is the underlying state variable? | May not be price — could be rate, time, solvency |
| What is the implied strike/threshold? | Where does behavior change? |
| What is the implied expiry? | When does it resolve? |
| Is this long or short the condition? | Direction of exposure |

**This often reveals combinations that product names hide:**

```
"Earn 11% APY"
  → conditional payoff: +11% per year IF platform remains solvent
  → underlying: platform solvency + asset custody
  → strike: none (continuous)
  → expiry: until withdrawal
  → long the condition: long platform risk
  → INSIGHT: this is an option on platform solvency
  → combine with: short perp (option on price direction)
  → result: separated platform risk from price risk → delta neutral yield

"Funding rate -0.02%/8hr"
  → conditional payoff: longs receive, shorts pay, every 8hr
  → underlying: basis between perp and spot
  → strike: none (continuous)
  → direction: if you're long perp, you receive
  → INSIGHT: long perp = short-term bet on basis normalizing
  → combine with: short spot (cancel price exposure)
  → result: pure carry trade
```

**Rule: always re-characterize before composing. Never compose by product name alone.**

---

## 1. Composition Engine

### When to Use

```
Composition (this file):  no structure exists yet → BUILD from blocks
Transformation (mechanism-transformations.md): structure exists → MODIFY it
Profile match (profiles/):  known structure → USE its profile

Composition is for Stage 4 CREATE — after profiles have been checked
and no suitable READY candidate found (or user wants something new).
```

### Process

**Step 1: ENUMERATE available blocks with edge**

List every block (instrument + platform) that currently shows non-zero edge.
Include: direction, magnitude, time horizon, capital requirement.

```
Example output:
  Earn XAUT:          +11% APR, cap 0.1 XAUT       [Platform, long XAUT]
  XAUT perp funding:  -0.005%/8hr                   [Instrument, shorts pay]
  XAUT 24APR basis:   +$18, 11 days                 [Instrument, contango]
  BTC IV-RV gap:      24pp                           [Instrument, fear premium]
  USDT Earn:          +12% APR, promo                [Platform, neutral]
  
Note: include blocks even if individually below their profile floor.
      Composition may combine sub-threshold blocks into above-threshold structures.
```

**Partial-data mode — don't get stuck waiting for perfect data:**

```
If exact number unknown, use estimated range:
  e.g., "Earn XAUT: 8-11% APR [ESTIMATED — verify]"

Screening rule:
  Use OPTIMISTIC end of estimate to decide whether to request data.
  (Don't discard potentially viable candidates due to conservative guesses.)
  If optimistic net > floor → worth requesting data to verify.
  If optimistic net < floor → skip, don't waste user's time.

After data received:
  Use REALISTIC estimate for final net calculation.
  
This prevents asking for 6 screenshots before knowing if anything is viable.
Request data only for candidates that survive optimistic screening.
```

**Step 2: PAIR blocks by exposure management**

Three modes — choose based on user intent:

```
Mode A — Delta Neutral (isolate non-price edge):
  Pair blocks to cancel price exposure.
  Use for: carry trades, yield capture, basis arb.
  Core pairs:
    Long asset + Short perp          → isolate carry
    Long asset + Short dated future  → lock basis
    Earn deposit + Short perp        → isolate platform yield
    Long perp A + Short perp B       → isolate funding differential

Mode B — Directional with Bounds (express view + manage risk):
  Pair blocks to express direction + limit downside.
  Use for: belief-driven structures, hedged directional.
  Required: user has stated a belief or direction preference.
  Core pairs:
    Earn deposit + buy OTM call      → yield + leveraged upside
    Long spot + buy put + sell call  → collar (bounded range)
    Bull call spread + PM No         → capped upside + downside repair

Mode C — Hedged Single Block (protect one position):
  Add hedge to existing block to modify risk profile.
  Use for: Earn + put protection, spot + collar.
  Core pairs:
    Earn deposit + buy put           → yield with floor
    Long spot + sell call            → covered call (income)
    Perp position + options hedge    → bounded risk on direction
```

For ALL modes, check:

```
  □ Same underlying or correlated?
  □ Time horizons compatible?
  □ Settlement aligned?
  □ Combined risk profile acceptable?
```

**Step 3: CALCULATE net edge**

```
net = Σ income_sources − Σ cost_sources

Income: yield APR, funding received, basis captured, premium collected
Cost:   fees (all legs), funding paid, borrowing interest, spread/slippage,
        opportunity cost of locked capital

MUST use executable prices (bid for sells, ask for buys).
NEVER use mid prices for net calculation.

If net ≤ 0 → reject this pair.
If net > 0 → continue to Step 4.
```

**Step 4: LAYER (optional)**

If net edge > 0 but small, ask: can a 3rd block amplify without breaking delta?

```
Rules for layering:
  - 3rd block's max loss < locked edge from first 2 blocks
  - 3rd block must add a DIFFERENT type of edge (not just more of same)
  - if 3rd block makes structure cross 3 legs → read payoff-algebra.md
  
Examples:
  Earn + Short Perp + PM No at far threshold → adds tail income
  Spread arb + short OTM put → adds premium income (but adds tail risk)
  
Anti-pattern:
  Adding legs that "look like they help" but don't improve net edge after costs.
  Always re-calculate net with ALL legs included.
```

**Step 5: RANK candidates**

```
Score = net_edge_APY / sqrt(legs × capital_ratio)

capital_ratio = capital_required_for_this_strategy / total_available_capital
  e.g., strategy needs $500 out of $5000 total → capital_ratio = 0.1

Higher score = better risk-adjusted edge per unit of complexity and capital.
Simple 2-leg with 5% net > Complex 4-leg with 7% net (usually).

IMPORTANT: ensure all candidates use same unit (APY) before ranking.
  Convert %/8hr → APY: rate × 3 × 365
  Convert $/trade → APY: (profit / capital) × (365 / holding_days) × 100

Rank by score, then apply pre-screen (Section 4 below) to top candidates.

For complex designs with >3 surviving candidates after pre-screen:
  → Read strategies/mechanism-transformations.md Section 3 
    for comprehensive 8-dimension scoring (worst-case, EV, fillability,
    simplicity, mismatch, scanner-readiness, robustness, capital efficiency).
  Use the simple formula above for quick comparison;
  use the 8-dimension scoring when candidates are close and decision is hard.
```

---

## 2. Function Extraction

### The Problem Composition Alone Can't Solve

```
Composition Engine:
  enumerate blocks → pair → calculate → rank
  
  This finds combinations of KNOWN blocks.
  It does NOT find new USES for existing blocks.
  
Function Extraction:
  "What does this block ACTUALLY DO in math?"
  → apply that function to problems it wasn't designed for
  → discover uses nobody intended
```

### 3 Questions for Every Block

Before composing, ask:

**Q1: "What does this block do in math?"**

Not "what is it called" but "what is its payoff function?"

```
PM Above Yes at K:   pays $1 if S > K, else $0 → digital call
Put option at K:     pays max(K-S, 0) → convex downside protection
Earn deposit:        pays APR × balance × time → fixed yield
Funding rate:        pays rate × position × time → variable carry
```

**Q2: "What problems can this function solve?"**

Not just the "intended" use, but ANY problem with matching shape:

```
Digital call function → solves:
  ✓ Directional bet (intended)
  ✓ Cheap insurance (buy PM No at far strike instead of expensive put)
  ✓ Income generation (sell PM Yes at far strike)
  ✓ Pricing cross-check (PM probability vs options-implied probability)
  ✓ Binary payoff replication (approximate with tight option spread)

Fixed yield function → solves:
  ✓ Passive income (intended)
  ✓ "Implied dividend" for options pricing (Earn rate affects put-call parity)
  ✓ Cost offset (Earn yield can subsidize hedge cost)
  ✓ Baseline comparison (any strategy must beat this)
```

**Q3: "If I didn't know this product existed, and I faced this problem, would I invent something like it?"**

```
Problem: "I want income from XAUT without price risk"
If I didn't know Earn existed, would I invent "deposit asset, receive yield"?  → Yes
If I didn't know perp existed, would I invent "short to hedge price"?  → Yes
→ Earn + Short Perp is a natural solution to this problem.

Problem: "I want to bet BTC stays below $80K cheaply"  
If I didn't know PM existed, would I invent "pay small amount, receive $1 if correct"?  → Yes
→ PM No above $80K is the natural solution.
→ But: also check if selling a call above $80K is cheaper for same function.

If answer is NO → don't force-fit. The tool doesn't match the problem.
```

### Substitutability Check

When one block is too expensive or unavailable, check if another block
provides the same function:

```
Function: binary payoff at boundary K
  PM Yes/No at K  (native digital, cheap if liquid)
  Tight call spread ÷ width  (synthetic digital, always available)
  → choose cheaper / more liquid one

Function: linear downside protection below K
  Put option at K  (convex, bounded cost)
  Stop-loss order at K  (synthetic put, execution risk)
  PM No above K  (binary, only pays if far below)
  → choose based on precision needed + cost

Function: yield on deposited asset
  Earn product  (platform risk)
  Staking  (protocol risk, may have lock period)
  Lending pool  (utilization risk, variable rate)
  → choose based on risk profile + rate
```

### Common Cross-Application Patterns (Concrete)

When the obvious approach doesn't work, try these substitutions:

```
Problem: Protection too expensive (put costs too much)
  → try PM No at same boundary (binary, may be cheaper)
  → try zero-cost collar (sell call to fund put)
  → try Earn deposit as "yield buffer" against drawdown

Problem: Yield too low (Earn below floor)
  → try Earn + sell OTM call (covered call adds premium income)
  → try Earn + PM No at far strike (adds tail income)
  → WARNING: both add risk — Earn alone may be better after baseline comparison (Gate 2)

Problem: Arb too thin (conversion edge ≈ 0)
  → try different strikes (OTM may have wider parity gaps)
  → try different expiry (near-dated often less efficient)
  → try different asset (less liquid asset = wider gaps)

Problem: Hedge cost too high (funding eats Earn yield)
  → try dated future instead of perp (lock cost, remove variability)
  → try shorter hedge duration (reduce cost exposure window)
  → try partial hedge (hedge 70% not 100%, accept some price risk)

Problem: Can't build desired payoff shape
  → check payoff-algebra.md for constraint relaxation hierarchy
  → relax precision first, then upside cap, then participation rate
  → simplest relaxation that preserves core intent
```

---

## 3. Progressive Descent

### Principle

```
Don't stop at the first failure. Try every level before saying "no opportunity."
But also don't force acceptance — if nothing is worth it, say so.
```

### Descent Ladder

Within the filtered pool (after Stage 2 FILTER removed regime-wrong):

**Effort budget — one check per level, don't deep-dive:**

```
Lv.1 Pure Arb:    Quick check ATM±2 strikes. Not obvious → move on.
Lv.2 Near-Pure:   Check available dated contracts vs floor. Below → move on.
Lv.3 Near-Arb:    Compute 1 net formula (funding or Earn). Below floor → move on.
Lv.4 Structured:  1 IV check + 1 platform rate check. Below floor → move on.
Lv.5 Speculation: Only if user stated belief. No belief → skip entirely.

Principle: 1 check per level. Pass → explore deeper. Fail → next level.
Don't spend effort deep-analyzing a level that fails the first check.
```

```
TRY Lv.1 Pure Arb:
  Check: conversion parity, box spread, cross-exchange spot, PM parity
  Tools: direct calculation from prices
  If found with edge > fees → READY (best possible outcome)
  If not → descend

TRY Lv.2 Near-Pure:
  Check: dated futures basis, calendar spread, reverse cash-carry
  Tools: basis calculation, term structure analysis
  If found above profile.entry → READY
  If not → descend

TRY Lv.3 Near-Arb:
  Check: funding harvest/reverse, cross-exchange funding, earn+hedge
  Tools: funding rate analysis, net formula calculation
  If found above profile.entry → READY
  If not → descend

TRY Lv.4 Structured:
  Check: sell vol (IV-RV gap), platform yield, weekend gap, spread arb
  Tools: IV analysis, platform rate check, schedule check
  If found above profile.entry → READY
  If not → descend

TRY Lv.5 Speculation:
  Check: directional + hedge, risk reversal
  Tools: belief + payoff engineering
  If found with acceptable risk/reward → READY
  If not → no opportunity

AT EACH LEVEL:
  Don't just check cataloged strategies.
  Also try COMPOSITION (Section 1) with blocks available at that level.
  e.g., at Lv.3: compose Earn + Short Perp (may not be a cataloged profile)
```

### When Descent Reaches Bottom

```
If no opportunity found at any level:

  Present honestly:
    "No opportunity above floor at any level.
     
     Closest candidates:
       [Lv.X strategy] — current [metric] = Y, needs Z to reach entry
       [Lv.W strategy] — current [metric] = V, needs U to reach entry
     
     Best baseline available: [platform yield X% or hold cash]
     
     Conditions for opportunities to appear:
       Lv.1-2 arb: [specific market condition needed]
       Lv.3 near-arb: [specific condition]
       Lv.4 structured: [specific condition]
     
     Recommended re-scan trigger: [what to watch for]"
```

### Descent Does NOT Mean "Accept Anything"

```
IMPORTANT: Descent forces you to TRY every level.
It does NOT force you to ACCEPT sub-threshold results.

If Lv.4 is the best you find but it's below floor:
  → don't present it as viable
  → present it as "closest to viable, needs X to work"
  → recommend baseline instead

Descent + Worth-It gates work together:
  Descent: ensures you don't give up too early
  Gates: ensure you don't accept too easily
```

---

## 4. Pre-Screen Before Merging to READY

Every new candidate from composition/extraction/descent must pass:

```
1. NAME MECHANISM
   "What creates this edge?"
   
   Acceptable:
     □ Parity convergence (futures settle to spot)
     □ Platform subsidy (Earn promo, zero-fee campaign)
     □ Reference gap (TradFi closed, oracle lag)
     □ Crowd mispricing (IV > RV, extreme funding)
     □ Structural inefficiency (low liquidity, no arb infra)
     □ Time structure (settlement mismatch, funding cycle)
   
   Not acceptable:
     □ "Numbers are positive" (no mechanism named)
     □ "Backtest shows profit" (no forward-looking reason)
     □ "Multiple legs combine well" (no per-leg attribution)
   
   Can't name mechanism → REJECT

2. REPEATABILITY
   "If I execute this tomorrow, does the edge still exist?"
   
   YES if mechanism is structural (parity, subsidy, time gap)
   NO if edge is from snapshot pricing (bid-ask noise, momentary glitch)
   MAYBE if edge depends on regime (funding direction, IV level)
     → for MAYBE: note dependency, flag as regime-sensitive
   
   NOT repeatable → REJECT (accidental combination)

3. DECOMPOSE — attribute edge to specific legs
   "Remove each leg one at a time. Does the structure still work?"
   
   If removing leg X doesn't change the edge:
     → leg X is noise → remove it → simpler structure is better
   If all legs contribute:
     → integrated structure → proceed
   If no leg alone has edge but combination does:
     → verify mechanism explains WHY combination works
     → if can't explain → likely accidental → REJECT

4. EVERY LEG JUSTIFIED
   Each leg must improve worst-case OR expected value.
   If a leg neither improves worst-case nor EV → remove it.
   
   Common trap: adding a PM overlay that "improves" one scenario
   but costs more than it saves across all scenarios.

5. COMPLEXITY TAX
   Adding N extra legs must improve net edge by more than N × marginal cost.
   
   marginal cost per leg ≈ execution fee + monitoring effort + legging risk
   Ballpark: ~0.05-0.1% (fee + spread) per leg. Each leg must add ≥$5-10 per cycle.
   
   If complexity tax > edge improvement → simplify first, then re-evaluate.
```

---

## 5. Conversation as Discovery

### Capturing New Insights

```
Every conversation can reveal new building blocks or combinations.
```

**Insight triggers — capture when user says something that:**

```
1. CONNECTS two products that skill treats separately
   e.g., "Earn rate and funding rate are the same thing"
   → insight: both measure cost-of-carry, set by different mechanisms → gap = edge

2. QUESTIONS a "constant" in the model
   e.g., "Fee tier changes if volume reaches X"
   → insight: cost is variable not fixed → optimal timing around volume thresholds

3. NAMES an analogy from another domain
   e.g., "This is like dividend stock + short futures in TradFi"
   → insight: known TradFi pattern → validate if crypto version works

4. OBSERVES a contradiction
   e.g., "Why did XAUT funding flip direction?"
   → insight: possible regime shift or structural change → investigate

5. ASKS "can we use X for Y?" where Y is not X's intended purpose
   e.g., "Can PM hedge funding risk?"
   → insight: cross-application attempt → evaluate if functions match
```

**Process after capturing:**

```
  1. Capture the insight
  2. Re-characterize using Function Extraction (3 questions)
  3. Try to compose with existing blocks
  4. If viable → new candidate for READY pool
  5. If not viable now → note what would need to change
```

### Logging What's Missing

```
When composition stops at a certain level, record:

  reached:           Lv.4 (Earn + platform yield)
  blocked_by:        perp funding negative → hedge cost > Earn rate
  would_upgrade_if:  
    - funding turns positive (hedge becomes free)
    - Earn rate increases (more buffer above hedge cost)
    - fixed-rate borrow product launches (lock hedge cost)
  revisit_when:
    - funding rate flips to positive
    - new Earn promo announced
    - new instrument listed for this asset

This log helps future conversations start from where this one ended,
rather than repeating the same dead-end analysis.
```

---

## 6. Composition Checklist (Quick Reference)

```
□ Re-characterized all blocks? (Section 0)
□ Enumerated all blocks with edge? (Step 1)
□ Tried pairwise combinations? (Step 2)
□ Calculated net at executable prices? (Step 3)
□ Considered layering if net is thin? (Step 4)
□ Checked function substitutability? (Section 2)
□ Tried all levels in descent? (Section 3)
□ Pre-screened every candidate? (Section 4)
□   1. Named mechanism?
□   2. Repeatable?
□   3. Decomposed — every leg contributes?
□   4. Every leg justified?
□   5. Complexity tax passes?
□ Compared to profile floor if resembles known strategy? (Stage 4 cross-check)
□ Logged what's missing if stopped early? (Section 5)
```
