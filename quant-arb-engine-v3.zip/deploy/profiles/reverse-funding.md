```yaml
identity:
  name:        Reverse Funding Harvest
  type:        Lv.3 Near-Arb
  mechanism:   When crowd is heavily short, funding is negative → longs receive payment.
               Short spot (margin) + long perp = delta neutral, collect reverse funding. [STRUCTURAL]
  maturity:    CATALOGED

timing:
  regime:        Bear + funding consistently < -0.005%/8hr
  avoid_regime:  Funding > -0.005%/8hr (not negative enough to cover borrow cost)
  best_when:     Funding extreme negative (<-0.03%/8hr) during panic/capitulation

operating_range:
  floor:         -0.005%/8hr (≈6.5% APY equivalent)
  entry:         -0.01%/8hr (≈13% APY)
  normal:        -0.005 to -0.03%/8hr
  exceptional:   < -0.05%/8hr — panic events
  metric:        %/8hr absolute value (primary). APY in parentheses.
  range_basis:   same math as funding-harvest but higher floor needed because
                 borrow cost for short spot is typically higher than long spot margin.
  recalibrate_when: borrow rate structure changes, new short-selling products appear.

alternatives:
  when_below_floor:  platform-yield (no borrow cost issue)
  when_regime_wrong: funding-harvest (bull regime, opposite direction)
  simpler_version:   platform-yield (1 leg)

execution:
  style:         duration-based — mirror of funding harvest but opposite direction
  entry_signal:  funding < entry threshold for ≥2 consecutive periods
  exit_signal:   funding rises above -floor OR flips positive for ≥2 periods
  position_mgmt: same as funding harvest — check every 8hr

verification:
  must_check:
    - funding rate current + predicted
    - spot BORROW cost for short selling (KEY — often expensive)
    - net = |funding income| - borrow cost - fees → must be positive
    - borrow availability (can you short this amount?)
  freshness:
    - funding rate: < 8 hours
    - borrow rate: < 24 hours (can spike suddenly)
  platform_reqs: Margin short selling enabled. Sufficient borrow pool.

costs:
  net_formula:   net_per_period = |funding_rate| - (short_borrow_rate / 3) - entry_fees_amortized
                 WARNING: short borrow rate is usually MUCH higher than long borrow.
  formula_example: funding -0.015%/8hr, short borrow 15% APY (= 0.0137%/8hr)
                   net = 0.015% - 0.0137% - 0.0006% = 0.0007%/8hr ≈ 0.8% APY
                   (nearly zero — borrow kills most of the edge)
  fees:          same as funding harvest
  hidden_costs:  BORROW COST IS THE MAIN HIDDEN COST — often > funding income.
                 Must verify net BEFORE entering. Many reverse funding trades
                 look profitable on funding alone but lose money after borrow.
  min_profit:    $10 per day

risks:
  primary:       Borrow cost exceeds funding income → net negative despite "receiving" funding
  secondary:     Borrow recall (forced close), short squeeze
  kill_condition: Borrow rate spikes above funding income, or borrow pool dries up
  what_can_go_wrong: Enter when funding = -0.02%/8hr, borrow = 0.01%/8hr (net +0.01%).
                     Borrow spikes to 0.03%/8hr → now net -0.01% → losing money.
                     Must exit immediately but short squeeze makes exit expensive.
```
