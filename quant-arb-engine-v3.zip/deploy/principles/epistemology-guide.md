# Epistemology Guide — Knowledge Classification for Skill References

Every claim in the skill references MUST carry one of the following labels.
This prevents treating opinions as facts and prevents dismissing observations as guesses.

---

## Label Definitions

### [Exact Identity]
Mathematical truth. Holds unconditionally by definition or proof.
Does not depend on market conditions, regime, or platform.

**Examples:**
- Put-call parity: C − P = S − PV(K)
- Box spread value = PV(K2 − K1)
- PM Yes + PM No on same event = $1 (by contract design)
- Conversion payoff is locked if all legs are filled simultaneously

**When to trust:** Always. These are definitional.

---

### [Contract-specific]
True by the rules of a specific contract, platform, or exchange.
Verify by reading the actual contract rules. May change if platform updates rules.

**Examples:**
- Polymarket "hit in month" is a touch market (resolves on first touch)
- Deribit ETH options are European-style (no early exercise)
- Binance BTC/USDT is the resolver for specific Polymarket markets

**When to trust:** Trust after verifying the specific contract rules.
Re-check if using a different platform or if rules have been updated.

---

### [Observed — Date-stamped]
Directly observed from real market data at a specific point in time.
The observation is factual (it happened), but the CONDITIONS may have changed since.
Do NOT assume these observations still hold — re-verify with current data.

**Examples:**
- ETH conversion edge on Bybit ≈ $0 after fees (March 2026, 3 APR expiry)
- ETH PM Range overround ≈ 21% (Polymarket, March 2026)
- BTC funding on Binance = +0.003% on March 25, negative on March 29
- SOL PM "above 400" No rate = 82¢ (from notebook, late 2025 data)

**When to trust:** The observation itself is reliable. But the specific numbers
are snapshots — they WILL be different next time you look. Always re-scan.

---

### [Heuristic — Tested]
A rule of thumb that was tested against real data and found to work in the
conditions tested. May fail in different conditions. Use as starting point,
not as guarantee.

**Examples:**
- No rate sweet spot for PM + Options structures: 70-85¢
- Touch market needs ~2× the threshold distance vs Close market
- N_min = options_cost / PM_income_per_contract

**When to trust:** Good starting point. Adjust based on current conditions.
If the regime changes significantly, re-test the heuristic.

---

### [Heuristic — Untested]
A rule of thumb based on reasoning or analogy but NOT yet validated against
real data. Treat as hypothesis to be tested, not as established knowledge.

**Examples:**
- PM Calendar Spread (buy far-month No, sell near-month No) could capture time decay differential
- Cross-asset PM vol comparison could reveal mispricing
- Perp funding + PM combo could work on assets without options

**When to trust:** Do NOT trust until paper-traded or backtested.
These are ideas, not strategies.

---

### [Opinion — Analytical]
An interpretation or conclusion drawn from observations, but where
reasonable analysts could disagree. Often involves judgment about
causation, future behavior, or relative ranking.

**Examples:**
- "SOL is the best asset for PM + Options structures" → based on current data,
  but another asset could become better if conditions change
- "Hand β is better than Hand γ" → based on scoring that involves subjective weights
- "ETH options market is efficient" → based on one snapshot; could be inefficient at other times
- "Funding rate arb is Lv.5 not Lv.2" → classification involves judgment about
  what counts as "locked" vs "unlocked"
- "Best entry for monthly PM is first day of month" → reasonable but not proven across all conditions

**When to trust:** Consider the reasoning. If the reasoning is sound and
matches current conditions, use it. But always be aware that it's an opinion,
not a fact. Be open to revising.

---

### [Structural Impossibility]
Proven to be impossible by construction. Not just unlikely — mathematically
impossible under the stated assumptions.

**Examples:**
- PM-only non-negative when Σ Ask > $1 → impossible [Exact Identity]
- Unlimited upside + non-negative everywhere with finite instruments → impossible
- Non-negative PERP funding rate arb → impossible (perp funding can flip by design)
- Non-negative DATED futures basis arb → POSSIBLE [Exact Identity] (converges at expiry)
  NOTE: do not confuse these two. They are structurally different instruments.

**When to trust:** Always, under the stated assumptions. But check if the
assumptions still hold for your specific situation.

---

## Application to the 3 New Reference Files

### pm-question-types.md

| Section | Claims that need careful labeling |
|---------|----------------------------------|
| §1 Type taxonomy | [Contract-specific] — rules differ per platform, verify |
| §2 Type selection table | [Opinion — Analytical] — "best" involves judgment |
| §3 Asset selection | [Heuristic — Tested] for SOL vs ETH comparison; [Opinion — Analytical] for ranking table |
| §3 Asset ranking (★ table) | [Opinion — Analytical] — ranking will change as markets evolve |
| §4 Time decay patterns | [Heuristic — Tested] for "flat then jump" pattern; needs more data points |
| §4 "80% of time flat" | [Observed — limited sample] — based on handful of observations, not systematic study |
| §5 Entry timing | [Heuristic — Untested] — reasonable logic but not backtested |
| §6 Maturity strategies | [Heuristic — Tested] for matching expiry; [Heuristic — Untested] for sell-early strategy |
| §7 Platform reference | [Contract-specific] — verify current offerings |

### cross-instrument-optimization.md

| Section | Claims that need careful labeling |
|---------|----------------------------------|
| §1 PM payoff is step function | [Exact Identity] — by contract definition |
| §1 "No closed-form solution" | [Exact Identity] — piecewise linear + step = no smooth optimizer |
| §2 Critical points | [Exact Identity] — piecewise linear only needs kink checks |
| §3 Constraints C1-C7 | [Exact Identity] for C1, C2, C3, C4; [Heuristic — Tested] for C5-C7 |
| §3 N_min, N_max formulas | [Exact Identity] — algebraic derivation |
| §4 Iterative process | [Heuristic — Tested] — validated in notebook example |
| §5 SOL worked example | [Observed — from notebook] — specific numbers are date-stamped |
| §5 "Notebook uses N=1.8 → not fully non-neg" | [Exact Identity] — calculable from payoff algebra |
| §6 "No rate 70-85¢ sweet spot" | [Heuristic — Tested] but limited sample |
| §6 "SOL works, ETH doesn't" | [Observed — March 2026] — may change in different regime |

### real-world-discoveries.md

| Section | Claims that need careful labeling |
|---------|----------------------------------|
| §1 Non-neg design principle | [Heuristic — Tested] for the rule; [Exact Identity] for the locked-edge table |
| §1 "Funding is NOT locked" | [Exact Identity] — funding can flip by contract design |
| §2 Regime playbook | [Observed — March 2026] for market conditions; [Opinion — Analytical] for strategy viability ratings |
| §2 Hand rankings (β > γ > α) | [Opinion — Analytical] — scoring involves subjective dimension weights |
| §3 ETH efficiency observation | [Observed — March 2026, single snapshot] |
| §3 SOL vs ETH vol gap | [Observed — specific data points] — gap may narrow or widen |
| §4 Funding rate swing in 4 days | [Observed — March 25-29, 2026] |
| §4 "Cross-exchange funding = Lv.5" | [Opinion — Analytical] — classification involves judgment |
| §4 "Funding = bonus, never core" | [Heuristic — Tested] based on observed flips |
| §5 Scanner tools list | [Factual] — these tools exist; features may change |
| §6 Novel ideas 1-4 | [Heuristic — Untested] — ALL are hypotheses, not validated strategies |
| §7 Heuristics summary table | Mixed — each row carries its own label from source section |

---

## How to Use This Guide

When reading any claim in the skill references:

1. Check the label
2. If [Exact Identity] → trust unconditionally
3. If [Contract-specific] → verify the contract rules still match
4. If [Observed] → re-scan with current data before relying on it
5. If [Heuristic — Tested] → use as starting point, adjust for current conditions
6. If [Heuristic — Untested] → paper-trade first, do not deploy with real capital
7. If [Opinion — Analytical] → consider the reasoning, be open to alternatives
8. If [Structural Impossibility] → trust, but verify assumptions still hold

**Default behavior:** If a claim has no label, treat it as [Opinion — Analytical]
until verified. Absence of label = lowest trust level.
