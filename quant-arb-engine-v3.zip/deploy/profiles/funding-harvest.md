```yaml
identity:
  name:        Funding Rate Harvest
  type:        Lv.3 Near-Arb
  mechanism:   When crowd is heavily long, funding rate is positive → shorts receive payment.
               Spot long + perp short = delta neutral, collect funding. [STRUCTURAL]
  maturity:    CATALOGED

timing:
  regime:        Bull + funding consistently > +0.005%/8hr
  avoid_regime:  Funding < +0.005%/8hr (below floor, not enough to cover costs)
  best_when:     Funding extreme positive (>0.03%/8hr) during FOMO/leverage spike

operating_range:
  floor:         0.005%/8hr (≈6.5% APY) — below this, fees eat too much
  entry:         0.01%/8hr (≈13% APY)
  normal:        0.005-0.03%/8hr (≈6.5-39% APY)
  exceptional:   >0.05%/8hr (≈65% APY) — rare, usually during major FOMO
  metric:        %/8hr (primary). APY in parentheses for cross-strategy comparison.
                 Convert: APY = rate × 3 × 365
  range_basis:   floor = entry fees (~0.24%) amortized over ~14 days ≈ 0.005%/8hr.
                 below this, fee drag exceeds funding income.
  recalibrate_when: fee tiers change, or funding settlement frequency changes
                    (some exchanges moving to 4hr or 1hr funding).

alternatives:
  when_below_floor:  platform-yield (no directional dependency)
  when_regime_wrong: reverse-funding (bear regime, opposite direction)
  simpler_version:   platform-yield (1 leg, no funding monitoring)

execution:
  style:         duration-based — hold while funding stays favorable
                 NOT multi-cycle on spread. Funding is a continuous flow, not a convergence.
  entry_signal:  funding rate > entry threshold for ≥2 consecutive periods (16hr)
  exit_signal:   funding drops below floor OR flips negative for ≥2 periods
  position_mgmt: check funding every 8hr. no action needed while above floor.
                 if funding trending down → prepare to exit, don't wait for flip.

verification:
  must_check:
    - funding rate current + predicted next period
    - spot borrowing cost (if using margin for spot long)
    - net = funding income - borrow cost - fees → must be positive
    - cross-exchange comparison (is this exchange's rate abnormal?)
  freshness:
    - funding rate: < 8 hours (changes every period)
    - borrow rate: < 24 hours
  platform_reqs: Spot + perpetual on same exchange. Spot Hedging enabled in UTA.

costs:
  net_formula:   net_per_period = funding_rate - (borrow_rate / 3) - entry_fees_amortized
                 net_APY = net_per_period × 3 × 365
                 entry_fees_amortized = round_trip_fees / (holding_days × 3)
  formula_example: funding 0.02%/8hr, borrow 8% APY (= 0.0073%/8hr), 
                   round-trip fees 0.24%, holding 14d → amortized = 0.24%/42 = 0.0057%/8hr
                   net = 0.02% - 0.0073% - 0.0057% = 0.007%/8hr ≈ 7.7% APY
                   (profitable but much lower than headline ~22% — borrow + fees eat 65%)
                   
                   BREAK-EVEN: funding must be > borrow + amortized fees
                   = 0.0073% + 0.0057% = 0.013%/8hr (~14% APY) to just break even
                   Below this → losing money despite "receiving" funding
  fees:          spot taker ~0.1% + perp maker ~0.02% × 2 sides
  hidden_costs:  spot borrowing interest (hourly, variable),
                 funding rate can flip between entry and first collection
  min_profit:    $10 per day (2 legs, ongoing monitoring)

risks:
  primary:       Funding rate flips negative — you start paying instead of receiving
  secondary:     Spot borrow rate spikes, liquidation if margin insufficient
  kill_condition: Funding flips negative for >3 consecutive periods
  what_can_go_wrong: Enter at 0.02%/8hr, funding drops to 0.001%/8hr within 24hr.
                     Still positive but barely covers borrow cost → net near zero.
                     Not a loss, but wasted capital and effort.
```
