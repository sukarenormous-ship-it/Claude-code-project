# Cross-Instrument Optimization & Iterative PM Sizing

## Table of Contents

1. Why Iterative, Not Formula-Based
2. Critical Points to Check
3. Optimization Framework
4. Iterative Tuning Process (Practical)
5. Worked Example: SOL Protective Put + PM Bet No
6. The Options-PM Distance Constraint
7. Summary: The Complete Workflow

---

This reference provides the optimization framework for combining options and PM legs
into non-negative payoff structures. The key insight is that PM payoff is LINEAR
(step function), so there is no closed-form optimizer — N (PM contract count)
is found by iterative adjustment while watching the payoff chart.

---

## 1. Why Iterative, Not Formula-Based

### PM Payoff is Piecewise Linear

```
PM Bet No at threshold T, No rate = R:
  payoff(S) = { +(100 - R)  if S < T    (No wins)
              { -R          if S ≥ T    (No loses)
              
N contracts:
  payoff(S) = { +N × (100 - R)  if S < T
              { -N × R          if S ≥ T
```

This is a **step function** — it has exactly one discontinuity at S = T.
Combined with the smooth payoff from options (which is piecewise linear for
spreads, curved for single options), the total portfolio payoff is piecewise
linear with kinks at each option strike and at the PM threshold.

### Partial Closed-Form for N, But Not for Joint Optimization

Once the structure is fixed (K1, K2, T chosen), N CAN be solved algebraically:
  N for S<T region: N = |worst_payoff_without_PM| / PM_income_per_contract
  N for S=T region: N = (spot_gain_at_T − options_cost) / PM_loss_per_contract
  N* = the value that satisfies BOTH constraints simultaneously

However, the JOINT optimization of K1, K2, T, AND N together has no closed-form
because the feasibility region depends on PM market availability (discrete thresholds),
options liquidity (discrete strikes), and their interaction.

The practical approach is:

```
1. Fix options structure (K1, K2, option type, cost)
2. Fix PM parameters (T, No rate)
3. Start with N = 0
4. Increment N (by 0.1, 0.5, or 1.0)
5. At each N, evaluate payoff at ALL critical points
6. Stop when payoff ≥ 0 at all critical points
7. Check: is N ≤ N_max (safety constraint)?
```

This is exactly what practitioners do — adjust N while watching the payoff chart
until the curve lifts above zero everywhere.

---

## 2. Critical Points to Check

The payoff function only needs to be checked at **kink points** because
it is linear between kinks. If payoff ≥ 0 at every kink, it is ≥ 0 everywhere.

### Critical Points for Protective Put + PM Bet No

```
Structure: Long Spot(entry) + Long Put(K1, cost=P) + N × Bet No(T, noRate=R)

Critical points:
  S = 0          (extreme downside — theoretical)
  S = K1         (put strike — payoff shape changes here)
  S = entry      (breakeven point for spot)
  S = T - ε      (just below PM threshold — No still wins)
  S = T          (AT PM threshold — No LOSES here)  ← MOST CRITICAL
  S = very high  (extreme upside)
  
Most binding constraints are usually at S = entry (the kink from put cost)
and at S = T (where PM flips from winning to losing).
```

### Critical Points for Bull Call Spread + PM Bet No

```
Structure: Long Call(K1) + Short Call(K2) + N × Bet No(T, noRate=R)

Critical points:
  S = K1         (long call starts paying)
  S = K2         (short call caps payoff)
  S = T - ε      (PM No still wins)
  S = T          (PM No loses)
  
The "kink" that needs PM income to fix is the region S < K1
where the spread is worthless and only PM income matters.
```

---

## 3. Optimization Framework

### Decision Variables

```
K1 = protective put strike (or long call strike)
K2 = short call strike (if using spread) [optional]
T  = PM threshold
N  = number of PM contracts (can be fractional, e.g., 1.8)
```

### Objective Function — TWO options (NOT equivalent)

```
Objective A (Maximum Safety — maximin):
  Maximize: min{payoff(S) for all S in price range}
  → Finds N where the WORST scenario is as good as possible
  → Often results in N between N_min and N_max (not at boundary)
  → Use when: priority is robustness and worst-case protection

Objective B (Maximum Income):
  Maximize: N × PM_income_per_contract
  Subject to: payoff(S) ≥ 0 for all S in [S_min, S_max]
  → Always pushes N to N_max (the highest N where non-negative still holds)
  → Use when: priority is extracting maximum PM income
  
WARNING: These are NOT equivalent.
  Objective A → conservative N (best worst-case)
  Objective B → aggressive N (maximum income, worst-case = exactly $0)
  
  Choose based on risk preference. Objective A is safer.
```

### Constraints

```
C1 (Non-negative):
    payoff(S) ≥ 0 for all S
    → Check at all critical points (kinks + PM threshold)

C2 (PM safety at threshold — covers S ≥ T region):
    spot_gain_at_T − options_cost − N × R ≥ 0
    → N ≤ (spot_gain_at_T − options_cost) / R
    This is N_max — the maximum contracts before PM loss overwhelms spot gain
    NOTE: this constraint ensures non-negative ONLY at S = T and above

C3 (PM income covers options cost — covers S < T region):
    N × (100 − R) / 100 ≥ options_net_cost
    → N ≥ options_net_cost / ((100 − R) / 100)
    This is N_min — the minimum contracts to fund the options
    NOTE: this ensures non-negative ONLY when PM No wins (S < T)
    
    BOTH C2 and C3 must hold simultaneously for full non-negative.
    C3 alone does NOT guarantee non-negative — it only covers the S < T region.
    C2 alone does NOT guarantee non-negative — it only covers the S ≥ T region.

C4 (Feasibility):
    N_min ≤ N_max
    If N_min > N_max → structure is INFEASIBLE → choose different parameters

C5 (Budget):
    options_cost + N × R / 100 ≤ available_capital

C6 (PM market exists):
    T must correspond to an actual PM market with sufficient liquidity

C7 (Options market exists):
    K1, K2 must have listed options with acceptable bid-ask spread
```

### The Sweet Spot

```
N_min ≤ N* ≤ N_max

where N* is chosen to maximize the minimum payoff across all scenarios.

In practice: start at N_min and increase toward N_max,
watching the payoff chart for the point where the minimum payoff
across all scenarios is maximized.
```

---

## 4. Iterative Tuning Process (Practical)

### Step 1: Fix Options First

### Step 1 (Detail): Fix K1, Then SCAN K2 Options

```
Choose K1 from belief (e.g., entry point for upside participation)

DO NOT fix K2 immediately. Instead, scan all available K2:
  1. List every strike with liquid options AND matching PM threshold
  2. For each K2, calculate:
     - W = K2 − K1 (spread width)
     - C = ask(K1) − bid(K2) (executable spread cost)
     - p = PM No price at or near K2
     - N_min = C / (1 − p)
     - N_max = (W − C) / p
  3. Reject any K2 where N_min > N_max (infeasible)
  4. Rank surviving K2 by:
     - Safety margin (N_max − N_min)
     - Worst-case floor at optimal N
     - Deployability (fill size, depth)
  5. Present top 2-3 candidates with trade-offs

(Optional: add short call at K2 for spread)

Plot: payoff_options(S) = spot(S) + put(S) − P [− call(S) if spread]

Identify: the "kink" — the lowest point on the chart (usually at S ≈ entry)
          kink_depth = |min(payoff_options)|
```

### Step 2: Select PM Market

```
Scan available PM markets for the chosen asset
Find threshold T where:
  - T is far from spot (safety)  
  - No rate ≤ 85¢ (enough income per contract) [Heuristic]
  - Question type matches strategy (Close vs Touch)
  - Resolution date aligns with options expiry (or acceptable mismatch)
```

### Step 3: Calculate Bounds

```
PM income per contract = (100 − noRate) / 100
PM loss per contract = noRate / 100

N_min = kink_depth / PM_income_per_contract
N_max = (spot_gain_at_T − options_cost) / PM_loss_per_contract

If N_min > N_max → INFEASIBLE
  → Options: reduce kink_depth (cheaper put, tighter spread)
  → Or: find PM with better income (different asset, different question type)
```

### Step 4: Iterate N from N_min to N_max

```python
# Pseudocode for iterative tuning
for N in range(N_min, N_max, step=0.1):
    for S in critical_points:
        payoff = spot_payoff(S) + option_payoff(S) + N * pm_payoff(S)
    min_payoff = min(payoffs at all critical points)
    if min_payoff >= 0:
        print(f"N = {N} achieves non-negative payoff")
        print(f"Minimum payoff = {min_payoff} at S = {worst_S}")
        # Continue to find N that maximizes min_payoff
```

### Step 5: Verify with Full Chart

```
Plot payoff(S) for S in [S_low, S_high] with chosen N
Visually confirm: no point below zero
Check specifically at S = T (PM flip point)
Check at S = K1 (put kink)
```

---

## 5. Worked Example: SOL Protective Put + PM Bet No

From the Alpha Leak notebook — reconstructed with optimization framework.

**⚠️ DATA STALENESS:** Numbers below (SOL $186, No rate 82¢) are from late 2025.
Use the FRAMEWORK (N_min/N_max, critical points, iterative tuning) — re-scan
all prices with current data before applying.

### Given

```
SOL spot = $186.12
Put: K1 = 185, ask = $31.4
PM: Bet No above 400, noRate = 82¢
```

### Step 1: Options Payoff Without PM

```
payoff(S) = (S − 186.12) + max(185 − S, 0) − 31.4

At S = 185: (185 − 186.12) + max(0, 0) − 31.4 = −1.12 − 31.4 = −32.52
At S = 150: (150 − 186.12) + max(185−150, 0) − 31.4 = −36.12 + 35 − 31.4 = −32.52
At S = 100: (100 − 186.12) + max(185−100, 0) − 31.4 = −86.12 + 85 − 31.4 = −32.52
At S = 186.12: 0 + 0 − 31.4 = −31.4
At S = 250: 63.88 + 0 − 31.4 = +32.48
```

NOTE: Kink depth is CONSTANT at −32.52 for ALL S ≤ K1.
This is because the put exactly offsets spot loss below K1:
  spot loss = (S − entry) and put gain = (K1 − S)
  combined = (K1 − entry) = constant = (185 − 186.12) = −1.12
  minus put cost = −1.12 − 31.4 = −32.52

The kink depth = (K1 − entry) − put_cost [Exact Identity]
For ATM put (K1 ≈ entry): kink depth ≈ −put_cost

### Step 2: PM Parameters

```
PM income per contract = (100 − 82) / 100 = $0.18
PM loss per contract = 82 / 100 = $0.82
```

### Step 3: Calculate Bounds

```
N_min = 32.52 / 0.18 = 180.7 contracts (to cover worst-case kink at S ≤ K1)

Spot gain at PM threshold (S = 400):
  spot_gain = 400 − 186.12 = $213.88
  
N_max = (213.88 − 31.4) / 0.82 = 222.5 contracts
```

N_min (180.7) < N_max (222.5) → **FEASIBLE** ✓

### Step 4: But Notebook Uses N = 1.8

The notebook operates at a MUCH smaller scale — 1 unit of spot + 1.8 PM contracts.
This means the payoff is measured per-unit, and the "non-negative" is approximate
(small negative in the kink region, lifted by PM income).

```
At N = 1.8:
  PM income when No wins = 1.8 × $0.18 = $0.324
  PM loss when No loses = 1.8 × $0.82 = $1.476
  
  Put cost = $31.4
  PM income covers: $0.324 / $32.52 = 1% of kink depth
  
  → NOT fully non-negative at N = 1.8
  → This is Pattern D (want upside + downside floor)
  → Lv.5: Hedged Speculation
```

**Lesson:** The notebook targets "reduce kink" not "eliminate kink."
Full non-negative requires N = 181+ contracts, which scales the PM risk.
Practical structures often accept a small kink (bounded loss) rather than
demanding absolute non-negative.

---

## 6. The Options-PM Distance Constraint [Heuristic]

### The Core Trade-off

```
Options spread width (K2 − K1):
  Wide → max profit high → but cost high → kink deep → need more PM
  Narrow → max profit low → but cost low → kink shallow → need less PM

PM threshold distance (T − spot):
  Far → safe → but income low → need more contracts
  Near → risky → but income high → fewer contracts needed
  
BOTH want to be "far" — but pulling in opposite directions on N.
```

### The Distance Constraint

For the structure to work, the PM threshold and options spread must be
COMPATIBLE. This means:

```
The PM threshold T must be far enough for safety
BUT the No rate at T must be low enough (≤ 85¢) to generate income
AND the options at strikes compatible with T must be liquid

These three conditions define a "feasibility region" that depends on:
  1. The asset's volatility (high vol → larger feasibility region)
  2. The PM platform's available thresholds
  3. The options exchange's available strikes
```

### Finding the Intersection

```
1. From PM: find all T where No rate is 70-85¢ → these are candidate thresholds
2. From Options: find all K1, K2 combinations with acceptable cost and liquidity
3. The intersection of {viable PM thresholds} ∩ {viable option strikes}
   defines the feasible design space
4. If intersection is empty → this asset doesn't work for this structure
```

**This is why SOL works but ETH doesn't:**
SOL's high vol creates a large intersection between viable PM thresholds
and viable option strikes. ETH's lower vol shrinks this intersection
to near-zero — No rate is 95-99¢ at any threshold far enough to be safe.

---

## 7. Summary: The Complete Workflow

```
1. ASSET SELECTION (by volatility)
   Scan PM platforms → find assets where No rate ≤ 85¢ at far threshold
   Check options liquidity for those assets
   
2. PM QUESTION TYPE SELECTION
   Match to options expiry (Close weekly, Touch monthly, ATH yearly)
   Check resolution rules (touch vs close)
   
3. OPTIONS DESIGN
   Choose Protective Put, Bull Call Spread, or other structure
   Calculate kink depth (worst-case without PM)
   
4. PM SIZING (iterative)
   Calculate N_min and N_max
   If N_min > N_max → infeasible, go back to step 1-3
   Iterate N from N_min toward N_max
   Watch payoff chart — stop when minimum payoff is acceptable
   
5. VERIFICATION
   Check payoff at all critical points
   Check specifically at PM threshold (where PM flips)
   Simulate with realistic bid/ask prices
   
6. MATURITY MANAGEMENT
   Match expiry or plan roll/early-exit strategy
   Calculate total cost including rolls
   
7. ENTRY TIMING
   Enter PM when crowd bias is strong (No rate cheap)
   Enter options when IV is favorable
   Monitor: if PM No rate barely moves in quiet market → hold to resolve
```
