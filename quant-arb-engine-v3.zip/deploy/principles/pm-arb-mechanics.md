# PM Arbitrage Mechanics — Through the Option Lens

PM contracts are digital options. Cross-platform PM arb is digital option parity
violation across venues. This reference provides the math for identifying and
sizing PM-specific edge opportunities.

---

## 1. PM as Digital Options [Exact Identity]

| PM Contract | Option Equivalent |
|------------|-------------------|
| PM YES @ p¢ | Digital call priced at $p/100 |
| PM NO @ q¢ | Digital put priced at $q/100 |
| YES + NO on same market | Digital call + digital put = $1 (put-call parity for digitals) |
| NegRisk group (N outcomes) | Portfolio of N digital calls on mutually exclusive events = $1 |
| Nested threshold (Above $X, Above $Y) | Two digital calls — must satisfy monotonicity: P(>X) ≥ P(>Y) if X < Y |

This mapping means every PM parity rule is a special case of option parity.

---

## 2. Cross-Platform Parity [Exact Identity]

Two platforms pricing the same event must satisfy:

```
cost_YES_on_A + cost_NO_on_B ≤ $1.00
```

If < $1.00 after executable costs → arb. This is the digital equivalent of a box spread.

### Net Edge Waterfall

Every PM edge flows through the same deduction chain:

```
gross_edge = $1.00 − (cost_YES + cost_NO)
− platform_fees (per-platform fee × position)
− slippage (order book depth dependent)
− price_impact (AMM pools only)
= net_edge
```

If net_edge ≤ 0 → no real edge. Don't trade.

### Break-Even

```
break_even_spread = total_fees + slippage + impact
```

Any gross edge smaller than break-even = net loss.

### Annualized Comparison [Heuristic]

```
annualized = net_edge × (365 / days_to_resolution)
```

Shorter-dated markets with same net edge are more capital-efficient. Use for
comparing opportunities, not as guaranteed return.

---

## 3. Combinatorial Arb Types [Exact Identity]

### Type A: NegRisk Group (Mutually Exclusive Outcomes)

A set of N mutually exclusive outcomes must satisfy:

```
Σ P(outcome_i) = $1.00
```

**Overpriced (Σ > $1):** Mint a $1 combined position (costs $1), sell each YES
token on market. Revenue > $1 → profit = Σ − $1 − fees.

**Underpriced (Σ < $1):** Buy all YES tokens. One must resolve YES → payout $1.
Profit = $1 − Σ − fees.

### Type B: Nested Threshold (Monotonicity)

For thresholds X < Y on same underlying and expiry:

```
P(asset > X) ≥ P(asset > Y)    [must hold — X is superset of Y]
```

If P(>Y) > P(>X) → **inversion** → structural mispricing.
Arb: buy YES on underpriced lower threshold, buy NO on overpriced higher.

### Type C: Logical Implication

If event B can only occur when event A also occurs (B ⊆ A):

```
P(B) ≤ P(A)    [must hold — subset ≤ superset]
```

If P(B) > P(A) → structural mispricing.
Only trade if violation > executable cost threshold.

---

## 4. AMM-Specific Mechanics [Exact Identity]

**Note:** Some platforms (e.g., Myriad) have migrated from AMM to CLOB (as of Q1 2026).
Verify which model a platform uses before applying AMM-specific math.
The math below applies only to platforms still using AMM pools (e.g., Azuro, Omen).

AMMs (Azuro, Omen) price using pool reserves, not order books.

### CPAMM Invariant

```
k = yes_reserve × collateral_reserve    (constant)
spot_price = collateral_reserve / yes_reserve
```

### Fill Price (worse than spot — your trade shifts the pool)

```
new_collateral = collateral_reserve + trade_size
new_yes = k / new_collateral
tokens_received = yes_reserve − new_yes
fill_price = trade_size / tokens_received
price_impact = |fill_price − spot_price| / spot_price
```

Large trades relative to pool = large price impact. Cap trade size.

### Overround Stripping [Exact Identity]

AMM prices embed pool fee. Before comparing AMM to CLOB:

```
true_price = quoted_AMM_price / (1 − pool_fee_rate)
```

Without stripping overround, AMM prices look artificially cheap → false edge signal.

### Execution Rule

AMM leg first — AMM price moves with every trade. Lock AMM entry before
executing CLOB leg. CLOB price is stable (limit order).

---

## 5. Verdict Framework [Heuristic — adjust thresholds to conditions]

| Verdict | Net Edge | Action |
|---------|----------|--------|
| Strong | > break_even × 2 | Execute if liquidity allows |
| Marginal | break_even to break_even × 2 | Monitor — verify criteria match exactly |
| Avoid | < break_even | Fees + slippage consume the spread |

---

## 6. Risk Factors Specific to PM Arb

| Risk | Description | Mitigation |
|------|------------|------------|
| Oracle mismatch | Different platforms use different resolution sources | Verify resolution source on both |
| Criteria mismatch | "Same event" may be worded differently | Read exact resolution rules |
| Leg risk | Market moves between filling leg 1 and 2 | Execute simultaneously via API |
| Liquidity depth | Large fills exhaust order book | Check depth; size down if shallow |
| AMM price impact | Fill degrades as size grows relative to pool | Use fill simulator; cap at ~2% of pool |
| Platform restrictions | Jurisdiction limits, position caps | Verify account access and limits |

## 7. NegRisk + Options Bridge [Heuristic — Untested]

When NegRisk outcomes are overpriced (Σ Yes prices > $1):
1. Mint a $1 combined position (costs $1, gives you Yes tokens for every outcome)
2. Sell the overpriced outcome Yes tokens on PM (receive > $1 total)
3. You now hold remaining Yes tokens for underpriced outcomes
4. Hedge the underpriced outcomes using options (puts/calls matching the state)

This bridges PM combinatorial arb with options hedging — using options to manage
the residual risk from selling overpriced PM outcomes. Requires: NegRisk platform
(Polymarket), overpriced outcomes, AND liquid options on the same underlying.
Not yet validated with real execution — treat as hypothesis.
