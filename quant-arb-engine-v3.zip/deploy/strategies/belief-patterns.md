# Belief Pattern Templates

Use these patterns when the user gives a rough market belief or intuition.
Each pattern includes: common candidate families, what to optimize, main dangers,
and state-claim decomposition guidance.

**Key principle:** These patterns are starting points for creative design, not fixed recipes.
Use the state-claim framework to modify, combine, or invent beyond these templates.

---

## Pattern A — "ขึ้น แต่ไม่น่าทะลุ X ภายในเวลา T"
**Belief:** Price goes up, but probably not above threshold X by time T.

**State claims needed:**
- Leg 1: Bullish exposure (linear or convex) — profit in likely state
- Leg 2: Cap repair — pays if wrong about X boundary

**Candidate families:**
- Long Call + Buy No(X)
- Bull Call Spread + Buy No(X)
- Long Spot / Long Future + Protective Overlay + PM leg
- Capped bullish structure + prediction-market threshold overlay

**Optimize:** long strike, spread width, PM threshold, PM count N, expiry alignment

**Main dangers:** blow-off move through X, PM/option mismatch, settlement mismatch

**Same-trigger check:** If call strike ≈ PM threshold → they trigger together → amplify, not hedge.
Ensure sufficient distance between option strikes and PM boundary.

---

## Pattern B — "ลง แต่ไม่น่าหลุด Y ภายในเวลา T"
**Belief:** Price goes down, but probably not below threshold Y by time T.

**State claims needed:**
- Leg 1: Bearish exposure — profit in likely state
- Leg 2: Floor repair — pays if wrong about Y boundary

**Candidate families:**
- Long Put + PM overlay
- Bear Put Spread + PM overlay
- Short Future + Long Call + PM overlay
- Downside convexity + binary-like soft floor

**Optimize:** put strike, spread width, PM threshold, PM count N, hedge ratio

**Main dangers:** rebound risk, threshold mismatch, expensive protection

**Same-trigger check:** If put strike ≈ PM threshold → correlated triggers.
Put provides linear protection, PM provides binary — only combine if they cover different zones.

---

## Pattern C — "Movement likely, but extreme terminal state is overpriced"
**Belief:** There will be movement, but the extreme terminal state is priced too high.

**State claims needed:**
- Leg 1: Directional core — profits from expected movement
- Leg 2: Fade extreme — monetize the overpriced tail

**Candidate families:**
- Directional options leg + PM fade of extreme state
- Spread structure + PM overlay
- Capped directional structure + binary overlay

**Main dangers:** extreme state actually occurs, narrative overwhelms pricing logic

**Pattern lesson:** Large probability gaps between PM and options markets often exist
at extremes, but different payoff shapes (binary vs linear) and settlement mechanics
make clean exploitation difficult. Size accordingly.

---

## Pattern D — "Want upside, but need downside floor"
**Belief:** User wants participation in upside but needs a guaranteed minimum.

**State claims needed:**
- Leg 1: Upside participation (convex)
- Leg 2: Downside floor (protective)
- Optional Leg 3: Funding leg to pay for protection

**Candidate families:**
- Bull Call Spread
- Long Spot / Future + Protective Put
- Long Call + PM overlay
- Convex exposure financed with capped overlay

**Main dangers:** overpaying for protection, sacrificing too much upside

**Key trade-off:** True non-negative with upside requires PM strike far enough from spot.
If not available → bounded loss is the realistic alternative.

---

## Pattern E — "Tail event is overpriced"
**Belief:** The probability of an extreme event is priced too high relative to reality.

**State claims needed:**
- Leg 1: Fade the tail (sell the overpriced claim)
- Leg 2: Directional core or protection if tail occurs

**Candidate families:**
- PM fade of tail state + directional core leg
- Capped spread + PM tail fade
- Synthetic / parity check if related markets imply lower tail probability

**Main dangers:** shorting tail too aggressively, hidden convexity against you, event gap risk

**Pattern lesson:** PM markets often exhibit longshot bias — overpricing tails.
But binary payoff on PM vs linear payoff on options means the "same" probability
gap doesn't translate to exploitable edge without careful structure design.

---

## Pattern F — "It may not be pure arb, but is it good enough?"
**Belief:** User suspects the opportunity isn't locked but might have enough edge.

**Default behavior:**
1. Classify honestly on the Arb Taxonomy
2. Bound the mismatch risk — identify exact unlocked states
3. Estimate whether compensation is sufficient for the risk taken
4. Decide: worth modeling → scanning → paper trading → or reject

**Pattern lesson:** The taxonomy from pure arb to directional spec is continuous.
Most practical opportunities live in levels 3–5. The key question is whether the
residual risk is bounded and the compensation is adequate.

---

## Pattern G — "I want something scanner-friendly / bot-friendly"
**Belief:** User wants structures that are easy to automate.

**Default bias — prefer structures with:**
- Fewer legs
- Clearer mappings and threshold logic
- Lower legging risk
- Simpler settlement logic
- Easier reconciliation
- Stable scanner signal (not flickering)

**Pattern lesson:** Scanner-friendliness often conflicts with optimal payoff shape.
The best automated structure may not be the best theoretical structure. Prioritize
operational robustness over marginal edge improvement.

---

## Pattern H — "I want a structure that doesn't exist in textbooks"
**Belief:** User wants creative, novel structure design.

**Default behavior:**
1. Start from belief → state space → desired payoff shape
2. Decompose desired payoff into segments (regions of the state space)
3. For each segment, find the cheapest state claim that covers it
4. Compose legs — check trigger correlation at every step
5. Run the 7 Design Questions
6. Run D_min test if spread + PM combination
7. Stress-test: what breaks? what's the worst scenario?
8. Compare to the closest named strategy — is the custom version actually better?

**Main dangers:** over-engineering, too many legs, unfillable structure, false sense of novelty
(often the "new" structure is a known strategy in disguise — which is fine, but be honest about it)
