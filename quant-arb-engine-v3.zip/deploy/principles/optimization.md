# Optimization Framework

## Feasibility Tests

### D_min Test (Spread + PM) [Exact Identity]

```
D_min = (C − I) / p_no + I
D_actual ≥ D_min → feasible for non-negative payoff
```

### PM-Only Feasibility [Exact Identity]

Σ Ask(all brackets) > $1 → PM-only non-negative impossible.
Monitor for flash inversions where Σ Ask < $1.

### Feasibility Patterns

| Goal | Feasibility | Label |
|------|------------|-------|
| Non-negative + upside | PM strike must be far from spot | [Heuristic] |
| Non-negative, no upside | Conversion-type only | [Exact Identity] |
| Upside + bounded loss | Split-strike / spread | [Exact Identity] |
| PM-only non-negative | Impossible when Σ Ask > $1 | [Exact Identity] |

---

## Method

Use the simplest method that fits. Optimize deployable structures using executable
prices, fees, slippage, and legging risk. Never optimize theoretical payoffs.

---

## Payoff Tuning

Optimize the **shape** of the payoff curve: lift downside floor, preserve upside,
cap tails, widen profitable region, improve EV without destroying robustness.

---

## Scenario Dimensions

Test across: terminal price, pre-expiry shock, IV change, fill quality/slippage,
settlement mismatch, same-trigger amplification.

---

## Regime-Dependent [Heuristic]

| Regime | Focus |
|--------|-------|
| Trending (bias visible) | Exploit identified bias |
| High IV (IV > RV) | Credit spreads for VRP |
| Sideways | Iron condor wings |
| Neutral | Conversion/reversal for basis |

Regime changes. Re-verify before each trade.
