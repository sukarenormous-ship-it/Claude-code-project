# quant-arb-engine v3

Cross-market edge discovery, payoff engineering, and strategy design
for crypto derivatives, spot, prediction markets, and exchange platform features.

## Directory Structure

```
quant-arb-engine/
├── SKILL.md                           ← Main file — AI reads this first
├── README.md                          ← This file
├── CHANGELOG.md                       ← v2 → v3 changes
├── TEST-SCENARIOS.md                  ← 7 test cases for post-deploy validation
├── CLAUDE-CODE-HANDOFF.md             ← Handoff brief for Claude Code
│
├── profiles/                          ← Strategy profiles (1 per strategy)
│   ├── _template.md                   ← Template for adding new profiles
│   ├── spread-arb.md                  ← Lv.2 Cash-and-carry (floor 5%)
│   ├── funding-harvest.md             ← Lv.3 Funding rate carry (floor 0.005%/8hr)
│   ├── reverse-funding.md             ← Lv.3 Reverse funding (floor -0.005%/8hr)
│   ├── sell-vol.md                    ← Lv.4 Sell IV>RV premium (floor 5pp)
│   ├── platform-yield.md             ← Lv.4 Earn/promo capture (floor ~4%)
│   ├── weekend-gap.md                 ← Lv.4 RWA gap trade (floor 0.3%)
│   ├── cross-exchange-funding.md      ← Lv.3 Cross-exchange funding (floor 0.003%/8hr)
│   ├── conversion.md                  ← Lv.1 Put-call parity (floor 0.15%)
│   └── earn-hedge.md                  ← Lv.3-4 Earn + hedge (floor 3% net)
│
├── strategies/                        ← Process guides (how to do things)
│   ├── timing.md                      ← Regime detection + timing map + avoid_regime
│   ├── composition.md                 ← 5-step composition engine + ranking + descent
│   ├── reasoning.md                   ← 6 discovery prompts + edge source analysis
│   ├── mechanism-transformations.md   ← Transform library + 17 anti-patterns + scoring
│   ├── belief-patterns.md             ← 8 belief→structure pattern templates
│   ├── output-templates.md            ← Opportunity card format + verification labels
│   ├── execution-rules.md             ← Execution order + sizing + risk management
│   ├── operational.md                 ← Scanner/OMS design specifications
│   └── real-world-discoveries.md      ← Market observations + non-negative principle
│
└── principles/                        ← Reference knowledge (math + rules)
    ├── reference-gap.md               ← Reference gap principle + 6 known patterns
    ├── payoff-algebra.md              ← Payoff equations + constraint relaxation + examples
    ├── payoff-primitives.md           ← Building block math (parity, synthetics, greeks)
    ├── instrument-rules.md            ← Instrument functions + PM/options rules
    ├── pm-question-types.md           ← PM taxonomy + asset selection + time decay
    ├── pm-arb-mechanics.md            ← PM parity + NegRisk + AMM/CLOB mechanics
    ├── optimization.md                ← D_min test + feasibility patterns
    ├── cross-instrument-optimization.md ← Options+PM sizing (N_min/N_max)
    └── epistemology-guide.md          ← Knowledge classification labels
```

## How It Works

```
SKILL.md คือ master file — AI อ่านที่นี่ก่อน
  → 6-stage decision flow: OBSERVE → FILTER → MATCH → CREATE → VERIFY → RANK
  → 5 entry paths: Default scan, Belief, Education, Bot, Scanner Handoff
  → Auto-trigger map: AI อ่านเฉพาะ file ที่จำเป็น ไม่อ่านทั้งหมด
  → ทุก conversation อ่าน SKILL.md + timing.md + profiles ที่เกี่ยวข้อง
  → files อื่นอ่านเมื่อ auto-trigger condition match เท่านั้น
```

## Related Skills

```
quant-arb-engine  ← this skill: edge discovery + structure design
quant-foundations  → options education, strategy selection, pricing
quant-simulation   → delta hedging simulation, balance tracking
quant-scanner      → market data scanning, anomaly detection → handoff to arb-engine
```

## Deploy Instructions

```
1. Download quant-arb-engine-v3.zip
2. Unzip → rename "deploy/" to "quant-arb-engine/"
3. Upload to claude.ai Skills → REPLACE existing quant-arb-engine skill
   (the new directory structure replaces the old references/ flat structure)
4. Test: open NEW conversation → run each test in TEST-SCENARIOS.md
5. If issues found → see CLAUDE-CODE-HANDOFF.md for automated testing approach
```

## Adding New Strategies

```
1. Copy profiles/_template.md → profiles/new-strategy.md
2. Fill all 8 sections with quantitative thresholds
3. Add entry to SKILL.md Stage 3 quick-match table
4. Add avoid_regime to strategies/timing.md quick reference table
5. Add to appropriate regime maps in timing.md
6. Test: ask AI about the new strategy → verify it reads the profile
```

## Design Principles

- **Simple first**: Gate 2 baseline comparison — each leg must justify its cost
- **Honest labeling**: Lv.1-5 taxonomy, never call Lv.3+ "arbitrage"
- **Threshold-based**: numeric thresholds from profiles, not qualitative "high/low"
- **Profile-driven**: every cataloged strategy has operating range + net formula
- **Auto-trigger only**: AI reads reference files on-demand, never all upfront
- **Cannot execute**: AI analyzes and recommends, user executes trades
