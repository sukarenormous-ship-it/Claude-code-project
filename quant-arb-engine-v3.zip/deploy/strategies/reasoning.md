# Discovery Reasoning, Edge Source Analysis & Parameter Discovery

Read by: Stage 4 CREATE (when discovery needed)

---

## 1. Discovery Prompts

### When to Use

```
After Composition Engine (composition.md) has been tried:
  - Known patterns checked → nothing above entry
  - Pairwise composition tried → nothing new found
  - But user wants more than "no opportunity"

These prompts generate OBSERVATIONS that may lead to tradeable edges.
They are NOT strategies themselves — they produce raw material
that feeds back into the Composition Engine.

Process:
  Run each prompt → generate 1-2 observations → 
  check if observation implies specific asset + instrument →
  if yes → feed into Composition Engine →
  if no → move to next prompt

After all 6: if ≥1 viable composition found → proceed to pre-screen
             if 0 found → honest "no opportunity" with specifics
```

### The 6 Prompts

**Run order (fastest / highest-hit-rate first):**

```
1. SUBSIDY      — fastest: check Earn/promo page
2. TIME GAP     — calendar-based, predictable
3. WRONG CROWD  — check IV/pricing data already collected
4. FRICTION     — requires deeper platform knowledge
5. NEW PRODUCT  — requires research
6. ANALOGY      — most abstract, slowest

Early-stop: if ≥2 actionable observations found → may stop and compose.
Complete remaining prompts only if user wants exhaustive scan
or found observations are below entry threshold.
```

**Prompt 1: SUBSIDY**

```
"What is the platform currently promoting or subsidizing?"

Logic: platform spends marketing budget to attract users via boosted rates,
zero fees, prize pools, or cashback → subsidized edge exists until budget runs out.

Look for:
  - Earn rate significantly above normal (>8% on stablecoins, >6% on majors)
  - Zero-fee campaigns on specific pairs
  - Trading competitions with prize pools
  - Referral bonuses that offset costs
  - New product launches with introductory rates
  - "Carnival" or seasonal events

If found:
  Edge = subsidy amount above normal rate.
  Duration = until promo ends (check terms).
  Risk = promo terms change, platform risk.
  Combine with: hedge for delta neutral if asset is volatile.
  
Example from practice:
  Bybit Earn Carnival: USDT 12% APR (normal ~4%).
  Subsidy = 8% above normal. Available until Carnival ends.
  No hedge needed (USDT stable). Pure platform yield capture.
```

**Prompt 2: TIME GAP**

```
"Which underlyings trade on different schedules across venues?"

Logic: when reference market closes, remaining venues must price-discover alone
→ fewer informed participants → price drifts → converges when reference reopens.

Look for:
  - Commodity tokens (XAUT, oil) → TradFi closes weekends/holidays
  - Stock tokens → NYSE/NASDAQ close evenings/weekends
  - Any RWA token → underlying has limited trading hours
  - Cross-exchange → one exchange has maintenance window
  - Cross-timezone → Asian hours vs US hours (different participant base)

If found:
  Identify: what is the reference market? when does it close?
  Check: does the token price drift during closure?
  Check: does it converge when reference reopens?
  If yes to both → recurring opportunity tied to calendar.
  
Example from practice:
  XAUT trades 24/7. COMEX gold closes Friday evening → Monday morning.
  XAUT drifts over weekend. Monday: converges to COMEX open.
  Win rate ~67% on directional match. Structural, permanent.
```

**Prompt 3: WRONG CROWD**

```
"Who trades this instrument? Are they mispricing something?"

Logic: if the dominant participants lack expertise in the underlying,
they may systematically misprice based on their own domain's heuristics.

Look for:
  - Crypto traders pricing gold options (IV 30% when gold RV is ~15%)
  - Retail traders on PM (overconfident on extremes)
  - Leverage-heavy crowd on funding (funding rate ≠ fundamental value)
  - TradFi participants unfamiliar with crypto settlement mechanics
  - Bot-free assets where manual traders set prices

If found:
  Identify: WHO is on the other side? WHY are they wrong?
  Check: is their mispricing systematic or random?
  Systematic = repeatable edge. Random = noise, not tradeable.
  
Example from practice (successful):
  XAUT options priced at IV 30%. Gold historical vol ~15%.
  Crypto crowd applies crypto-vol expectations to gold → overpay.
  Systematic: crypto crowd consistently overprices gold vol.
  Tradeable: sell XAUT options if IV-RV gap > 10pp.

Example from practice (FAILED):
  Same observation: XAUT IV 30% vs gold RV 15% → 15pp gap → sell vol?
  HOWEVER: XAUT options bid-ask spread so wide that
  selling at bid price erases the IV premium entirely.
  Wrong crowd IS mispricing, but friction prevents capture.
  → observation valid, but not tradeable on THIS venue.
  → would work if options liquidity improves.
  LESSON: wrong crowd + friction can cancel each other out.
```

**Prompt 4: FRICTION**

```
"What on this platform do most users avoid because it's difficult?"

Logic: where there is friction, most participants stay away → edge persists.

Look for:
  - Products with thin liquidity (XAUT futures bid-ask $25)
  - Complex execution (multi-leg options on illiquid strikes)
  - Obscure features (Convert pricing, TradFi section, margin modes)
  - Manual-only processes (no API, requires clicking through UI)
  - High minimum size or awkward lot sizes

If found:
  Friction = barrier to arb → edge may be real and persistent.
  Check: is the friction ALSO a barrier for US? If yes → not actionable.
  If friction only blocks others (bots, casual traders) but we can do it → edge.
  
Example from practice:
  XAUT futures have $25 bid-ask spread → bots can't profit → basis $18 persists.
  We can capture it manually if willing to accept spread cost.
  Whether it's WORTH capturing depends on net after spread.
```

**Prompt 5: NEW PRODUCT**

```
"What on this platform launched within the last 3 months?"

Logic: new products lack established arb infrastructure.
No one has built bots, no MM competition, pricing may be off.

Look for:
  - New token listings (spot before perp → basis gap)
  - New Earn/savings products (introductory rates often high)
  - New contract types (USDC-settled options, TradFi section)
  - New features (Convert, Copy Trading signals, PM integration)
  - New pairs (exotic crosses, commodity tokens)

If found:
  Check: is pricing efficient? (compare to similar products)
  Check: is there arb infrastructure? (bots, MM, API access)
  If no arb infra → mispricing may persist for weeks/months.
  Window: typically 1-3 months before arb infra catches up.
  
Example from practice:
  XAUT Earn launched March 2026. 11% APR for early depositors.
  No one has built Earn+hedge strategy yet (new product).
  Edge: platform subsidy + lack of competition.
```

**Prompt 6: CROSS-DOMAIN ANALOGY**

```
"What TradFi strategy has no crypto equivalent yet?"

Logic: strategies that work in TradFi may translate to crypto
if the underlying mechanism exists but no one has implemented it.

Look for:
  - Dividend capture (TradFi) → Earn yield capture (crypto)
  - Basis trading (TradFi futures) → Cash-and-carry (crypto)
  - Pairs trading (TradFi stocks) → Correlated token pairs (crypto)
  - Calendar spreads (TradFi options) → Crypto options term structure
  - Convertible arb (TradFi bonds) → Token mechanics with conversion features
  - Merger arb (TradFi M&A) → Token migration/upgrade events

If found:
  Verify: does the underlying mechanism actually exist in crypto?
  Verify: are the required instruments available?
  If yes → implement. If partially → note what's missing.
  
Example from practice:
  TradFi: "Dividend stock + short futures" is standard income strategy.
  Crypto equivalent: "Earn yield + short perp" — same mechanism.
  Not widely done because people think of Earn and Perp as different worlds.
```

---

## 2. Edge Source Analysis

### When to Use

```
For EVERY candidate edge — before proceeding to composition or verification.
This is not optional. If you can't answer these 3 questions, the edge may not be real.

Relationship to Discovery Prompts:
  Discovery prompts answer: "WHERE might edge exist?" → raw observation
  Edge Source answers: "IS this edge real and durable?" → validated edge
  
  Overlap is intentional — Edge Source is the VERIFICATION step.
  If Edge Source confirms what the prompt found, that's good — it means
  the observation was already well-reasoned. Don't force a different answer.
```

### The 3 Questions

**Question 1: WHO is on the other side?**

```
Every trade has a counterparty. Who is losing money for you to profit?

Common answers:
  Retail overleveraged         → funding rate extreme
  Bots excluded by friction    → wide spread on low-liquidity assets
  Market makers offline        → parity violations (conversion arb)
  Platform marketing budget    → subsidized Earn rates
  Uninformed crowd             → IV mispricing (wrong crowd)
  Forced sellers/buyers        → liquidation cascades, margin calls
  Passive holders              → not optimizing yield (Earn available but unused)

Red flag: "Nobody is losing" → probably not a real edge.
Exceptions — when counterparty is an ENTITY with a budget, not a trader:
  - Platform marketing budget (Earn promos, zero-fee campaigns)
  - Protocol inflation/emission (staking rewards, liquidity mining)
  - Insurance fund distributions
  - Airdrop farming subsidies
  In these cases: entity pays intentionally → edge is real but temporary.
  Duration = until budget runs out or program changes.
```

**Question 2: WHY hasn't this been arbitraged away?**

```
If edge is real, why does it still exist?

Structural reasons (edge persists):
  □ Low liquidity         → bots can't scale profitably
  □ Platform subsidy      → platform is paying intentionally
  □ Time gap              → structural market closure (weekends, holidays)
  □ Information gap       → niche asset, less analyst coverage
  □ Infrastructure gap    → no API, manual-only, complex execution
  □ Regulatory barrier    → restricted in some regions
  □ Product newness       → arb infrastructure hasn't been built yet

Non-structural reasons (edge may vanish):
  □ Temporary glitch      → will close in seconds/minutes
  □ Data lag              → prices not actually different, just delayed
  □ Miscalculation        → you missed a fee or cost
  □ Regime-dependent      → works now, breaks when regime changes

If no structural reason → be very skeptical.
```

**Question 3: HOW LONG will this edge persist?**

```
Duration guides position sizing and urgency:

  Structural (market design):       months to years
    e.g., weekend gap, low-liquidity asset spread
    → can build systematic strategy, larger size OK
    
  Platform subsidy (promo):         until promo ends (weeks to months)
    e.g., Earn Carnival 12%, zero-fee campaign
    → capture while available, prepare to exit
    
  Time gap (calendar):              permanent but periodic
    e.g., weekend gold gap, after-hours stock token drift
    → recurring strategy, schedule-based
    
  Information gap:                  until more participants enter (months)
    e.g., new asset class, niche token
    → narrowing over time, act sooner = better
    
  Newness:                          weeks to months
    e.g., new product launch, first listing
    → arb infra being built, window closing
    
  Temporary:                        seconds to minutes
    e.g., exchange glitch, MM requote
    → act instantly or don't bother

Map persistence to strategy:
  Long persistence → larger size, less urgency, systematic
  Short persistence → small size or instant execution, opportunistic
```

---

## 3. Parameter Discovery

### When to Use

```
Run the 5-question process when:
  1. Analyzing a NEW asset class not seen before
     (first time looking at oil tokens, stock tokens, new RWA)
  2. User observes something unexpected
     ("why did funding flip?", "why is IV different from TradFi?")
  3. Discovery prompts found TIME GAP or FRICTION observation
     → use Q2-Q5 to identify WHICH parameters drift
  4. Looking for second-order effects to optimize existing strategy
     ("can we improve Earn+hedge by timing around IV cycles?")

Do NOT run for:
  - Well-known assets with established profiles (BTC, ETH)
    unless something unexpected happened
  - Simple platform yield capture (no parameters to discover)
  - When time budget is tight — this is deep analysis, not quick scan
```

### The Principle

```
Every parameter in a market has a reference source that anchors it.
When the reference disappears, the parameter drifts.
When the reference returns, the parameter converges (usually).
This drift-convergence cycle is a tradeable pattern.

Price is the most obvious parameter, but NOT the only one.
```

### 5-Question Discovery Process

For any instrument or asset, ask:

**Q1: "What parameters determine its price, cost, or value?"**

```
Don't stop at price. List everything:
  - Spot price (obvious)
  - Implied volatility (options pricing)
  - Funding rate (perp cost-of-carry)
  - Borrow/lending rate (margin cost)
  - NAV / token peg (wrapped/tokenized asset value)
  - Index price (aggregated reference)
  - Oracle price (DeFi reference)
  - Correlation with other assets
  - Margin requirement (capital efficiency)
  - Collateral ratio (haircut)
  - Fee tier (volume-dependent)
  - Settlement price (expiry reference)
```

**Q2: "What is the reference source for each parameter?"**

```
Every parameter is anchored by something:
  Price          → reference market (COMEX for gold, NYSE for stocks)
  IV             → market maker quotes + options supply/demand
  Funding rate   → arb bots maintaining spot-perp basis
  Borrow rate    → lending pool supply/demand
  NAV            → redemption mechanism against underlying
  Index price    → aggregate of prices from multiple exchanges
  Oracle         → on-chain feed (Chainlink, Pyth) with update frequency
  Correlation    → historical co-movement pattern
  Margin req.    → exchange risk engine using current IV + positions
```

**Q3: "When does each reference have downtime?"**

```
  Reference market closes        → weekends, holidays, after-hours
  Market maker goes offline       → off-hours, stress events, maintenance
  Arb bots stop                   → exchange API down, gas too high
  Lending pool depletes           → whale withdrawal, bank run
  Oracle update delayed           → congestion, heartbeat too slow
  Exchange under maintenance      → scheduled or emergency
  Correlation breaks              → market stress, structural change
  Risk engine recalculates        → only periodically, not continuous
```

**Q4: "Does the parameter drift during downtime?"**

```
  Check: does the parameter behave differently when reference is absent?
  
  Price without reference market:     usually drifts ✓
  IV without market makers:           often spikes or collapses ✓
  Funding without arb bots:           can become extreme ✓
  Borrow rate without supply:         spikes ✓
  NAV without redemption:             token trades at premium/discount ✓
  Oracle without update:              stale price, protocol uses old data ✓
  Correlation during stress:          breaks down ✓
  Margin req with stale IV:           may be too loose or too tight ✓
  
  Not all parameters drift equally. Some have backup mechanisms.
  Check empirically if data available.
```

**Q5: "Does it converge when reference returns?"**

```
  ✅ Typically converges:
     Price (settlement mechanism forces convergence)
     IV (MMs reprice when back online)
     Funding (arb bots restore basis)
     NAV (redemption reopens)
     Oracle (feed updates)
     
  ⚠️ May or may not converge:
     Correlation (may have structurally changed)
     Borrow rate (may stay high if demand persists)
     
  ❌ Does not converge:
     If reference changes permanently (delist, protocol change, regime shift)
     → this is NOT a drift — it's a structural change → don't trade as convergence

  BEFORE TRADING any drift:
     Verify the convergence mechanism.
     Name it: settlement, arb bot, MM reprice, redemption, oracle update.
     If you can't name the mechanism → don't assume convergence.
```

### Second-Order Effects

```
Not just direct parameters — parameters that affect OTHER parameters:

  IV → margin requirement → capital efficiency → optimal position size → effective APR
  
  Chain: when IV drops, margin requirement drops, you can take larger position
  with same capital, effective APR increases. But nobody optimizes for this.
  
  Funding rate → Earn-hedge net → strategy viability
  
  Chain: when funding flips, Earn-hedge net changes sign.
  Both variables move independently but affect same outcome.

How to find:
  1. Pick any parameter from Q1 list
  2. Ask: "what does this parameter affect downstream?"
  3. Trace the chain 2-3 steps
  4. Ask: "does anyone optimize across this chain?"
  5. If no → potential edge from cross-parameter optimization
```

### Question Assumptions

```
Parameters that people assume are constant but actually change:

  "Fee is fixed"          → VIP tier changes with volume
  "Collateral ratio fixed" → exchange adjusts based on market conditions
  "Earn rate stable"      → promo rates change without notice
  "Funding every 8hr"     → some exchanges moved to 4hr or 1hr
  "Settlement at expiry"  → early exercise possible for American-style
  "Index = spot"          → index is weighted average, can diverge from any single spot
  
When a "constant" changes, participants who assumed it was fixed will misprice.
  → first movers who notice the change can capture the adjustment period.
  
Monitor: exchange announcements, rule changes, product updates.
These are where "constant" assumptions break.

Integration with workflow:
  Stage 4 pre-screen (DECOMPOSE): "Am I assuming any parameter is constant
    that might change? If yes → edge may be fragile. Note the assumption."
  Stage 5 Gate 3 (FEASIBILITY): "Have any platform rules changed recently?
    Check exchange announcements if uncertain."
  Conversation: when user mentions a rule change → this IS an assumption
    being questioned → capture as insight (see composition.md Section 5).
```

---

## 4. Putting It All Together

```
When Stage 4 CREATE needs discovery:

  Step 1: Run 6 Discovery Prompts (Section 1)
          Generate observations. Not all will be actionable.
          
  Step 2: For each actionable observation, run Edge Source Analysis (Section 2)
          WHO/WHY/HOW LONG — if can't answer → observation is not tradeable
          
  Step 3: For surviving observations, check Parameter Discovery (Section 3)
          Are there parameters drifting that others haven't noticed?
          Are there second-order effects being ignored?
          
  Step 4: Feed actionable edges into Composition Engine (composition.md)
          Transform each validated edge into block format first:
            [asset] [observation]: [magnitude] [Instrument/Platform, edge type]
          Then: enumerate as blocks → pair → calculate → pre-screen
          
  Step 5: Log everything (composition.md Section 5)
          What was found, what was rejected and why,
          what would become viable under changed conditions
```

---

## Note: Example Diversification

```
Current examples are from a single session (April 2026, Bybit, XAUT/BTC).
As more strategies are executed, add diverse examples covering:
  - Different assets (oil tokens, stock tokens, altcoins)
  - Different regimes (bull examples, transition examples)
  - Different platforms (Binance, OKX — not just Bybit)
  - Failed examples (observations that looked promising but weren't)
  - Cross-domain examples (TradFi patterns applied to crypto)

Failed examples are especially valuable — they teach AI to recognize
dead ends faster and avoid wasting user's time.
```
