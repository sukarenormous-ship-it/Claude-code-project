# Output Templates

Use when output is materially relevant. Skip fields that don't apply.

---

## 1. Opportunity Card (Primary Format)

See SKILL.md Stage 6 for the full Opportunity Card format.
Use the v3 card format with: Type, Asset, Structure, Net Profit, Capital,
Duration, Max Loss, Worth-It verdict, Edge Source, Persists, Unverified,
Key Risk, Action, Data Age.

Classification labels (from Gate 4 Data Readiness):
  RECOMMENDATION — 0 unverified items
  CONDITIONAL    — 1 unverified item  
  CANDIDATE      — 2+ unverified items

---

## 2. Quick Scenario Grid

Use for multi-scenario analysis when designing complex structures.

```
┌──────────────────┬──────────┬──────────┬──────────┬───────────┐
│ Scenario         │ P/L      │ Hedged?  │ Fails?   │ Accept?   │
├──────────────────┼──────────┼──────────┼──────────┼───────────┤
│ Strong Down      │          │          │          │           │
│ Mild Down        │          │          │          │           │
│ Flat / Range     │          │          │          │           │
│ Moderate Up      │          │          │          │           │
│ Strong Up        │          │          │          │           │
│ Extreme Move     │          │          │          │           │
│ Bad Fill         │          │          │          │           │
│ Settlement Miss  │          │          │          │           │
└──────────────────┴──────────┴──────────┴──────────┴───────────┘
```

---

## 3. Verification Status Labels

| Label | Meaning |
|-------|---------|
| **RECOMMENDATION** | All items verified — ready to execute |
| **CONDITIONAL** | 1 unverified item — likely viable, verify before size up |
| **CANDIDATE** | 2+ unverified items — promising but needs more data |
| **WATCHLIST** | Below entry but above floor — viable when conditions improve |
| **NOT WORTH IT** | Above floor but baseline is better — show alongside baseline |
| **SKIP** | Below floor — don't bother |

Always state: what the baseline is, and whether the candidate beats it.

---

## 4. No Opportunity Template

```
"No opportunity above entry threshold at any level.

 Closest candidates:
   [Lv.X strategy] — current [metric] = Y, needs Z to reach entry
   
 Best baseline: [platform yield X% or hold cash]
 
 Conditions for opportunities to appear:
   Lv.1-2: [specific condition]
   Lv.3:   [specific condition]  
   Lv.4:   [specific condition]
   
 Re-scan when: [specific trigger]"
```
